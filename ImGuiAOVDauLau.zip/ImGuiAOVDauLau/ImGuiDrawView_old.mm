#import <UIKit/UIKit.h>
#import <Metal/Metal.h>
#import <MetalKit/MetalKit.h>
#import <Foundation/Foundation.h>

#import "imgui/imgui.h"
#import "imgui/imgui_impl_metal.h"
#import "imgui/Il2cpp.h"
#import "imgui/Fonts.h"
#include "imgui/Fonts.hpp"
#import "imgui/stb_image.h"
#import "imgui/Cbeios.h"

#import "LoadView/CaptainHook.h"
#import "LoadView/ImGuiDrawView.h"
#import "LoadView/Includes.h"
#import "LoadView/MonoString.h"
#include "LoadView/dbdef.h"


//Auto Patch
#include "Hook/patch.h"
#include "Hook/hook.h"
#include "Hook/Hookz.h"

//Auto Update
#import "5Toubun/NakanoIchika.h"
#import "5Toubun/NakanoNino.h"
#import "5Toubun/NakanoMiku.h"
#import "5Toubun/NakanoYotsuba.h"
#import "5Toubun/NakanoItsuki.h"
#import "5Toubun/dobby.h"
#import "5Toubun/il2cpp.h"
#import "Security/oxorany_include.h"

#import "stb_image.h"
#import "Image/AutoBocPha.h"
#import "Image/autobangsuong.h"
#import "Image/AutoCapCuu.h"
#import "Image/AutoHoiMau.h"
#import "Image/AutoTrungTri.h"
#import "Image/imagepoong.h"
#import "Image/Herolib.h"
#import "imgui/img.h"
#import "fonts.h"

//ESP
#include "Unity/Quaternion.h"
#include "Unity/Monostring.h"
#include "Unity/Vector2.h"
#import "Unity/Vector3.h"
#include "Unity/VInt3.h"
#include "Unity/EspManager.h"

//Block Host
#import "Antihook/NemG.h"

#define iPhonePlus ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(1242, 2208), [[UIScreen mainScreen] currentMode].size) : NO)
#define kWidth  [UIScreen mainScreen].bounds.size.width
#define kHeight [UIScreen mainScreen].bounds.size.height
#define kScale [UIScreen mainScreen].scale
#define NSSENCRYPT(str) [NSString stringWithUTF8String:str]
using namespace IL2Cpp;
@interface ImGuiDrawView () <MTKViewDelegate>
@property (nonatomic, strong) id <MTLDevice> device;
@property (nonatomic, strong) id <MTLCommandQueue> commandQueue;
- (void)activehack;
@end

@implementation ImGuiDrawView


NSUserDefaults *saveSetting = [NSUserDefaults standardUserDefaults];
NSTimer *autoDeleteTimer;


//float tamdanh = 7.6;
bool BugSkillRange = false;
bool XoaLichSu = false;

static bool MenDeal = true;
static int tab = 1;
static bool ShowBoTroz = false;
static bool ShowRank = false;

static bool ShowBoTroz_active = false;
static bool ShowRank_active = false;


bool ESPEnable = false;
bool CheckFogEsp = false;
bool PlayerBox3D = false;
bool PlayerHealth = false;
bool PlayerLine = false;
bool ShowIconBT = false;
bool PlayerDistance = false;

static float mapStartX = 274.0f;
static float mapStartY = 33.0f;
static float mapSpacingX = 26.0f;
static float mapRadius = 10.0f;




uint64_t OpenWaterUIDOffset;

uint64_t GetCameraOffset;
uint64_t UpdateCameraOffset;
	
uint64_t SetVisibleOffset;
uint64_t GetSkinOffset;
uint64_t UnpackEvoOffset;
	
uint64_t IsOpenOffset;
uint64_t PersonalBtnIdOffset;
uint64_t ShowHeroInfoOffset;
uint64_t ShowSkillStateInfoOffset;
uint64_t ShowHeroHpInfoOffset;

uint64_t CheckRoleNameOffset;
uint64_t RemoveSpaceOffset;
uint64_t UpdateFrameLaterOffset;
uint64_t IsCanSellOffset;
uint64_t SendInBattleMsgOffset;


uint64_t UnpackOffset;
uint64_t OnClickSelectOffset;
uint64_t IsCanUseSkinOffset;
uint64_t GetHeroSkinIdOffset;
uint64_t IsHaveHeroSkinOffset;
	
uint64_t Bugoffset;
uint64_t SkinPicOffset;
uint64_t InitTeamHeroListOffset;
uint64_t TeamLaderGradeMaxOffset;
uint64_t IsHostProfileOffset;

uint64_t UpdateLogicOffset;
uint64_t GetUseSkillDirectionOffset;
uint64_t UpdateLogicESPOffset;
uint64_t DestroyActorOffset;
uint64_t DestroyActor2Offset;

uint64_t ShowWinLoseOffset;
uint64_t SetPlayerNameOffset;
uint64_t SkillSlotOffset;
uint64_t IsAwakeSkinOffset;
uint64_t UpdateNameCDOffset;

uint64_t OnEnterOffset;
uint64_t EndGameOffset;
uint64_t DisconnectOffset;
uint64_t Reconnectoffset;

uint64_t CreateHeroDataOffset;
uint64_t HandleGameSettleOffset;
uint64_t CreateGameOverSummaryOffset;

uint64_t ShowBoTroOffset;
uint64_t ShowKhungRankOffset;


float hb_offsetY = 26.8f;
float hb_textScale = 0.51f;
float hb_barWidth = 55.6f;
float hb_hpHeight = 2.1f;
float hb_mpHeight = 1.5f;
float hb_paddingX = 0.0f;
float hb_spacingY = 0.0f;
float hb_diamondSize = 6.6f;
float hb_nameOffsetY = 0.0f;


ImFont* FontThemes;
ImFont* xFontPongs;


struct Texture {
    id<MTLTexture> texture; 
    float height;
    float width;
    int heroID;
};
id<MTLTexture> LoadImageFromMemory(id<MTLDevice> device, unsigned char* image_data, size_t image_size) {
    CFDataRef imageData = CFDataCreate(kCFAllocatorDefault, image_data, image_size);
    CGDataProviderRef dataProvider = CGDataProviderCreateWithCFData(imageData);
    CGImageRef cgImage = CGImageCreateWithPNGDataProvider(dataProvider, NULL, false, kCGRenderingIntentDefault);
    CFRelease(imageData);
    CGDataProviderRelease(dataProvider);
    if (!cgImage) {
        return nil;
    }
    NSError *error = nil;
    MTKTextureLoader *textureLoader = [[MTKTextureLoader alloc] initWithDevice:device];
    NSDictionary *options = @{MTKTextureLoaderOptionSRGB : @(NO)};
    id<MTLTexture> texture = [textureLoader newTextureWithCGImage:cgImage options:options error:&error];

    if (error) {
        CGImageRelease(cgImage);
        return nil;
    }
    CGImageRelease(cgImage);
    return texture;
}
vector<Texture> textures;

void AddTexturesFromImageData(id<MTLDevice> device) {
    for (const auto& heroData : heroArray) {
        Texture tex;
        tex.texture = LoadImageFromMemory(device, heroData.data, heroData.size);
        if(tex.texture == nil) continue;
        tex.width = tex.texture.width;
        tex.height = tex.texture.height;
        textures.push_back(tex);
    }
}


- (instancetype)initWithNibName:(nullable NSString *)nibNameOrNil bundle:(nullable NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];

    _device = MTLCreateSystemDefaultDevice();
    _commandQueue = [_device newCommandQueue];

    if (!self.device) abort();
    // Ảnh ============
    AddTexturesFromImageData(_device);
    id<MTLTexture> texture = nil;
    CFDataRef imageData = CFDataCreate(kCFAllocatorDefault, _Airi_data, sizeof(_Airi_data));
    CGDataProviderRef dataProvider = CGDataProviderCreateWithCFData(imageData);
    CGImageRef cgImage = CGImageCreateWithPNGDataProvider (dataProvider, NULL, false, kCGRenderingIntentDefault);
    CFRelease(imageData);
    CGDataProviderRelease(dataProvider);
    NSError *error = nil;
    MTKTextureLoader *textureLoader = [[MTKTextureLoader alloc] initWithDevice:self.device];
    NSDictionary *options = @{MTKTextureLoaderOptionSRGB : @(NO)};
    texture = [textureLoader newTextureWithCGImage:cgImage options:options error:&error];

    if (error) {
    NSLog(@"Failed to load texture: %@", error.localizedDescription);
    }
    //======================

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO(); (void)io;

    // Stil referansını al
    ImGuiStyle& style = ImGui::GetStyle();

    ImFontConfig config;
    config.FontDataOwnedByAtlas = false;
    
    io.Fonts->Clear();

    ImFontConfig font_cfg;
    font_cfg.FontDataOwnedByAtlas = false;

    ImGui::StyleColorsDark();

    ImFont* font = io.Fonts->AddFontFromMemoryCompressedTTF((void*)zzz_compressed_data, zzz_compressed_size, 60.0f, NULL, io.Fonts->GetGlyphRangesVietnamese());

    static const ImWchar icons_ranges[] = { ICON_MIN_FA, ICON_MAX_FA, 0 };
    ImFontConfig icons_config;
    icons_config.MergeMode = true;
    icons_config.PixelSnapH = true;
    icons_config.FontDataOwnedByAtlas = false;

    io.Fonts->AddFontFromMemoryTTF((void*)fontAwesome, sizeof(fontAwesome), 60, &icons_config, icons_ranges);


    FontThemes = io.Fonts->AddFontFromMemoryTTF(TtftoHex_Craftedby_Devx, sizeof(TtftoHex_Craftedby_Devx), 16.0f);

    ImGui_ImplMetal_Init(_device);

    return self;
}

+ (void)showChange:(BOOL)open
{
    MenDeal = open;
}

+ (BOOL)isMenuShowing {
    return MenDeal;
}

- (MTKView *)mtkView
{
    return (MTKView *)self.view;
}

- (void)loadView
{
    CGFloat w = [UIApplication sharedApplication].windows[0].rootViewController.view.frame.size.width;
    CGFloat h = [UIApplication sharedApplication].windows[0].rootViewController.view.frame.size.height;
    self.view = [[MTKView alloc] initWithFrame:CGRectMake(0, 0, w, h)];
}



class Camera {
	public:
        static Camera *get_main() {
        Camera *(*get_main_) () = (Camera *(*)()) GetMethodOffset("UnityEngine.CoreModule.dll", "UnityEngine", "Camera", "get_main", 0);
        
        return get_main_();
    }

    Vector3 WorldToViewportPoint(Vector3 position) 
    {
    Vector3 (*WorldToViewportPoint_)(Camera* camera, Vector3 position) = (Vector3 (*)(Camera*, Vector3)) GetMethodOffset(oxorany("UnityEngine.CoreModule.dll"), oxorany("UnityEngine"), oxorany("Camera"), oxorany("WorldToViewportPoint"), 2);
    return WorldToViewportPoint_(this, position);
    }
    
    Vector3 WorldToScreenPoint(Vector3 position) {
        Vector3 (*WorldToScreenPoint_)(Camera *camera, Vector3 position) = (Vector3 (*)(Camera *, Vector3)) GetMethodOffset("UnityEngine.CoreModule.dll", "UnityEngine", "Camera", "WorldToScreenPoint", 1);
        
        return WorldToScreenPoint_(this, position);
    }

    Vector3 WorldToScreen(Vector3 position) {
        Vector3 (*WorldToViewportPoint_)(Camera* camera, Vector3 position, int eye) = (Vector3 (*)(Camera*, Vector3, int)) GetMethodOffset("UnityEngine.CoreModule.dll", "UnityEngine", "Camera", "WorldToViewportPoint", 1);
        
        return WorldToViewportPoint_(this, position, 2);
}

   float get_fieldOfView(){
        float (*get_fieldOfView_)(Camera *camera) = (float (*)(Camera *))GetMethodOffset(oxorany("UnityEngine.CoreModule.dll"),oxorany("UnityEngine"),oxorany("Camera"),oxorany("get_fieldOfView"), 0);
        return get_fieldOfView_(this);
    }
    
    void set_fieldOfView(float value){
        void (*set_fieldOfView_)(Camera *camera,float value) = (void (*)(Camera *,float))GetMethodOffset(oxorany("UnityEngine.CoreModule.dll"),oxorany("UnityEngine"),oxorany("Camera"),oxorany("set_fieldOfView"), 1);
        return set_fieldOfView_(this,value);
    }

};


class Component {
public:
    static void* get_transform(void* instance) {
        static void* (*_) (void*) = (void* (*)(void*)) GetMethodOffset(oxorany("UnityEngine.CoreModule.dll"), oxorany("UnityEngine"), oxorany("Component"), oxorany("get_transform"), 0);
        return (_ != nullptr && instance != nullptr) ? _(instance) : nullptr;
    }
};

class Screen {
public:
    static void SetResolution(int width, int height, bool fullscreen) {
        void (*_) (int, int, bool) = (void (*)(int, int, bool)) GetMethodOffset(oxorany("UnityEngine.CoreModule.dll"), oxorany("UnityEngine"), oxorany("Screen"), oxorany("SetResolution"), 3);
        if (_ != nullptr) {
            _(width, height, fullscreen);
        }
    }
};


class Transform {
public:
    static Vector3 get_position(void* player) {
        static Vector3 (*_) (void*) = (Vector3 (*)(void*)) GetMethodOffset(oxorany("UnityEngine.CoreModule.dll"), oxorany("UnityEngine"), oxorany("Transform"), oxorany("get_position"), 0);
        void* transform = Component::get_transform(player);
        return (_ != nullptr && transform != nullptr) ? _(transform) : Vector3();
    }
    static void set_position(void* player, Vector3 position) {
        static void (*_) (void*, Vector3) = (void (*)(void*, Vector3)) GetMethodOffset(oxorany("UnityEngine.CoreModule.dll"), oxorany("UnityEngine"), oxorany("Transform"), oxorany("set_position"), 1);
        void* transform = Component::get_transform(player);
        _(transform, position);
    }
    static Quaternion get_rotation(void* player) {
        static Quaternion (*_) (void*) = (Quaternion (*)(void*)) GetMethodOffset(oxorany("UnityEngine.CoreModule.dll"), oxorany("UnityEngine"), oxorany("Transform"), oxorany("get_rotation"), 0);
        void* transform = Component::get_transform(player);
        return (_ != nullptr && transform != nullptr) ? _(transform) : Quaternion();
    }
};

VInt3 LActorRoot_get_location(void *instance) {
    VInt3 (*_LActorRoot_get_location)(void *instance) = (VInt3 (*)(void *))GetMethodOffset(oxorany("Project.Plugins_d.dll"), oxorany("NucleusDrive.Logic"), oxorany("LActorRoot") , oxorany("get_location"), 0);
return _LActorRoot_get_location(instance);
}

VInt3 LActorRoot_get_forward(void *instance) {
VInt3 (*_LActorRoot_get_forward)(void *instance) = (VInt3 (*)(void *))GetMethodOffset(oxorany("Project.Plugins_d.dll"), oxorany("NucleusDrive.Logic"), oxorany("LActorRoot") , oxorany("get_forward"), 0);
    return _LActorRoot_get_forward(instance);
}

class CActorInfo {
    public:
        string *ActorName() {
            return *(string **)((uintptr_t)this + GetFieldOffset(oxorany("Project_d.dll"), oxorany("Assets.Scripts.GameLogic"), oxorany("CActorInfo"), oxorany("ActorName")));
        }
};

class ActorConfig {
public:
    int ConfigID() {
        return *(int *) ((uintptr_t) this + GetFieldOffset(oxorany("Project_d.dll"), oxorany("Assets.Scripts.GameLogic"), oxorany("ActorConfig"), oxorany("ConfigID"))); //public Int32 ConfigID; // 0x10
    }
};
class ValueLinkerComponent {
public:
    int get_actorHp() {
        int (*get_actorHp_)(ValueLinkerComponent * objLinkerWrapper) = (int (*)(ValueLinkerComponent *)) GetMethodOffset(oxorany("Project_d.dll"), oxorany("Kyrios.Actor"), oxorany("ValueLinkerComponent"), oxorany("get_actorHp"), 0); //ValueLinkerComponent - get_actorHp
        return get_actorHp_(this);
    }

    int get_actorHpTotal() {
        int (*get_actorHpTotal_)(ValueLinkerComponent * objLinkerWrapper) =
        (int (*)(ValueLinkerComponent *)) GetMethodOffset(oxorany("Project_d.dll"), oxorany("Kyrios.Actor"), oxorany("ValueLinkerComponent"), oxorany("get_actorHpTotal"), 0); //ValueLinkerComponent - get_actorHpTotal
        return get_actorHpTotal_(this);
    }
    int Level() {
            return *(int *) ((uintptr_t) this + GetFieldOffset(oxorany("Project_d.dll"), oxorany("Kyrios.Actor"), oxorany("ValueLinkerComponent"), oxorany("<actorSoulLevel>k__BackingField")));
            }

};

class VActorMovementComponent {
public:
    int get_maxSpeed() {
        int (*get_maxSpeed_)(VActorMovementComponent * component) = (int (*)(VActorMovementComponent *))GetMethodOffset(oxorany("Project_d.dll"), oxorany("Kyrios.Actor"), oxorany("VActorMovementComponent"), oxorany("get_maxSpeed"), 0);
        return get_maxSpeed_(this);
    }
};

class HudComponent3D { // autott
    public:
            
        int Hud() { // Kiểu loại Hud
            return *(int *) ((uintptr_t) this + GetFieldOffset(oxorany("Project_d.dll"), oxorany("Assets.Scripts.GameLogic"), oxorany("HudComponent3D"), oxorany("HudType")));
       }
        
        int Hudh() { // độ cao Hud
            return *(int *) ((uintptr_t) this + GetFieldOffset(oxorany("Project_d.dll"), oxorany("Assets.Scripts.GameLogic"), oxorany("HudComponent3D"), oxorany("hudHeight")));
       }
   };   

class ActorLinker {
public:
    ValueLinkerComponent *ValueComponent() {
        return *(ValueLinkerComponent **)((uintptr_t)this + GetFieldOffset(oxorany("Project_d.dll"), oxorany("Kyrios.Actor"), oxorany("ActorLinker"), oxorany("ValueComponent"))); //public ValueLinkerComponent ValueComponent; // 0x18
    }
    ActorConfig *ObjLinker() {
        return *(ActorConfig **) ((uintptr_t) this + GetFieldOffset(oxorany("Project_d.dll"), oxorany("Kyrios.Actor"), oxorany("ActorLinker"), oxorany("ObjLinker"))); //public ActorConfig ObjLinker; // 0x9C
    }
    VActorMovementComponent* MovementComponent() {
            return *(VActorMovementComponent**)((uintptr_t)this + GetFieldOffset(oxorany("Project_d.dll"), oxorany("Kyrios.Actor"), oxorany("ActorLinker"), oxorany("MovementComponent"))); 
        }
    Vector3 get_position() {
        Vector3 (*get_position_)(ActorLinker * linker) = (Vector3(*)(ActorLinker *)) GetMethodOffset(oxorany("Project_d.dll"), oxorany("Kyrios.Actor"), oxorany("ActorLinker"), oxorany("get_position"), 0); //ActorLinker - get_position
        return get_position_(this);
    }
    Quaternion get_rotation() {
        Quaternion (*get_rotation_)(ActorLinker *linker) = (Quaternion (*)(ActorLinker *)) GetMethodOffset(oxorany("Project_d.dll"), oxorany("Kyrios.Actor"), oxorany("ActorLinker"), oxorany("get_rotation"), 0); //ActorLinker - get_rotation
        return get_rotation_(this);
    }
    bool IsHostCamp() {
        bool (*IsHostCamp_)(ActorLinker *linker) = (bool (*)(ActorLinker *)) GetMethodOffset(oxorany("Project_d.dll"), oxorany("Kyrios.Actor"), oxorany("ActorLinker"), oxorany("IsHostCamp"), 0); //ActorLinker - IsHostCamp
        return IsHostCamp_(this);
    }
    bool IsHostPlayer() {
        bool (*IsHostPlayer_)(ActorLinker *linker) = (bool (*)(ActorLinker *)) GetMethodOffset(oxorany("Project_d.dll"), oxorany("Kyrios.Actor"), oxorany("ActorLinker"), oxorany("IsHostPlayer"), 0); //ActorLinker - IsHostPlayer
        return IsHostPlayer_(this);
    }
    bool isMoving() {
        return *(bool *) ((uintptr_t) this + GetFieldOffset(oxorany("Project_d.dll"), oxorany("Kyrios.Actor"), oxorany("ActorLinker"), oxorany("isMoving"))); //	public bool isMoving; // 0x2F2
    }
    Vector3 get_logicMoveForward() {
        Vector3 (*get_logicMoveForward_)(ActorLinker *linker) = (Vector3 (*)(ActorLinker *)) GetMethodOffset(oxorany("Project_d.dll"), oxorany("Kyrios.Actor"), oxorany("ActorLinker"), oxorany("get_logicMoveForward"), 0); //ActorLinker - get_logicMoveForward
        return get_logicMoveForward_(this);
    }
    bool get_bVisible() {
        bool (*get_bVisible_)(ActorLinker *linker) = (bool (*)(ActorLinker *)) GetMethodOffset(oxorany("Project_d.dll"), oxorany("Kyrios.Actor"), oxorany("ActorLinker"), oxorany("get_bVisible"), 0); //ActorLinker - get_bVisible
        return get_bVisible_(this);
    }
    int get_playerId() {
        int (*get_playerId_)(ActorLinker *linker) = (int (*)(ActorLinker *)) GetMethodOffset(oxorany("Project_d.dll"), oxorany("Kyrios.Actor"), oxorany("ActorLinker"), oxorany("get_playerId"), 0);
        return get_playerId_(this);
    }
     uintptr_t AsHero() {
            uintptr_t (*AsHero_)(ActorLinker *linker) = (uintptr_t (*)(ActorLinker *)) (GetMethodOffset(oxorany("Project_d.dll"), oxorany("Kyrios.Actor"), oxorany("ActorLinker"), oxorany("AsHero"), 0));
            return AsHero_(this);
        }

    HudComponent3D *HudControl() {
            return *(HudComponent3D **)((uintptr_t)this + GetFieldOffset(oxorany("Project_d.dll"), oxorany("Kyrios.Actor"), oxorany("ActorLinker"), oxorany("HudControl")));
        } // autott
};

class ActorManager {
public:
    List<ActorLinker *> *GetAllHeros() {
        List<ActorLinker *> *(*_GetAllHeros)(ActorManager *actorManager) = (List<ActorLinker *> *(*)(ActorManager *)) GetMethodOffset(oxorany("Project_d.dll"), oxorany("Kyrios.Actor"), oxorany("ActorManager"), oxorany("GetAllHeros"), 0); //ActorManager - GetAllHeros
        return _GetAllHeros(this);
    }

    List<ActorLinker *> *GetAllMonsters() {
       List<ActorLinker *> *(*_GetAllMonsters)(ActorManager *actorManager) = (List<ActorLinker *> *(*)(ActorManager *))(GetMethodOffset(oxorany("Project_d.dll"), oxorany("Kyrios.Actor"), oxorany ("ActorManager"), oxorany("GetAllMonsters"), 0));
        return _GetAllMonsters(this); // autott
     } 

};

class KyriosFramework {
public:
    static ActorManager *get_actorManager() {
        auto get_actorManager_ = (ActorManager *(*)()) GetMethodOffset(oxorany("Project_d.dll"), oxorany("Kyrios"), oxorany("KyriosFramework"), oxorany("get_actorManager"), 0); //KyriosFramework - get_actorManager
        return get_actorManager_();
    }
};

class LAcComponent {
public:
    uint32_t get_ACInstanceID() {
        return *(uint32_t*)((uintptr_t)this + GetFieldOffset(oxorany("Project.Plugins_d.dll"), oxorany("NucleusDrive.Logic"), oxorany("LAcComponent"), oxorany("acInstanceID"))); // 0x20
    }

    uint32_t get_PlayerID() {
        return *(uint32_t*)((uintptr_t)this + GetFieldOffset(oxorany("Project.Plugins_d.dll"), oxorany("NucleusDrive.Logic"), oxorany("LAcComponent"), oxorany("playerID"))); // 0x24
    }

    uint32_t get_ChessID() {
        return *(uint32_t*)((uintptr_t)this + GetFieldOffset(oxorany("Project.Plugins_d.dll"), oxorany("NucleusDrive.Logic"), oxorany("LAcComponent"), oxorany("chessID"))); // 0x28
    }

    uint32_t get_StarLevel() {
        return *(uint32_t*)((uintptr_t)this + GetFieldOffset(oxorany("Project.Plugins_d.dll"), oxorany("NucleusDrive.Logic"), oxorany("LAcComponent"), oxorany("starLevel"))); // 0x2c
    }

    uint32_t get_Hurt() {
        return *(uint32_t*)((uintptr_t)this + GetFieldOffset(oxorany("Project.Plugins_d.dll"), oxorany("NucleusDrive.Logic"), oxorany("LAcComponent"), oxorany("hurt"))); // 0x30
    }

    int32_t get_ACFetterSign() {
        return *(int32_t*)((uintptr_t)this + GetFieldOffset(oxorany("Project.Plugins_d.dll"), oxorany("NucleusDrive.Logic"), oxorany("LAcComponent"), oxorany("acFetterSign"))); // 0x34
    }

    std::vector<uint32_t> get_DropActionList() {
        return *(std::vector<uint32_t>*)((uintptr_t)this + GetFieldOffset(oxorany("Project.Plugins_d.dll"), oxorany("NucleusDrive.Logic"), oxorany("LAcComponent"), oxorany("dropActionList"))); // 0x48
    }

    std::vector<uint32_t> get_EquipList() {
        return *(std::vector<uint32_t>*)((uintptr_t)this + GetFieldOffset(oxorany("Project.Plugins_d.dll"), oxorany("NucleusDrive.Logic"), oxorany("LAcComponent"), oxorany("equipList"))); // 0x4c
    }
};

ImDrawList* getDrawList(){
    ImDrawList *drawList;
    drawList = ImGui::GetBackgroundDrawList();
    return drawList;
};
static int slot1;
static int slot2;
static int slot3;

int aimType = 0;
int drawType = 2;
int HeroTypeID = 0;

void DrawAimbotTab() {

    const char* aimWhenOptions[] = {"Aim Theo Tỉ Lệ % Máu", "Aim Theo Tỉ Lệ Máu Thấp", "Aim Theo Địch Ở Gần Nhất", "Aim Theo Địch Gần Tia Nhất"};

    ImGui::Combo("Tuỳ Chọn Aim :)", &aimType, aimWhenOptions, IM_ARRAYSIZE(aimWhenOptions));

    const char* drawOptions[] = {"Không", "Luôn Bật", "Khi Xem"};
    ImGui::Combo("Vẽ Vật Thể", &drawType, drawOptions, IM_ARRAYSIZE(drawOptions));

}

void DoLeckID() {
    const char* HeroWhenOptions[] = {"Elsu", 
    "Gildur","Grakk","Raz",
    "Enzo","Yue"};
    ImGui::PushItemWidth(80);
    ImGui::Combo("##Dolechtiong", &HeroTypeID, HeroWhenOptions, IM_ARRAYSIZE(HeroWhenOptions));
    ImGui::PopItemWidth();

static bool Elsu_active = false;
static bool Gildur_active = false;
static bool Grakk_active = false;
static bool Raz_active = false;
static bool Enzo_active = false;
static bool Yue_active = false;


//====== Hero Elsu 196 ============
if (HeroTypeID == 0) {
    if (Elsu_active == NO) {
        Radius = 25;
        DoLechAim = 0.43;
        // SizeIDHero = 196;
    }
    Elsu_active = YES;
}
else {
    if (Elsu_active == YES) {
    }
    Elsu_active = NO;
}

//====== Hero Gildur 108 ============
if (HeroTypeID == 1) {
    if (Gildur_active == NO) {
        Radius = 15;
        DoLechAim = 0.90;
        // SizeIDHero = 108;
    }
    Gildur_active = YES;
}
else {
    if (Gildur_active == YES) {
    }
    Gildur_active = NO;
}

//====== Hero Grakk 175 ============
if (HeroTypeID == 2) {
    if (Grakk_active == NO) {
        Radius = 15;
        DoLechAim = 0.60;
        // SizeIDHero = 175;
    }
    Grakk_active = YES;
}
else {
    if (Grakk_active == YES) {
    }
    Grakk_active = NO;
}

//====== Hero Raz 157 ============
if (HeroTypeID == 3) {
    if (Raz_active == NO) {
        Radius = 15;
        DoLechAim = 0.50;
        // SizeIDHero = 157;
    }
    Raz_active = YES;
}
else {
    if (Raz_active == YES) {
    }
    Raz_active = NO;
}

//====== Hero Enzo 195 ============
if (HeroTypeID == 4) {
    if (Enzo_active == NO) {
        Radius = 10;
        DoLechAim = 0.54;
        // SizeIDHero = 195;
    }
    Enzo_active = YES;
}
else {
    if (Enzo_active == YES) {
    }
    Enzo_active = NO;
}

//====== Hero Yue 545 ============
if (HeroTypeID == 5) {
    if (Yue_active == NO) {
        Radius = 15;
        DoLechAim = 0.75;
        // SizeIDHero = 545;
    }
    Yue_active = YES;
}
else {
    if (Yue_active == YES) {
    }
    Yue_active = NO;
}
} 


float Radius = 0;
float DoLechAim = 0;
int skillSlot;
float LazeThemes = 0;
float LazeElsu[4] = { 0.0f,1.0f,1.0f,1.0f };
float ColorCrosshair[4] = { 1.0f,0.0f,0.0f,1.0f };
bool AimSkill = false;
static int AllHero = 1;
static int SizeIDHero;

struct EntityInfo {
    Vector3 myPos;
    Vector3 enemyPos;
    Vector3 moveForward;
    int ConfigID;
    bool isMoving;
    int currentSpeed;
    float Ranger;
    int Hud;
    int Hudh;
    int Level; 
    ActorLinker *Entity;
};

EntityInfo EnemyTarget;

Vector3 RotateVectorByQuaternion(Quaternion q) {
    Vector3 v(0.0f, 0.0f, 1.0f);
    float w = q.w, x = q.x, y = q.y, z = q.z;

    Vector3 u(x, y, z);
    Vector3 cross1 = Vector3::Cross(u, v);
    Vector3 cross2 = Vector3::Cross(u, cross1);
    Vector3 result = v + 2.0f * cross1 * w + 2.0f * cross2;

    return result;
}

float SquaredDistance(Vector3 v, Vector3 o) {
    return (v.x - o.x) * (v.x - o.x) + (v.y - o.y) * (v.y - o.y) + (v.z - o.z) * (v.z - o.z);
}

Vector3 calculateSkillDirection(Vector3 myPosi, Vector3 enemyPosi, bool isMoving, Vector3 moveForward, int currentSpeed) {
    if (isMoving) {
        float distance = Vector3::Distance(myPosi, enemyPosi);
        float bulletTime = distance / (Radius / DoLechAim); 

        enemyPosi += Vector3::Normalized(moveForward) * (currentSpeed / 1000.0f) * bulletTime;
    }

    Vector3 direction = enemyPosi - myPosi;
    direction.Normalize();
    return direction;
}

Vector2 drawPos;
bool isCharging;

Vector3 (*_GetUseSkillDirection)(void *instance, bool isTouchUse);
Vector3 GetUseSkillDirection(void *instance, bool isTouchUse){
    if (instance != NULL && AimSkill &&/* EnemyTarget.ConfigID == SizeIDHero */  EnemyTarget.ConfigID != 0) {
        
        
    if(aimSkill1 == 1) slot1 = 1;
    if(aimSkill1 == 0) slot1 = -1;
    
    if(aimSkill2 == 1) slot2 = 2;
    if(aimSkill2 == 0) slot2 = -1;
    
    if(aimSkill3 == 1) slot3 = 3;
    if(aimSkill3 == 0) slot3 = -1;
    
    
        if (EnemyTarget.myPos != Vector3::zero() && EnemyTarget.enemyPos != Vector3::zero() &&  skillSlot == slot1 || skillSlot == slot2 || skillSlot == slot3) {
            return calculateSkillDirection(EnemyTarget.myPos, 
            EnemyTarget.enemyPos,
             EnemyTarget.isMoving, 
             EnemyTarget.moveForward,
             EnemyTarget.currentSpeed);
        }
    }
    return _GetUseSkillDirection(instance, isTouchUse);
}

uintptr_t m_isCharging, m_currentSkillSlotType;

bool (*_UpdateLogic)(void *instance, int delta);
bool UpdateLogic(void *instance, int delta){
	if (instance != NULL) 
  {
		isCharging = *(bool *)((uintptr_t)instance + m_isCharging);
		skillSlot = *(int *)((uintptr_t)instance + m_currentSkillSlotType);
	}
	return _UpdateLogic(instance, delta);
}

void Aimbot(ImDrawList *draw)
 {
    if (AimSkill)
	{
		Quaternion rotation;
		float minDistance = std::numeric_limits<float>::infinity();
		float minDirection = std::numeric_limits<float>::infinity();
		float minHealth = std::numeric_limits<float>::infinity();
		float minHealth2 = std::numeric_limits<float>::infinity();
		float minHealthPercent = std::numeric_limits<float>::infinity();
		ActorLinker *Entity = nullptr;
		
		ActorManager *get_actorManager = KyriosFramework::get_actorManager();
		if (get_actorManager == nullptr) return;

		List<ActorLinker *> *GetAllHeros = get_actorManager->GetAllHeros();
		if (GetAllHeros == nullptr) return;

		ActorLinker **actorLinkers = (ActorLinker **) GetAllHeros->getItems();

		for (int i = 0; i < GetAllHeros->getSize(); i++)
		{
			ActorLinker *actorLinker = actorLinkers[(i *2) + 1];
			if (actorLinker == nullptr) continue;
		
			if (actorLinker->IsHostPlayer()) {
				rotation = actorLinker->get_rotation();
				EnemyTarget.myPos = actorLinker->get_position();
				EnemyTarget.ConfigID = actorLinker->ObjLinker()->ConfigID();
			}

			if (actorLinker->IsHostCamp() || !actorLinker->get_bVisible() || actorLinker->ValueComponent()->get_actorHp() < 1) continue;
		
			Vector3 EnemyPos = actorLinker->get_position();
			float Health = actorLinker->ValueComponent()->get_actorHp();
			float MaxHealth = actorLinker->ValueComponent()->get_actorHpTotal();
			int HealthPercent = (int)std::round((float)Health / MaxHealth * 100);
			float Distance = Vector3::Distance(EnemyTarget.myPos, EnemyPos);
            float Direction = SquaredDistance(
                RotateVectorByQuaternion(rotation), 
                calculateSkillDirection(
                    EnemyTarget.myPos, 
                    EnemyPos, 
                    actorLinker->isMoving(), 
                    actorLinker->get_logicMoveForward(),
                    actorLinker->MovementComponent()->get_maxSpeed() 
                )
            );			
			if (Distance < Radius)
			{
				if (aimType == 0)
				{
					if (HealthPercent < minHealthPercent)
					{
						Entity = actorLinker;
						minHealthPercent = HealthPercent;
					}
				
					if (HealthPercent == minHealthPercent && Health < minHealth2)
					{
						Entity = actorLinker;
						minHealth2 = Health;
						minHealthPercent = HealthPercent;
					}
				}
			
				if (aimType == 1 && Health < minHealth)
				{
					Entity = actorLinker;
					minHealth = Health;
				}
				
				if (aimType == 2 && Distance < minDistance)
				{
					Entity = actorLinker;
					minDistance = Distance;
				}
			
				if (aimType == 3 && Direction < minDirection && isCharging)
				{
					Entity = actorLinker;
					minDirection = Direction;
				}
			}
		}
		if (Entity == nullptr) {
            EnemyTarget.enemyPos = Vector3::zero();
            EnemyTarget.moveForward = Vector3::zero();
            EnemyTarget.ConfigID = 0;
            EnemyTarget.isMoving = false;
        }
		if (Entity != NULL)
		{
			float nDistance = Vector3::Distance(EnemyTarget.myPos, Entity->get_position());
			if (nDistance > Radius || Entity->ValueComponent()->get_actorHp() < 1)
			{
				EnemyTarget.enemyPos = Vector3::zero();
				EnemyTarget.moveForward = Vector3::zero();
				minDistance = std::numeric_limits<float>::infinity();
				minDirection = std::numeric_limits<float>::infinity();
				minHealth = std::numeric_limits<float>::infinity();
				minHealth2 = std::numeric_limits<float>::infinity();
				minHealthPercent = std::numeric_limits<float>::infinity();
				Entity = nullptr;
			}
					
			else
			{
				EnemyTarget.enemyPos =  Entity->get_position();
				EnemyTarget.moveForward = Entity->get_logicMoveForward();
				EnemyTarget.isMoving = Entity->isMoving();
                EnemyTarget.currentSpeed = Entity->MovementComponent()->get_maxSpeed();
			}
		}
		
		if (Entity != NULL && aimType == 3 && !isCharging)
		{
			EnemyTarget.enemyPos = Vector3::zero();
			EnemyTarget.moveForward = Vector3::zero();
			minDirection = std::numeric_limits<float>::infinity();
			Entity = nullptr;
		}
		
		if ((Entity != NULL || EnemyTarget.enemyPos != Vector3::zero()) && get_actorManager == nullptr)
		{
			EnemyTarget.enemyPos = Vector3::zero();
			EnemyTarget.moveForward = Vector3::zero();
			minDistance = std::numeric_limits<float>::infinity();
			minDirection = std::numeric_limits<float>::infinity();
			minHealth = std::numeric_limits<float>::infinity();
			minHealth2 = std::numeric_limits<float>::infinity();
			minHealthPercent = std::numeric_limits<float>::infinity();
			Entity = nullptr;

		}
        
		if (drawType != 0 && /*EnemyTarget.ConfigID == SizeIDHero */EnemyTarget.ConfigID != 0) {
                if (EnemyTarget.myPos != Vector3::zero() && EnemyTarget.enemyPos != Vector3::zero()) {
                    Vector3 futureEnemyPos = EnemyTarget.enemyPos;
                    if (EnemyTarget.isMoving) {
                        float distance = Vector3::Distance(EnemyTarget.myPos, EnemyTarget.enemyPos);
                        float bulletTime = distance / (Radius / DoLechAim); // Giữ nguyên logic tính bulletTime của bạn
                        futureEnemyPos += Vector3::Normalized(EnemyTarget.moveForward) * (EnemyTarget.currentSpeed / 1000.0f) * bulletTime;
                    }
                    Vector3 EnemySC = Camera::get_main()->WorldToScreen(futureEnemyPos);
                    Vector2 RootVec2 = Vector2(EnemySC.x, EnemySC.y);


                    if (EnemySC.z > 0) {
                        
                        RootVec2 = Vector2(EnemySC.x*kWidth,kHeight -EnemySC.y*kHeight);
                        ImVec2 imRootVec2 = ImVec2(RootVec2.x, RootVec2.y);
                        ImVec2 startLine = ImVec2(kWidth / 2 + 10, kHeight / 2);
                        float sizelaze = 6.0f;
                    if (drawType == 1) {
                        //Đường Kẻ
                        draw->AddLine(startLine, imRootVec2, ImColor(0, 0, 0, 128), LazeThemes + 2);
                        draw->AddLine(startLine, imRootVec2, ImColor(LazeElsu[0], LazeElsu[1], LazeElsu[2], LazeElsu[3]), LazeThemes);
                        // Tâm
                        // Circle
                        draw->AddCircle(imRootVec2, sizelaze, ImColor(ColorCrosshair[0], ColorCrosshair[1], ColorCrosshair[2], ColorCrosshair[3]), 100, 1.0f);
                       // Left line
                        draw->AddLine(ImVec2(imRootVec2.x - sizelaze, imRootVec2.y), ImVec2(imRootVec2.x - sizelaze / 2, imRootVec2.y), ImColor(ColorCrosshair[0], ColorCrosshair[1], ColorCrosshair[2], ColorCrosshair[3]), 1.0f);
                       // Right line
                        draw->AddLine(ImVec2(imRootVec2.x + sizelaze / 2, imRootVec2.y), ImVec2(imRootVec2.x + sizelaze, imRootVec2.y), ImColor(ColorCrosshair[0], ColorCrosshair[1], ColorCrosshair[2], ColorCrosshair[3]), 1.0f);
                       // Top line
                        draw->AddLine(ImVec2(imRootVec2.x, imRootVec2.y - sizelaze), ImVec2(imRootVec2.x, imRootVec2.y - sizelaze / 2), ImColor(ColorCrosshair[0], ColorCrosshair[1], ColorCrosshair[2], ColorCrosshair[3]), 1.0f);
                       // Bottom line
                        draw->AddLine(ImVec2(imRootVec2.x, imRootVec2.y + sizelaze / 2), ImVec2(imRootVec2.x, imRootVec2.y + sizelaze), ImColor(ColorCrosshair[0], ColorCrosshair[1], ColorCrosshair[2], ColorCrosshair[3]), 1.0f);
                        // Dot point
                        draw->AddRectFilled(ImVec2(imRootVec2.x - 0.5f, imRootVec2.y - 0.5f), ImVec2(imRootVec2.x + 0.5f, imRootVec2.y + 0.5f), IM_COL32(0, 255, 255, 255));
                        }

                    if (drawType == 2 && isCharging && (skillSlot == slot1 || skillSlot == slot2 || skillSlot == slot3)) {
                         //Đường Kẻ
                         draw->AddLine(startLine, imRootVec2, ImColor(0, 0, 0, 128), LazeThemes + 2);
                         draw->AddLine(startLine, imRootVec2, ImColor(LazeElsu[0], LazeElsu[1], LazeElsu[2], LazeElsu[3]), LazeThemes);
                         // Tâm
                        // Circle
                         draw->AddCircle(imRootVec2, sizelaze, ImColor(ColorCrosshair[0], ColorCrosshair[1], ColorCrosshair[2], ColorCrosshair[3]), 100, 1.0f);
                        // Left line
                         draw->AddLine(ImVec2(imRootVec2.x - sizelaze, imRootVec2.y), ImVec2(imRootVec2.x - sizelaze / 2, imRootVec2.y), ImColor(ColorCrosshair[0], ColorCrosshair[1], ColorCrosshair[2], ColorCrosshair[3]), 1.0f);
                        // Right line
                         draw->AddLine(ImVec2(imRootVec2.x + sizelaze / 2, imRootVec2.y), ImVec2(imRootVec2.x + sizelaze, imRootVec2.y), ImColor(ColorCrosshair[0], ColorCrosshair[1], ColorCrosshair[2], ColorCrosshair[3]), 1.0f);
                        // Top line
                         draw->AddLine(ImVec2(imRootVec2.x, imRootVec2.y - sizelaze), ImVec2(imRootVec2.x, imRootVec2.y - sizelaze / 2), ImColor(ColorCrosshair[0], ColorCrosshair[1], ColorCrosshair[2], ColorCrosshair[3]), 1.0f);
                        // Bottom line
                         draw->AddLine(ImVec2(imRootVec2.x, imRootVec2.y + sizelaze / 2), ImVec2(imRootVec2.x, imRootVec2.y + sizelaze), ImColor(ColorCrosshair[0], ColorCrosshair[1], ColorCrosshair[2], ColorCrosshair[3]), 1.0f);
                        // Dot point
                         draw->AddRectFilled(ImVec2(imRootVec2.x - 0.5f, imRootVec2.y - 0.5f), ImVec2(imRootVec2.x + 0.5f, imRootVec2.y + 0.5f), IM_COL32(0, 255, 255, 255));
                        }
                    }
                 }
               }
            }
	    }

static bool unlockskin = false;
static bool unlocksss = false;
static bool enableBanList = false;


static std::vector<uint64_t> bannedSkins = { 
   
    14111, //Lauriel - Nguyên Vệ Thần 
    11113, //Violet - Huyết Ma Thần
    11119, //Violet - Vọng Nguyệt Long Cơ
    11110, //Violet - Vợ Người Ta
    11120, //Violet - Nobara
    16710,
    16711,
    16712,
    13613,
    10620,
    10611,
    15013,
    15015,
    50108,
    50112,
    50119,
    13210,
    11812,
    11816,
    12912,
    54307,
    54308,
    54804,
    52007,
    52011,
    11607,
    11610,
    11611,
    11614,
    11616,
    13011,
    13015,
    13116,
    13118,
    13111,
    10912,
    10915,
    15212,
    14213,
    10709,
    10714,
    59901,
    15412,
    15406,
    15413,
    55304,
    52414,
    59802,
    13706,
    13705,
    19009
};


bool isBanned(uint32_t heroId, uint16_t skinId) {
    if (!enableBanList) return false; // nếu tắt check thì luôn trả về false
    uint64_t key = heroId * 100 + skinId;
    for (auto k : bannedSkins) if (k == key) return true;
    return false;
}

static int currentHeroId = 0;
static int currentSkinId = 0;
static int Skill5View = 0;
static int MowenIDView = 0;
static int UnlockLinhs = 0;


static int showTitleID = 0;
static int showTitleMask = 0;
static int legendTitleFlag = 0;


void DrawIntStepper(const char* label, int* value, int minValue = 0, int maxValue = 100, int step = 1) {
    ImGui::Text("%s", label);
    ImGui::SameLine();
    
    if (ImGui::Button("-")) {
        *value = (*value - step >= minValue) ? *value - step : minValue;
    }

    ImGui::SameLine();
    ImGui::Text("%d", *value);
    ImGui::SameLine();

    if (ImGui::Button("+")) {
        *value = (*value + step <= maxValue) ? *value + step : maxValue;
    }
}

void DrawHeroSkinInfo() {
    ImGui::Text("Hero ID: %u", currentHeroId);
    ImGui::SameLine();
    ImGui::Text("Skin ID: %u", currentSkinId);
    //ImGui::SameLine();
    //ImGui::Text("TypeKill ID: %d", TypeKill);
    ImGui::SameLine();
    ImGui::Text("Skill ID: %d", Skill5View);
    //ImGui::SameLine();
   // ImGui::Text("Lính ID: %d", UnlockLinhs);
}


typedef int32_t TdrErrorType;

class TdrReadBuf {
public:
    std::vector<uint8_t> beginPtr;
    int32_t position;
    int32_t length;
    bool isNetEndian;
    bool isUseCache;
};

namespace CSProtocol {
class COMDT_HERO_COMMON_INFO {
public:
    uint32_t getHeroID() { return *(uint32_t*)((uintptr_t)this + GetFieldOffset("AovTdr.dll","CSProtocol","COMDT_HERO_COMMON_INFO","dwHeroID")); }
    uint16_t getSkinID() { return *(uint16_t*)((uintptr_t)this + GetFieldOffset("AovTdr.dll","CSProtocol","COMDT_HERO_COMMON_INFO","wSkinID")); }
    void setSkinID(uint16_t id) { *(uint16_t*)((uintptr_t)this + GetFieldOffset("AovTdr.dll","CSProtocol","COMDT_HERO_COMMON_INFO","wSkinID")) = unlocksss ? 1 : id; }
};

struct saveData {
    static uint32_t heroId;
    static uint16_t skinId;
    static bool enable;
    static std::vector<std::pair<COMDT_HERO_COMMON_INFO*, uint16_t>> backup;

    static void set(uint32_t h, uint16_t s) { heroId = h; skinId = s; }
    static void reset() { for (auto& p : backup) p.first->setSkinID(p.second); backup.clear(); }
};

uint32_t saveData::heroId = 0;
uint16_t saveData::skinId = 0;
bool saveData::enable = false;
std::vector<std::pair<COMDT_HERO_COMMON_INFO*, uint16_t>> saveData::backup;

}

using namespace CSProtocol;

// Hook hàm
TdrErrorType (*old_unpack)(COMDT_HERO_COMMON_INFO*, TdrReadBuf&, int32_t);
void hook_unpack(COMDT_HERO_COMMON_INFO* inst) {
    if (!saveData::enable) return;
    uint32_t hid = inst->getHeroID();
    uint16_t sid = inst->getSkinID();
    saveData::backup.emplace_back(inst, sid);
    if (hid == saveData::heroId && !isBanned(hid, saveData::skinId)) inst->setSkinID(saveData::skinId);
}

TdrErrorType unpack(COMDT_HERO_COMMON_INFO* inst, TdrReadBuf& buf, int32_t ver) {
    auto r = old_unpack(inst, buf, ver);
    if (unlockskin || unlocksss && !isBanned(inst->getHeroID(), inst->getSkinID())) hook_unpack(inst);
    return r;
}

void (*old_RefreshHeroPanel)(void*, bool, bool, bool);
void (*old_OnClickSelectHeroSkin)(void*, uint32_t, uint32_t);
void OnClickSelectHeroSkin(void* inst, uint32_t hid, uint32_t sid) {
    if (unlockskin || unlocksss && hid && !isBanned(hid, sid)) old_RefreshHeroPanel(inst, 1, 1, 1);
    old_OnClickSelectHeroSkin(inst, hid, sid);
}

bool (*old_IsCanUseSkin)(void*, uint32_t, uint32_t);
bool IsCanUseSkin(void* inst, uint32_t hid, uint32_t sid) {
    if (unlockskin || unlocksss) {
        if (!isBanned(hid, sid)) { saveData::set(hid, sid); return true; }
        return false;
    }
    return old_IsCanUseSkin(inst, hid, sid);
}

bool (*old_IsHaveHeroSkin)(uint32_t, uint32_t, bool);
bool IsHaveHeroSkin(uint32_t hid, uint32_t sid, bool t = false) {
    return unlockskin || unlocksss ? !isBanned(hid, sid) : old_IsHaveHeroSkin(hid, sid, t);
}

uint32_t (*old_GetHeroWearSkinId)(void*, uint32_t);
uint32_t GetHeroWearSkinId(void* inst, uint32_t hid) {
    currentHeroId = hid;
    uint32_t sid = unlockskin || unlocksss ? (isBanned(hid, saveData::skinId) ? 0 : saveData::skinId) : old_GetHeroWearSkinId(inst, hid);
    currentSkinId = sid;
    if (unlockskin || unlocksss) saveData::enable = true;
    return sid;
}


struct SkinElement {};  // ⚠️ Tùy cấu trúc thực tế
SkinElement (*_GetSkin)(void* instance, int skinId);
SkinElement GetSkin(void* instance, int skinId) {
    if (unlocksss && instance && currentSkinId != 0) {
        return _GetSkin(instance, currentSkinId); 
    }
    return _GetSkin(instance, skinId);
}

// ✅ Hook get_szSkinPicID → sửa ID ảnh skin
string (*_get_szSkinPicID)(void* instance);
string get_szSkinPicID(void* instance) {
    if (unlocksss && instance && currentHeroId && currentSkinId) {
        *(int*)((uintptr_t)instance + 0x10) = currentHeroId * 100 + currentSkinId;
    }
    return _get_szSkinPicID(instance);
}



void *(*GetAwakeSkinData)(uint32_t wakeSkinID);
bool (*_IsAwakeSkin)(uint32_t wakeSkinID);
bool IsAwakeSkin(uint32_t wakeSkinID) {
	if (_IsAwakeSkin(wakeSkinID))
	{
		void *awakeSkin = GetAwakeSkinData(wakeSkinID);
		
		if (awakeSkin != nullptr)
		{
			*(uint8_t *)((uintptr_t)awakeSkin + GetFieldOffset("AovTdr.dll", "CSProtocol", "COMDT_HERO_SKIN_WAKE_DATA", "bCurWearLevel")) = 5;
			*(uint8_t *)((uintptr_t)awakeSkin + GetFieldOffset("AovTdr.dll", "CSProtocol", "COMDT_HERO_SKIN_WAKE_DATA", "bWakeLevel")) = 5;
		    *(uint64_t *)((uintptr_t)awakeSkin + GetFieldOffset("AovTdr.dll", "CSProtocol", "COMDT_HERO_SKIN_WAKE_DATA", "ullWakeFeatureMask")) = 2147483647;
			*(uint64_t *)((uintptr_t)awakeSkin + GetFieldOffset("AovTdr.dll", "CSProtocol", "COMDT_HERO_SKIN_WAKE_DATA", "ullWearFeatureMask")) = 2147483647;
		
		}
	}
	return _IsAwakeSkin(wakeSkinID);
}

TdrErrorType (*_unpack1)(uintptr_t instance, void **srcBuf, uint32_t cutVer);
TdrErrorType unpack1(uintptr_t instance, void **srcBuf, uint32_t cutVer){
	auto result = _unpack1(instance, srcBuf, cutVer);
	if (result) return result;
	
	*(uint8_t *)((uintptr_t)instance + GetFieldOffset("AovTdr.dll", "CSProtocol", "COMDT_CHOICEHERO", "bSkinWakeLevel")) = 5;
	
	*(uint64_t *)((uintptr_t)instance + GetFieldOffset("AovTdr.dll", "CSProtocol", "COMDT_CHOICEHERO", "ullSkinWakeFeatureMask")) = 2147483647;
	
	
	return result;
}


EntityManager *espManager;
EntityManager *ActorLinker_enemy;

std::map<uint64_t, Vector3> previousEnemyPositions;
Vector3 Lerp(Vector3 &a,const Vector3 &b, float t) 
{
    if(Vector3::Distance(a,b) > 1) a = b;
    return Vector3
    {
        a.x + (b.x - a.x) * t,
        a.y + (b.y - a.y) * t,
        a.z + (b.z - a.z) * t
    };
}

ImVec2 GetPlayerPosition(Vector3 Pos)
{
    Vector3 PosSC = Camera::get_main()->WorldToViewportPoint(Pos);
    ImVec2 Pos_Vec2 = ImVec2(kWidth - PosSC.x*kWidth, PosSC.y*kHeight);
    if (PosSC.z > 0) 
    {
        Pos_Vec2 = ImVec2(PosSC.x*kWidth, kHeight - PosSC.y*kHeight);
    }
    return Pos_Vec2;
}

bool (*Reqskill)(void *ins);
bool (*Reqskill2)(void *ins,bool bForce);

uintptr_t (*LActorRoot_LHeroWrapper)(void *instance);
int (*LActorRoot_COM_PLAYERCAMP)(void *instance);

bool (*LObjWrapper_get_IsDeadState)(void *instance);
bool (*LObjWrapper_IsAutoAI)(void *instance);
int (*ValuePropertyComponent_get_actorHp)(void *instance);
int (*ValuePropertyComponent_get_actorHpTotal)(void *instance);
int (*ValueLinkerComponent_get_actorEpTotal)(void *instance);
int (*ValueLinkerComponent_get_actorSoulLevel)(void *instance);
int (*ValuePropertyComponent_get_actorSoulLevel)(void *instance);
int (*ValuePropertyComponent_get_actorEp)(void *instance);
int (*ValuePropertyComponent_get_actorEpTotal)(void *instance);

void* (*get_VHostLogic)();
void* (*get_playerCenter)();
void* (*GetMasterRoleInfo)(void* instance);
void* (*GetCurrentRankDetail)(void* instance);

int (*ActorLinker_COM_PLAYERCAMP)(void *instance);
bool (*ActorLinker_IsHostPlayer)(void *instance);
int (*ActorLinker_ActorTypeDef)(void *instance);
Vector3 (*ActorLinker_getPosition)(void *instance);
bool (*ActorLinker_get_bVisible)(void *instance);

void (*old_ActorLinker_ActorDestroy)(void *instance);
void ActorLinker_ActorDestroy(void *instance) {
    if (instance != NULL) {
        old_ActorLinker_ActorDestroy(instance);
		ActorLinker_enemy->removeEnemyGivenObject(instance);
        if (espManager->MyPlayer==instance){
            espManager->MyPlayer=NULL;
        }
    }
}
void (*old_LActorRoot_ActorDestroy)(void *instance,bool bTriggerEvent);
void LActorRoot_ActorDestroy(void *instance, bool bTriggerEvent) {
    if (instance != NULL) {
        old_LActorRoot_ActorDestroy(instance, bTriggerEvent);
        espManager->removeEnemyGivenObject(instance);
        
    }
}

int dem(int num){
    int div=1, num1 = num;
    while (num1 != 0) {
        num1=num1/10;
        div=div*10;
    }
    return div;
}

Vector3 VInt2Vector(VInt3 location, VInt3 forward){
    return Vector3((float)(location.X*dem(forward.X)+forward.X)/(1000*dem(forward.X)), (float)(location.Y*dem(forward.Y)+forward.Y)/(1000*dem(forward.Y)), (float)(location.Z*dem(forward.Z)+forward.Z)/(1000*dem(forward.Z)));
}

Vector3 VIntVector(VInt3 location)
{
    return Vector3((float)(location.X) / (1000), (float)(location.Y) / (1000), (float)(location.Z) / (1000));
}

bool ShowCD = false;

typedef struct _monoString {
    void* klass;
    void* monitor;
    int length;    
    char chars[1];   // UTF-16LE data

    int getLength() {
        return length;
    }

    char* getChars() {
        return chars;
    }

    NSString* toNSString() {
        return [[NSString alloc] initWithBytes:(const void *)(chars)
                                        length:(NSUInteger)(length * 2)
                                      encoding:NSUTF16LittleEndianStringEncoding];
    }

    char* toCString() {
        NSString* v1 = toNSString();
        return (char*)([v1 UTF8String]);  
    }

    std::string toString() {
        return std::string(toCString());
    }

} monoString;


monoString *CreateMonoString(const char *str) {
    monoString *(*String_CreateString)(void *instance, const char *str, int startIndex, int length) = (monoString *(*)(void *, const char*, int, int))GetMethodOffset("mscorlib.dll", "System", "String", "CreateString", 3);
    return String_CreateString(NULL, str, 0, (int)strlen(str));
}

uintptr_t botro, cphutro, c1, c2, c3;
uintptr_t Skill5OK; // ID Bổ Trợ
uintptr_t SkillSlotOK; // Skill (slot)
uintptr_t SkillTime; // Thời Gian Skill
uintptr_t MowenIDzz; //ID Phù Trợ

int Skill5_C3 = 0;
int Skill5BT = 0;
int Skill5ID = 0;

void* myLActorRoot = nullptr;
void* myActor = nullptr;
void* Lactor = nullptr;
int myId = 0;


Vector3 CurrentPosition;
bool autott;
bool rongta;
bool onlymt = false;

float Rangeskill0;
float Rangeskill1;
float Rangeskill2;
float Rangeskill3;
float Rangeskill5;

void* Req0 = nullptr;
void* Req1 = nullptr;
void* Req2 = nullptr;
void* Req3 = nullptr;
void* Req4 = nullptr;
void* Req5 = nullptr;
void* Req6 = nullptr;
void* Req9 = nullptr;

bool bangsuong;
bool autobocpha;
bool hoimau;
bool capcuuz;

int slot;
float mauphutro = 13.79f;  // % máu
float maubotro = 12.67f;    // % máu
float maucapcuu = 18.45f;  // % máu
float mauhoimau = 16.2f; // % máu

std::unordered_map<uintptr_t, std::string> nameORG;
uintptr_t (*AsHero)(void*);
void (*SetPlayerName)(void*, monoString*, monoString*, bool, monoString*);
void _SetPlayerName(void* instance, monoString* playerName, monoString* prefixName, bool isGuideLevel, monoString* customName) {
    if (!instance) return;

    uintptr_t instAddr = reinterpret_cast<uintptr_t>(instance);
    std::string playerNameStr = playerName->toString();

    if (nameORG.find(instAddr) == nameORG.end()) {
        nameORG[instAddr] = playerNameStr;
    }
    SetPlayerName(instance, playerName, prefixName, isGuideLevel, customName);
}

void (*old_Update)(void*);
void AUpdate(void* instance) {
    if (!instance) return;

    uintptr_t SkillControl = AsHero(instance);
    uintptr_t HudControl = *(uintptr_t*)((uintptr_t)instance + GetFieldOffset("Project_d.dll", "Kyrios.Actor", "ActorLinker", "HudControl"));


    ActorLinker* actor = (ActorLinker*)instance;
     bool isMyHud = (actor->get_playerId() == myId);  // Dùng myId để kiểm tra
    if(actor->IsHostPlayer()){
        myActor = (void*) instance;
     }



   if (HudControl && SkillControl) {
    int skill1Cd = *(int*)(SkillControl + (c1 - 0x4)) / 1000;
    int skill2Cd = *(int*)(SkillControl + (c2 - 0x4)) / 1000;
    int skill3Cd = *(int*)(SkillControl + (c3 - 0x4)) / 1000;
    int skill4Cd = *(int*)(SkillControl + (botro - 0x4)) / 1000;

    if (ShowCD) 
    {
     std::string sk1 = (skill1Cd == 0) ? " [ A ] " : " [ " + std::to_string(skill1Cd) + " ] ";
     std::string sk2 = (skill2Cd == 0) ? " [ O ] " : " [ " + std::to_string(skill2Cd) + " ] ";
     std::string sk3 = (skill3Cd == 0) ? " [ V ] " : " [ " + std::to_string(skill3Cd) + " ] ";
     std::string sk4 = (skill4Cd == 0) ? " [ VIP ] " : " [ " + std::to_string(skill4Cd) + " ] ";

     monoString* playerName = CreateMonoString((sk1 + sk2 + sk3).c_str());
     monoString* prefixName = CreateMonoString(sk4.c_str());
     monoString* custom = CreateMonoString("");

      _SetPlayerName((void*)HudControl, playerName, prefixName, true, custom);
    } 
    else {
            std::string originalName = "Player";
            auto it = nameORG.find(HudControl);
            if (it != nameORG.end()) {
                originalName = it->second;
            }
            monoString* playerName = CreateMonoString(originalName.c_str());
            monoString* prefixName = CreateMonoString("");
            monoString* custom = CreateMonoString("");

            _SetPlayerName((void*)HudControl, playerName, prefixName, false, custom);
      }
    }
    // Gọi lại hàm update gốc
    old_Update(instance);
        
    if (ActorLinker_ActorTypeDef(instance)== 0){
        if (ActorLinker_IsHostPlayer(instance)== true){
            espManager->tryAddMyPlayer(instance);
              Lactor = instance;
            } else {
				if(espManager->MyPlayer != NULL) {
					if(ActorLinker_COM_PLAYERCAMP(espManager->MyPlayer) != ActorLinker_COM_PLAYERCAMP(instance)){
						ActorLinker_enemy->tryAddEnemy(instance);
					}
				}
           }
     }
}


int AutoWinTowerMode = 0; // 1: Tắt, 2: Trụ địch, 3: Trụ mình
bool AutoWinz = false;
bool IsNativeObjectAlive(void *unity_obj) {
    return (unity_obj != nullptr && (*(uintptr_t *)((uintptr_t)unity_obj + GetFieldOffset(oxorany("UnityEngine.CoreModule.dll"), oxorany("UnityEngine"), oxorany("Object"), oxorany("m_CachedPtr"))))); // class Object -> private IntPtr m_CachedPtr; // 0x8
}

void (*old_LActorRoot_UpdateLogic)(void *instance, int delta);
void LActorRoot_UpdateLogic(void *instance, int delta) {
    if (instance != NULL) {
        old_LActorRoot_UpdateLogic(instance, delta);

    static const auto AsOrgan = (void * (*)(void *)) GetMethodOffset(oxorany("Project.Plugins_d.dll"), oxorany("NucleusDrive.Logic"), oxorany("LActorRoot"), oxorany("AsOrgan"), 0);
    static const auto IsOwner = (bool (*)(void *))GetMethodOffset(oxorany("Project.Plugins_d.dll"), oxorany("NucleusDrive.Logic"), oxorany("LActorRoot"), oxorany("IsOwner"), 1);
    static const auto get_isTower = (bool (*)(void *)) GetMethodOffset(oxorany("Project.Plugins_d.dll"), oxorany("NucleusDrive.Logic"), oxorany("LOrganWrapper"), oxorany("get_isTower"), 0);
    static const auto get_actorHp = (int (*)(void *)) GetMethodOffset(oxorany("Project.Plugins_d.dll"), oxorany("NucleusDrive.Logic"), oxorany("ValuePropertyComponent"), oxorany("get_actorHp"), 0);
    static const auto set_actorHp = (int (*)(void *, int)) GetMethodOffset(oxorany("Project.Plugins_d.dll"), oxorany("NucleusDrive.Logic"), oxorany("ValuePropertyComponent"), oxorany("set_actorHp"), 1);
    static const auto get_objCamp = (int (*)(void *)) GetMethodOffset(oxorany("Project_d.dll"), oxorany("Kyrios.Actor"), oxorany("ActorLinker"), oxorany("get_objCamp"), 0);
    static const auto GiveMyEnemyCamp = (int (*)(void *)) GetMethodOffset(oxorany("Project.Plugins_d.dll"), oxorany("NucleusDrive.Logic"), oxorany("LActorRoot"), oxorany("GiveMyEnemyCamp"), 0);

    if (instance && IsNativeObjectAlive(myActor)) {
        if (GiveMyEnemyCamp(instance) != get_objCamp(myActor)) {
            myLActorRoot = instance;
        }
        if (AutoWinz){
            void *organ = AsOrgan(instance);
            if (organ && !get_isTower(organ)){
                void *valueComponent = *(void **)((uintptr_t)instance + GetFieldOffset(oxorany("Project.Plugins_d.dll"), oxorany("NucleusDrive.Logic"), oxorany("LActorRoot"), oxorany("ValueComponent")));
                if (valueComponent && get_actorHp(valueComponent) > 0) {
                    bool bEnemy = GiveMyEnemyCamp(instance) == get_objCamp(myActor);
                    if (AutoWinTowerMode == 0 && bEnemy) set_actorHp(valueComponent, 0);
                    if (AutoWinTowerMode == 1 && !bEnemy) set_actorHp(valueComponent, 0);
                }
            }
        }
    }

        if (espManager->MyPlayer!=NULL) {
            if (LActorRoot_LHeroWrapper(instance)!=NULL && LActorRoot_COM_PLAYERCAMP(instance) == ActorLinker_COM_PLAYERCAMP(espManager->MyPlayer)) {
				espManager->tryAddEnemy(instance);
			}
		}
    }
}



struct BugSkillInfo {
    int skillID = 0;
    float rangeOrigin = 0.0f;
    float rangeFuture = 0.0f;

    BugSkillInfo() = default;

    BugSkillInfo(int id, float origin, float future)
        : skillID(id), rangeOrigin(origin), rangeFuture(future) {}
};

BugSkillInfo GetEnemySkillRangeByID(int ConfigID)
{
    BugSkillInfo info;

    switch (ConfigID)
    {
        case 106: info = BugSkillInfo(2, 6.99f, 8.79f); break; // Krixi
        case 107: info = BugSkillInfo(3, 6.40f, 7.00f); break; // Zepphy
        case 110: info = BugSkillInfo(1, 7.98f, 8.88f); break; // Kahhi
        case 111: info = BugSkillInfo(2, 8.99f, 10.79f); break; // Violet
        case 118: info = BugSkillInfo(118, 8.98f, 9.88f); break; // Alice
        case 119: info = BugSkillInfo(1, 7.49f, 9.49f); break; // Mganga
        case 123: info = BugSkillInfo(3, 11.90f, 13.19f); break; // Maloch
        case 124: info = BugSkillInfo(2, 7.99f, 8.69f); break; // Ignig
        case 127: info = BugSkillInfo(1, 8.99f, 10.99f); break; // Azenkka
        case 135: info = BugSkillInfo(2, 3.49f, 7.69f); break; // Thane
        case 137: info = BugSkillInfo(3, 19.90f, 21.99f); break; // Paine
        case 144: info = BugSkillInfo(1, 6.40f, 8.00f); break; // Tarra
        case 146: info = BugSkillInfo(2, 6.90f, 7.69f); break; // Zill
        case 148: info = BugSkillInfo(2, 7.98f, 8.75f); break; // Preyta
        case 149: info = BugSkillInfo(2, 5.90f, 6.49f); break; // Xeniel
        case 150: info = BugSkillInfo(1, 5.49f, 7.09f); break; // Nak
        case 152: info = BugSkillInfo(152, 7.98f, 8.68f); break; // Điêu thuyền
        case 156: info = BugSkillInfo(2, 7.98f, 8.68f); break; // Aleister
        case 162: info = BugSkillInfo(3, 6.90f, 7.50f); break; // Krinak
        case 169: info = BugSkillInfo(2, 5.90f, 6.39f); break; // Slimz
        case 170: info = BugSkillInfo(3, 7.50f, 8.18f); break; // Moren
        case 171: info = BugSkillInfo(2, 6.49f, 7.09f); break; // Cresht
        case 173: info = BugSkillInfo(3, 8.98f, 9.70f); break; // Fennik
        case 177: info = BugSkillInfo(2, 10.98f, 12.07f); break; // Lindis
        case 187: info = BugSkillInfo(2, 6.98f, 7.68f); break; // Arum
        case 191: info = BugSkillInfo(3, 8.00f, 8.50f); break; // Rouie
        case 192: info = BugSkillInfo(2, 8.99f, 9.79f); break; // Celica
        case 503: info = BugSkillInfo(3, 5.49f, 7.69f); break; // Zuka
        case 510: info = BugSkillInfo(1, 8.00f, 8.75f); break; // Liliana
        case 519: info = BugSkillInfo(1, 8.99f, 10.99f); break; // Anette
        case 522: info = BugSkillInfo(3, 8.00f, 10.40f); break; // Enrroll
        case 523: info = BugSkillInfo(523, 8.99f, 10.99f); break; // Darcy
        case 526: info = BugSkillInfo(3, 7.90f, 8.60f); break; // Ishar
        case 530: info = BugSkillInfo(2, 10.40f, 11.50f); break; // Dirak
        case 531: info = BugSkillInfo(1, 4.90f, 7.09f); break; // Keera
        case 534: info = BugSkillInfo(2, 6.48f, 7.08f); break; // Dextra
        case 535: info = BugSkillInfo(2, 8.40f, 9.20f); break; // ??? (Chưa rõ tên)
        case 536: info = BugSkillInfo(1, 5.40f, 7.19f); break; // Aoi
        case 539: info = BugSkillInfo(1, 8.99f, 11.49f); break; // Lorion
        case 541: info = BugSkillInfo(2, 9.48f, 9.88f); break; // Bonnie
        case 542: info = BugSkillInfo(3, 7.90f, 8.80f); break; // Tachi
        default: info = BugSkillInfo(0, 0.0f, 0.0f); break;
    }

    return info;
}


void (*_SkillControlIndicator)(void *ins,int del);
void SkillControlIndicator(void *ins,int del) {
if (ins != NULL && BugSkillRange) {

     auto p_skillSlot = *(uintptr_t *)((uintptr_t)ins + GetFieldOffset(oxorany("Project_d.dll"), oxorany("Assets.Scripts.GameLogic"), oxorany("SkillControlIndicator"), oxorany("skillSlot")));
     if (p_skillSlot != NULL) {
        
    int skSlot = *(int *)((uintptr_t) p_skillSlot + GetFieldOffset(oxorany("Project_d.dll"), oxorany("Assets.Scripts.GameLogic"), oxorany("SkillSlot"), oxorany("SlotType")));

if (EnemyTarget.ConfigID ) { 
    // Sử dụng struct BugSkillInfo để lấy thông tin skill
    BugSkillInfo enemyInfo = GetEnemySkillRangeByID(EnemyTarget.ConfigID);
    
    // Kiểm tra nếu skill ID khớp với slot hiện tại
    if (enemyInfo.skillID == skSlot || enemyInfo.skillID == EnemyTarget.ConfigID) {
        
        Vector3 *useSkillPosition = (Vector3 *)((uintptr_t)ins + GetFieldOffset(oxorany("Project_d.dll"), oxorany("Assets.Scripts.GameLogic"), oxorany("SkillControlIndicator"), oxorany("useSkillPosition")));
        Vector3 *useOffsetPosition = (Vector3 *)((uintptr_t)ins + GetFieldOffset(oxorany("Project_d.dll"), oxorany("Assets.Scripts.GameLogic"), oxorany("SkillControlIndicator"), oxorany("useOffsetPosition")));
        Vector3 *useOffsetPosition2 = (Vector3 *)((uintptr_t)ins + GetFieldOffset(oxorany("Project_d.dll"), oxorany("Assets.Scripts.GameLogic"), oxorany("SkillControlIndicator"), oxorany("useOffsetPosition")));

        if (useOffsetPosition != NULL && useOffsetPosition2 != NULL) {
            // Logic kiểm tra distance trước khi aim (sửa theo logic đúng)
            Vector3 useOffset = *useOffsetPosition;
            float Distance = Vector2::Distance({0, 0}, {useOffset.x, useOffset.z});
            Vector3 newOffset = useOffset;
            
            // Nếu distance >= rangeOrigin thì sử dụng rangeFuture
            if(Distance >= enemyInfo.rangeOrigin) {
                useOffset.Normalize();
                newOffset = useOffset * enemyInfo.rangeFuture;
            }
            // Ngược lại giữ nguyên useOffset
            
            // Cập nhật position với newOffset đã tính toán
            *useOffsetPosition2 = newOffset;
             }
            }
           }
        }
}

    return _SkillControlIndicator(ins,del);
}



void (*_Skslot)(void *ins, int del);
void Skslot(void *ins, int del) {
  if (ins != NULL) {
    slot = *(int *)((uintptr_t)ins + GetFieldOffset(oxorany("Project_d.dll"), oxorany("Assets.Scripts.GameLogic"), oxorany("SkillSlot"), oxorany("SlotType")));//// public SkillSlotType SlotType; // 0x80
    void* skillControl = *(void**) ((uintptr_t)ins + GetFieldOffset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameLogic"),oxorany("SkillSlot"),oxorany("skillIndicator")));
    int range = *(int*) ((uintptr_t)skillControl + GetFieldOffset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameLogic"),oxorany("SkillControlIndicator"),oxorany("curindicatorDistance")));
    Vector3 currentPosition = *(Vector3*) ((uintptr_t)skillControl + GetFieldOffset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameLogic"),oxorany("SkillControlIndicator"),oxorany("useSkillDirection")));

     if(slot == 1)//Chiêu 1
    { 
     Req1 = ins;
     Rangeskill1 = (float)range/1000.0f;
    }
    if(slot == 2) //Chiêu 2
    { 
     Req2 = ins;
     Rangeskill2 = (float)range/1000.0f;
    }
    if(slot == 3) //Chiêu 3
    { 
     Req3 = ins;
     Rangeskill3 = (float)range/1000.0f;
    }
    if(slot == 4) //Hồi máu
    { Req4 = ins; }

    if(slot == 5) //bổ trợ
    { Req5 = ins; }

    if(slot == 6) //Biến Về
    { Req6 = ins; }

    if(slot == 9) //Phù Trợ
    { Req9 = ins; }

    if(slot == 0) //Đánh Thường
    { Req0 = ins;
    Rangeskill0 = (float)range/1000.0f;
    }
    
    if(slot == skillSlot)
    { CurrentPosition = currentPosition; }


     if (Lactor != NULL) 
    {
     // Kiểu loại điều khiển
     auto SkillControl = AsHero(Lactor); 
     // Lấy ID của bổ trợ
     Skill5View = *(int*)(SkillControl + Skill5OK);   
     MowenIDView = *(int*)(SkillControl + MowenIDzz);

     }
 /*
80109 tốc Hành giầy 
80108 bộc phá
80104 trừng trị
80110 giảm thiết
80102 cấp cứu
80105 suy ngược
80103 ngất ngư
80107 thanh tẩy
80115 tốc biến

uint mowenID = *(uint*)(SkillControl + 0xF0);

20303 phù trợ doila sp
20302 hồi máu xanh
30304 hồi máu xanh
10301 hồi máu xanh biển
*/

/*
   if(ins != NULL && BugSkillRange)
    {
        // Lấy SkillControlIndicator từ instance
        void* SkillControlIndicator = *(void**)((uintptr_t)ins + GetFieldOffset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameLogic"),oxorany("SkillSlot"),oxorany("skillIndicator"))); // Lấy SkillIndi của Class SkillSlot (instance của LateUpdate)
       // if(SkillControlIndicator != NULL) {
            Vector3 useOffsetPosition = *(Vector3*)((uintptr_t)SkillControlIndicator + GetFieldOffset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameLogic"),oxorany("SkillControlIndicator"),oxorany("useOffsetPosition")));
            Vector3 useSkillPosition = *(Vector3*)((uintptr_t)SkillControlIndicator + GetFieldOffset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameLogic"),oxorany("SkillControlIndicator"),oxorany("useSkillPosition")));
            Vector3 myPos = ActorLinker_getPosition(espManager->MyPlayer);
            Vector3 localDir = useOffsetPosition.Normalize();
            Vector3 newOffset = localDir * 7.6f;
            useOffsetPosition = myPos + newOffset;
        //}
    }
*/



//======================== Bug Skill Okeerre

/*

// Danh sách các tướng được hỗ trợ bug range
std::map<int, float> tamdanhList = {
    {135, 7.6f},    // Thane
    {531, 7.1f},    // Keera
    {123, 13.0f},   // Maloch
    {542, 8.8f},    // Tachi
    {137, 22.0f},   // Paine
    {503, 7.7f},    // Zuka
    {150, 7.1f},    // Nakroth
    {146, 7.5f},    // Zill
    {169, 6.4f},    // Slimz
    {536, 7.2f},    // Aoi
    {149, 6.5f},    // Xeniel
    {171, 7.0f},    // Cresht
    {522, 10.4f},   // Errol
    {510, 8.75f},   // Liliana
    {106, 8.75f},   // Krixi
    {152, 9.5f},    // Mganga
    {716, 8.8f},    // Điêu Thuyền
    {539, 11.0f},   // Lorion
    {523, 10.8f},   // D’Arcy
    {111, 10.8f},   // Violet
    {192, 9.8f},    // Celica
    {118, 9.8f},    // Alice
    {519, 11.0f},   // Annette
    {191, 10.9f},   // Rouie
    {541, 9.8f},    // Bonnie
    {127, 11.0f},   // Azzen’Ka
    {526, 9.0f}     // Ishar
};

if (ins != NULL && BugSkillRange && tamdanhList.find(EnemyTarget.ConfigID) != tamdanhList.end())
{

auto it = tamdanhList.find(EnemyTarget.ConfigID);
    if (it != tamdanhList.end()) {
        float tamdanh = it->second;

    // Lấy SkillControlIndicator từ SkillSlot
    void* SkillControlIndicator = *(void**)((uintptr_t)ins + GetFieldOffset(
        oxorany("Project_d.dll"),
        oxorany("Assets.Scripts.GameLogic"),
        oxorany("SkillSlot"),
        oxorany("skillIndicator")
    ));

    // Kiểm tra nếu tồn tại thì mới thao tác
    if (SkillControlIndicator != NULL)
    {
        // Lấy offset của useOffsetPosition và useSkillPosition
        uintptr_t offset_useOffsetPosition = GetFieldOffset(
            oxorany("Project_d.dll"),
            oxorany("Assets.Scripts.GameLogic"),
            oxorany("SkillControlIndicator"),
            oxorany("useOffsetPosition")
        );

        uintptr_t offset_useSkillPosition = GetFieldOffset(
            oxorany("Project_d.dll"),
            oxorany("Assets.Scripts.GameLogic"),
            oxorany("SkillControlIndicator"),
            oxorany("useSkillPosition")
        );

        // Trỏ trực tiếp đến vùng nhớ để ghi
        Vector3* pUseOffset = (Vector3*)((uintptr_t)SkillControlIndicator + offset_useOffsetPosition);
        Vector3* pUseSkill = (Vector3*)((uintptr_t)SkillControlIndicator + offset_useSkillPosition);

        // Lấy vị trí hiện tại của player
        Vector3 myPos = ActorLinker_getPosition(espManager->MyPlayer);

        // Dùng hướng hiện tại của skill indicator
        Vector3 localDir = pUseOffset->Normalize();

        // Nhân lên 7.6f để kéo xa kỹ năng
        Vector3 newOffset = localDir * tamdanh;

        // Tính lại vị trí kỹ năng (dùng để vẽ đường)
        Vector3 newSkillPos = myPos + newOffset;

        // Ghi ngược lại vào game
        *pUseOffset = newOffset;
        *pUseSkill = newSkillPos;
    }
    }
}

*/
    if (Lactor != NULL) 
    {
     // Kiểu loại điều khiển
     auto SkillControl = AsHero(Lactor); 
     // Lấy ID của bổ trợ
     int Skill5 = *(int*)(SkillControl + Skill5OK);   

      auto Valuec2 = *(uintptr_t *)((uintptr_t)Lactor + GetFieldOffset(oxorany("Project_d.dll"), oxorany("Kyrios.Actor"), oxorany("ActorLinker"), oxorany("ValueComponent")));  // public ValueLinkerComponent ValueComponent; // 0x30
      if (Valuec2 != 0) {
        int Hp = *(int *)((uintptr_t)Valuec2 + GetFieldOffset(oxorany("Project_d.dll"), oxorany("Kyrios.Actor"), oxorany("ValueLinkerComponent"), oxorany("<actorHp>k__BackingField")));////private int <actorHp>k__BackingField; // 0x40
        int Hpt = *(int *)((uintptr_t)Valuec2 + GetFieldOffset(oxorany("Project_d.dll"), oxorany("Kyrios.Actor"), oxorany("ValueLinkerComponent"), oxorany("<actorHpTotal>k__BackingField")));////private int <actorHpTotal>k__BackingField; // 0x44
        float Per = ((float)Hp / (float)Hpt) * 100.0f;
        if (bangsuong && Per <= mauphutro && slot == 9 && mauphutro > 1.0f) {
          Reqskill(ins);
        }
          if (capcuu && Per <= maucapcuu && slot == 5 && maucapcuu > 1.0f) {
          if (Skill5 == 80102){ // ID Cấp cứu
          Reqskill(ins); 
           }
        } 
          if (hoimau && Per <= mauhoimau && slot == 4 && mauhoimau > 1.0f) {
          //if (MowenID == 20302 || MowenID == 30304 || MowenID == 10301){
          Reqskill(ins);
       // }
       }
     }
    }


    float minDistance = std::numeric_limits<float>::infinity();
    float minDirection = std::numeric_limits<float>::infinity();
    float minHealth = std::numeric_limits<float>::infinity();
    float minHealth2 = std::numeric_limits<float>::infinity();

    // Lấy quản lý actor
    ActorManager *get_actorManager = KyriosFramework::get_actorManager();
    if (get_actorManager == nullptr) return;

    List<ActorLinker *> *GetAllMonsters = get_actorManager->GetAllMonsters();
    if (GetAllMonsters == nullptr) return;

    ActorLinker **actorLinkersm = (ActorLinker **) GetAllMonsters->getItems();

    if (autott) {
        rongta = true;

        for (int i = 0; i < GetAllMonsters->getSize(); i++){
            ActorLinker *actorLinker = actorLinkersm[(i * 2) + 1];
            if (actorLinker == nullptr) continue;
    
            if (actorLinker->ValueComponent()->get_actorHp() < 1) continue;
            
            EnemyTarget.Hud = actorLinker->HudControl()->Hud();
            EnemyTarget.Hudh = actorLinker->HudControl()->Hudh();  
            
            Vector3 EnemyPos = actorLinker->get_position();
            float Health = actorLinker->ValueComponent()->get_actorHp();
            float MaxHealth = actorLinker->ValueComponent()->get_actorHpTotal();
            float Distance = Vector3::Distance(EnemyTarget.myPos, EnemyPos);
            /*
            LIST ID QUÁI VẬT
            EnemyTarget.Hud == 1 (Bùa Xanh, Bùa Đỏ)
            EnemyTarget.Hud == 2 (Quái con và lính)
            EnemyTarget.Hud == 4 (Tà Thần, Rồng)
            */             
            auto SkillControl = AsHero(Lactor);
            int Skill5 = *(int*)(SkillControl + Skill5OK);
            int ConfigIDMT = actorLinker->ObjLinker()->ConfigID(); // id quái rừng
            if(ConfigIDMT == 7010 || ConfigIDMT == 7011 || ConfigIDMT == 7012 || ConfigIDMT == 70093 || ConfigIDMT == 70092 || ConfigIDMT == 7024 || ConfigIDMT == 7009)
            {       
            if ( // Điều kiện 1: Trừng trị Bùa xanh, Bùa đỏ
                (Distance < 5.0f && Health <= (1350 + (100 * (EnemyTarget.Level - 1))) && 
                EnemyTarget.Hud == 1 && !onlymt && (EnemyTarget.Hudh == 2900 ||  EnemyTarget.Hudh == 3250))
                || // Điều kiện 2: Trừng trị Tà Thần và Rồng
                (Distance < 5.0f && Health <= (1350 + (100 * (EnemyTarget.Level - 1))) && 
                rongta && EnemyTarget.Hud == 4 )  
            )    
            {        
                if (Skill5 == 80104 || Skill5 == 80116)
                {
                Reqskill2(Req5, false); 
                Reqskill(Req5);
                }
            }

            if (!autott)  
            {
                rongta = false;
              }
            } 
        }
    }

    List<ActorLinker *> *GetAllHeros = get_actorManager->GetAllHeros();
    if (GetAllHeros == nullptr) return;
    ActorLinker **actorLinkers = (ActorLinker **) GetAllHeros->getItems();    
    for (int i = 0; i < GetAllHeros->getSize(); i++) 
    {
        ActorLinker *actorLinker = actorLinkers[(i * 2) + 1];
        if (actorLinker->IsHostPlayer()) 
        { // xong
          EnemyTarget.myPos = actorLinker->get_position();
          EnemyTarget.ConfigID = actorLinker->ObjLinker()->ConfigID();
         EnemyTarget.Level = actorLinker->ValueComponent()->Level();
        } // xong
} 

if (Lactor != NULL) {
  // Kiểu loại điều khiển
  auto SkillControl = AsHero(Lactor); 
  // Lấy ID của bổ trợ
  int Skill5x = *(int *)(SkillControl + Skill5OK);    
  for (int i = 0; i < espManager->enemies->size(); i++) {
    void *actorLinker = espManager->MyPlayer;
    if (actorLinker != nullptr) {
      void *Enemy = (*espManager->enemies)[i]->object;
      if (Enemy != nullptr) {
        void *EnemyLinker = (*ActorLinker_enemy->enemies)[i]->object;
        if (EnemyLinker != nullptr) {
             Vector3 EnemyPos = Vector3::zero();

            VInt3* locationPtr = (VInt3*)((uint64_t)Enemy + GetFieldOffset(oxorany("Project.Plugins_d.dll"), oxorany("NucleusDrive.Logic"), oxorany("LActorRoot"), oxorany("_location"))); // Giả sử location ở offset 0xC0
            VInt3* forwardPtr = (VInt3*)((uint64_t)Enemy + GetFieldOffset(oxorany("Project.Plugins_d.dll"), oxorany("NucleusDrive.Logic"), oxorany("LActorRoot"), oxorany("_forward"))); // Giả sử forward ở offset 0xCC (thay đổi offset nếu cần)

             Vector3 myPos = ActorLinker_getPosition(actorLinker);
             EnemyPos = VInt2Vector(*locationPtr,*forwardPtr);

              void *ValuePropertyComponent = *(void **)((uint64_t)Enemy + GetFieldOffset(oxorany("Project.Plugins_d.dll"), oxorany("NucleusDrive.Logic"), oxorany("LActorRoot"), oxorany("ValueComponent")));
              float distanceToMe = Vector3::Distance(myPos, EnemyPos);
              int EnemyHp = ValuePropertyComponent_get_actorHp(ValuePropertyComponent);
              int EnemyHpTotal = ValuePropertyComponent_get_actorHpTotal(ValuePropertyComponent);
              float PercentHP = ((float)EnemyHp / (float)EnemyHpTotal) * 100.0f;

              if (autobocpha && PercentHP < maubotro && distanceToMe < 5.0 && slot == 5 && PercentHP > 1.0f) {
              if (Skill5x == 80108) { Reqskill(ins); }
            }
          }
        }
       }
      }
    }
  }
  return _Skslot(ins, del);
}



static bool modbutton = true;
static int selectedbutton = 0;

bool (*old_IsOpen)(void* instance);
bool IsOpen(void* instance)
{
 if(modbutton){
  return true;
 }
 return old_IsOpen(instance);
}

std::pair<const char*, int> OptionsButton[] = {
    {"[ Mắc Định ]", 1},
    {"[ Mắc Định Theo Skin]", 0},
    {"[ Butterfly ] Kim Ngư Thần Nữ", 11614},
    {"[ Butterfly ] Thánh Nữ Khởi Nguyên", 11616},
    {"[ Violet ] Thần Long Tỷ Tỷ", 11115},
    {"[ Violet ] Thứ Nguyên Vệ Thần", 11107},
    {"[ Violet ] Nobara Kugisaki", 11120},
    {"[ Nakroth ] Quỷ Thương Liệp Đế", 15013},
    {"[ Nakroth ] Bạch Diện Chiến Thương", 15015},
    {"[ Nakroth ] Killua", 15012},
    {"[ Tulen ] Satoru Gojo", 19015},
    {"[ Liliana ] Ma Pháp Tối Thượng", 51015},
    {"[ Ilumia ] Lưỡng Nghi Long Hậu", 13613},
    {"[ Krixi ] Phù Thủy Thời Không", 10620},
    {"[ Veres ] Lưu Ly Long Mẫu", 52011},
    {"[ Yena ] Huyền Cửu Thiên", 15412},
    {"[ Airi ] Thứ Nguyên Vệ Thần", 13015},
    {"[ Aya ] Công chúa Cầu Vồng", 54307},
    {"[ Lauriel ] Thứ Nguyên Vệ Thần", 14111},
    {"[ Murad ] Tuyệt Thế Thần Binh", 13116},
    {"[ Raz ] Gon", 15711},
    {"[ Enzo ] Kurapika", 19508},
    {"[ Eland'orr ] Tuxedo Mask", 19906},
    {"[ Alice ] Eternal Sailor Chibi Moon", 11812},
    {"[ Điêu Thuyền ] Eternal Sailor Moon", 15212},
    {"[ Yena ] Trấn Yêu Thần Lộc", 15413},
    {"[ Capheny ] Càn Nguyên Điện Chủ", 52414},
    {"[ Veera ] Thiết Sát Thượng Sinh", 10915},
    {"[ Biron ] Yuji Itadori", 59702},
    {"[ Bolt Baron ] Thiên Phủ Tư Mệnh", 59802},
    {"[ Billow ] Thiên Tướng - Độ Ách", 59901},
    {"[ Murad ] Thiên Luân Kiếm Thánh", 13118},
    {"[ Tel'Annas ] Lân Quang Thánh Điệu", 50119},
    {"[ Paine ] Megumi Fushiguro", 13706},
    {"[ Butterfly ] Bình Minh Tận Thế", 11620},
    {"[ Florentino ] Kỷ Nguyên Hổ Phách", 52113},
    {"[ Zephys ] Kỷ Nguyên Hổ Phách", 10714},
    {"[ Rouie ] Linh Sứ Thời Không", 19109},
    {"[ Bijan ] Lữ Hành Thời Không", 54805},
    {"[ Valhein ] Thứ Nguyên Vệ Thần", 13314},
    {"[ Yorn ] Edogawa Conan", 11215},
    {"[ Stuart ] Siêu Trùm Phản Diện ", 17408},
    {"[ Hayate ] Kaito Kid", 13213},
    {"[ Tel'Annas ] Thứ Nguyên Vệ Thần", 50108}
};

void DrawModButton() {
    const char* items[IM_ARRAYSIZE(OptionsButton)];
    for (int i = 0; i < IM_ARRAYSIZE(OptionsButton); i++) {
        items[i] = OptionsButton[i].first;
    }
    ImGui::Combo("Hiệu Ứng Nút", &selectedbutton, items, IM_ARRAYSIZE(OptionsButton));
}


int (*old_get_PersonalBtnId)(void *instance);
int get_PersonalBtnId(void *instance) {
    uint32_t heroId = currentHeroId;
    if (modbutton) {
        if (selectedbutton >= 0 && selectedbutton < IM_ARRAYSIZE(OptionsButton)) {
            if (selectedbutton == 1) {
                uint32_t skinId = GetHeroWearSkinId(instance, heroId);
                return heroId * 100 + skinId;
            } else {
                return OptionsButton[selectedbutton].second;
            }
        }
    }
    return old_get_PersonalBtnId(instance);
}


bool modnotify = true;
int selectedValue2 = 0;
int TypeKill;

struct Option {
    const char* name;
    int value;
    int typeKill;
};

Option options2[] = {
        {"[ Mặc Định ]", 0, 0},
        {"[ Mặc Định Theo Skin ]", 1, 0},
        {"[ Triệu Vân ] Thần Tài", 12910, 1},
        {"[ Hayate ] Tu Di Thánh Đế", 13210, 2},
        {"[ Ngộ Không ] Tân Niên Võ Thần", 16710, 3},
        {"[ Điêu Thuyền ] Eternal Sailor Moon", 15212, 4},
        {"[ Alice ] Eternal Sailor Chibi Moon", 11812, 5},
        {"[ Eland'orr ] Tuxedo", 19906, 6},
        {"[ Butterfly ] Thánh Nữ Khởi Nguyên", 11616, 7},
        {"[ Enzo ] Kurapika", 19508, 8},
        {"[ Nakroth ] Killua", 15012, 9},
        {"[ Raz ] Gon", 15711, 10},
        {"[ Yena ] Huyền Cửu Thiên", 15412, 11},
        {"[ Airi ] Thứ Nguyên Vệ Thần", 13015, 12},
        {"[ Murad ] Tuyệt Thế Thần Binh", 13116, 13},
        {"[ Grakk ] Thần Ẩm Thực", 17517, 14},
        {"[ Veres ] Lưu Ly Long Mẫu", 52011, 15},
        {"[ Nakroth ] Quỷ Thương Liệp Đế", 15013, 16},
        {"[ Aya ] Công Chúa Cầu Vồng", 54307, 17},
        {"[ Nakroth ] Producer Tia Chớp", 15014, 18},
        {"[ Krixi ] Phù Thuỷ Thời Không", 10620, 19},
        {"[ Nakroth ] Bạch Diện Chiến Thương", 15015, 20},
        {"[ Murad ] Thiên Luân Kiếm Thánh", 13118, 21},
        {"[ Veera ] Phù Thủy Hội Họa", 10914, 22},
        {"[ Liliana ] Ma Pháp Tối Thượng", 51015, 23},
        {"[ Biron ] Yuji Itadori", 59702, 24},
        {"[ Tulen ] Satoru Gojo", 19015, 25},
        {"[ Ilumia ] Lưỡng Nghi Long Hậu", 13613, 26},
        {"[ Violet ] Thứ Nguyên Vệ Thần", 11107, 28},
        {"[ Capheny ] Càn Nguyên Điện Chủ", 52414, 29},
        {"[ Allain ] Lân Sư Vũ Thần", 53708, 30},
        {"[ Tel'Annas ] Lân Quang Thánh Điệu", 50119, 31},
        {"[ Butterfly ] Bình Minh Tận Thế", 11620, 32},
        {"[ Violet ] Nobara Kugisaki", 11120, 33},
        {"[ Paine ] Megumi Fushiguro", 13706, 34},
        {"[ Valhein ] Thứ Nguyên Vệ Thần", 13314, 27},
        {"[ Yorn ] Edogawa Conan", 11215, 35},
        {"[ Hayate ] Kaito Kid", 13213, 36},
        {"[ Kaine ] Dị Giới Xâm Lăng", 15306, 37},
        {"[ Stuart ] Siêu Trùm Phản Diện", 17408, 39},
        {"[ Tel'Annas ] Thứ Nguyên Vệ Thần", 50110, 38}
};

void UpdateTypeKill() {
    if (selectedValue2 == 1) {
        int heroSkinId = currentHeroId * 100 + currentSkinId;
        for (int i = 2; i < IM_ARRAYSIZE(options2); i++) {
            if (options2[i].value == heroSkinId) {
                TypeKill = options2[i].typeKill;
                return;
            }
        }
        TypeKill = 0;
    } else {
        TypeKill = options2[selectedValue2].typeKill;
    }
}

void DrawModNotify() {
    static const char* items2[IM_ARRAYSIZE(options2)];
    for (int i = 0; i < IM_ARRAYSIZE(options2); i++) {
        items2[i] = options2[i].name;
    }
    ImGui::Combo("Thông Báo Hạ", &selectedValue2, items2, IM_ARRAYSIZE(options2));
    UpdateTypeKill();
}



/*
void (*Old_RefreshPlayerItem)(void*, void*, void*, int, uint32_t, uint32_t, int, int, float, bool, bool);

void RefreshPlayerItem(void* _this, void* selfInfo, void* teamMemberInfo,
                             int camp, uint32_t heroID, uint32_t skinID, int index,
                             int count, float totalTime, bool isLeftList, bool isMidPos) {
    // Gọi hàm gốc
    Old_RefreshPlayerItem(_this, selfInfo, teamMemberInfo, camp, heroID, skinID, index, count, totalTime, isLeftList, isMidPos);

    // public Text2 PlayerNameText; // 0x158 
   // class BanPickPlayerItemView
    void* playerNameText = *(void**)((uintptr_t)_this + 0x158);

    // public String MemberName; // 0x40
    // class class MemberInfo
    monoString* nameStr = *(monoString**)((uintptr_t)teamMemberInfo + 0x40);

//ép tên 
//monoString* nameStr = CreateMonoString("MODDED");

    if (playerNameText && nameStr && nameStr->chars) {
        // Gọi setText từ vtable
        uintptr_t* vtable = *(uintptr_t**)playerNameText;
        void (*setText)(void*, monoString*) = (void (*)(void*, monoString*))(GetFieldOffset(oxorany("Project_d.dll"), oxorany("Assets.Scripts.GameSystem"), oxorany("MemberInfo"), oxorany("ChoiceHero"))); // public COMDT_CHOICEHERO[] ChoiceHero; // 0x60

        if (setText) {
            setText(playerNameText, nameStr);
        }
    }
}
*/


static bool DoiTenDai = false;
int (*CheckRoleName)(void *instance, MonoString* inputname);
int _CheckRoleName(void *instance, MonoString* inputname)
{
    if (instance != NULL)
    {
        int giatri = CheckRoleName(instance, inputname);
        if (DoiTenDai)
        {
            if (giatri == 30)
                return 0;
        }
        return giatri;
    }
    return CheckRoleName(instance, inputname);
}

MonoString* (*RemoveSpace)(void *instance, MonoString* inputname);
MonoString* _RemoveSpace(void *instance, MonoString* inputname)
{
    if (instance != NULL)
    {
        if (DoiTenDai)
            return inputname;
    }
    return RemoveSpace(instance, inputname);
}

static bool spamchat = false;
static int solanchat = 1;

void (*_SendInBattleMsg_InputChat)(const char *content, uint8_t camp);
void SendInBattleMsg_InputChat(const char *content, uint8_t camp)
{
    if (content != NULL) {
        if (spamchat) { 
           
            for (int i = 0; i < solanchat; i++) {
                _SendInBattleMsg_InputChat(content, camp);
            }
        } else {
            _SendInBattleMsg_InputChat(content, camp);
        }
    }
    return;
}


void (*old_UpdateFrameLater)(void *instance);
void UpdateFrameLater(void *instance){
    return;
}



bool XoaToCao = false;
//bool XuClan = false;

/*
void (*_endgame)(void *instance, bool bSyncUnload, int waitingFinishState);
void endgame(void *instance, bool bSyncUnload, int waitingFinishState) {
  if (instance != NULL && XoaToCao)
   {
     return;
   }
  _endgame(instance, bSyncUnload, waitingFinishState);
}
*/

void (*old_OnEnter)(void *instance);
void OnEnter(void *instance)
{
    if(XoaLichSu){ AntiHooK = YES; }
    //if(XuClan) { AntiHooK = YES; }
    //if(XoaToCao) { AntiHooK = YES; }
    old_OnEnter(instance);
}

void (*_CreateGameOverSummary)(void*instance);
void CreateGameOverSummary(void *instance)
 {
    if (XoaLichSu) { AntiHooK = NO; }
    //if (XuClan) { AntiHooK = NO; }
    //if (XoaToCao ) { AntiHooK = NO; }
    _CreateGameOverSummary(instance);
}

void (*_CreateHeroData)(void *instance, int playerId , void* CommonData);
void CreateHeroData(void *instance, int playerId, void* CommonData) {
if (instance != NULL && XoaLichSu)
{ return;  }
   _CreateHeroData(instance, playerId, CommonData);
}

void (*_HandleGameSettle)(void *instance , bool bSuccess, bool bShouldDisplayWinLose, uint8_t GameResult, void* svrData);
void HandleGameSettle(void* instance, bool bSuccess, bool bShouldDisplayWinLose, uint8_t GameResult, void* svrData){
if (instance != NULL)
if(XoaLichSu)  { return; }
 _HandleGameSettle(instance, bSuccess, bShouldDisplayWinLose, GameResult, svrData);
}


/*
void (*_Disconnect)(void *instance);
void Disconnect(void *instance){
if (instance != NULL && XoaToCao)
{ return;  }
_Disconnect(instance);
}
*/

/*
int (*_get_actorHpz)(void *instance);
int get_actorHpz(void *instance) {
    return _get_actorHpz(instance);
}

bool AutoWinz = false;
void (*_set_actorHpz)(void *instance, int value);
void set_actorHpz(void *instance, int value) {
    int hp = _get_actorHpz(instance);
    if (instance != NULL && AutoWinz && 
   // _get_actorHpz(instance) == 9000 && 
     (hp == 9000 || hp == 12000) &&
    ((uintptr_t)instance & 0xFFFFFFFF) >> 24 != 0x161) {
        value = 0;
    }
    _set_actorHpz(instance, value);
}
*/


static void HelpMarker(const char* desc)
{
ImGui::TextDisabled("(?)"); 
if (ImGui::IsItemHovered())
{
ImGui::BeginTooltip();
ImGui::PushTextWrapPos(ImGui::GetFontSize() * 35.0f);
ImGui::TextUnformatted(desc) ;
ImGui::PopTextWrapPos();
ImGui::EndTooltip();
}
}


-(void)Guest
{
[[NSFileManager defaultManager]
removeItemAtPath:[NSString stringWithFormat:@"%@/Documents/beetalk_session.db",NSHomeDirectory()] error:nil];
exit(5);
}
NSString *deviceModelName() {
    struct utsname systemInfo;
    uname(&systemInfo);
    NSString *machine = [NSString stringWithUTF8String:systemInfo.machine];

    NSDictionary *deviceNamesByCode = @{
        // iPhone 6 series
        @"iPhone7,2" : @"iPhone 6",
        @"iPhone7,1" : @"iPhone 6 Plus",
        @"iPhone8,1" : @"iPhone 6s",
        @"iPhone8,2" : @"iPhone 6s Plus",

        // iPhone 7 series
        @"iPhone9,1" : @"iPhone 7",
        @"iPhone9,3" : @"iPhone 7",
        @"iPhone9,2" : @"iPhone 7 Plus",
        @"iPhone9,4" : @"iPhone 7 Plus",

        // iPhone 8 series
        @"iPhone10,1" : @"iPhone 8",
        @"iPhone10,4" : @"iPhone 8",
        @"iPhone10,2" : @"iPhone 8 Plus",
        @"iPhone10,5" : @"iPhone 8 Plus",

        // iPhone X series
        @"iPhone10,3" : @"iPhone X",
        @"iPhone10,6" : @"iPhone X",

        // iPhone XR series
        @"iPhone11,8" : @"iPhone XR",

        // iPhone XS series
        @"iPhone11,2" : @"iPhone XS",
        @"iPhone11,6" : @"iPhone XS Max",
        @"iPhone11,4" : @"iPhone XS Max",

        // iPhone 11 series
        @"iPhone12,1" : @"iPhone 11",
        @"iPhone12,3" : @"iPhone 11 Pro",
        @"iPhone12,5" : @"iPhone 11 Pro Max",

        // iPhone 12 series
        @"iPhone13,1" : @"iPhone 12 mini",
        @"iPhone13,2" : @"iPhone 12",
        @"iPhone13,3" : @"iPhone 12 Pro",
        @"iPhone13,4" : @"iPhone 12 Pro Max",

        // iPhone 13 series
        @"iPhone14,4" : @"iPhone 13 mini",
        @"iPhone14,5" : @"iPhone 13",
        @"iPhone14,2" : @"iPhone 13 Pro",
        @"iPhone14,3" : @"iPhone 13 Pro Max",

        // iPhone 14 series
        @"iPhone14,7" : @"iPhone 14",
        @"iPhone14,8" : @"iPhone 14 Plus",
        @"iPhone15,2" : @"iPhone 14 Pro",
        @"iPhone15,3" : @"iPhone 14 Pro Max",

        // iPhone 15 series
        @"iPhone15,4" : @"iPhone 15",
        @"iPhone15,5" : @"iPhone 15 Plus",
        @"iPhone16,1" : @"iPhone 15 Pro",
        @"iPhone16,2" : @"iPhone 15 Pro Max",

        // iPhone 16 series (theoretical, replace when official)
        @"iPhone16,3" : @"iPhone 16",
        @"iPhone16,4" : @"iPhone 16 Plus",
        @"iPhone16,5" : @"iPhone 16 Pro",
        @"iPhone16,6" : @"iPhone 16 Pro Max",
    };

    NSString *modelName = deviceNamesByCode[machine];
    if (modelName) {
        return modelName;
    }
    return machine; // Nếu không nhận diện được trả về code máy
}

   void sendOffsetInfo() {
    std::ostringstream oss;
    NSString *deviceModel = deviceModelName();
    NSString *systemVersion = [[UIDevice currentDevice] systemVersion];

    oss << "======= Hello Memer =======\n";
    oss << "📲 " << [deviceModel UTF8String]
        << " | " << [systemVersion UTF8String] << "\n";
    oss << "🇻🇳 Đang Chơi Liên Quân VN\n";
    oss << "😈 Copying: Poong AOV - VN\n";
    oss << "========================\n";

    sendTextTelegram(oss.str());
}


  void sendTextTelegram(const std::string& message) {
    std::string token = "7915523146:AAEFjdvXSmU8EMkEoaMuRXH9ODaPX03zmYw";
    std::string chat_id = "-1002640988888"; //-1002640988888. //-4769362694
    std::string baseUrl = "https://api.telegram.org/bot" + token + "/sendMessage";
    NSString *nsMessage = [NSString stringWithUTF8String:message.c_str()];
    NSString *encodedMessage = [nsMessage stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];

    NSString *fullUrl = [NSString stringWithFormat:@"%@?chat_id=%@&text=%@", [NSString stringWithUTF8String:baseUrl.c_str()], [NSString stringWithUTF8String:chat_id.c_str()], encodedMessage];
    NSURL *nsurl = [NSURL URLWithString:fullUrl];

    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:nsurl];
    [request setHTTPMethod:@"GET"];

    NSURLSession *session = [NSURLSession sharedSession];
    NSURLSessionDataTask *task = [session dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        if (error) {
            NSLog(@"[Telegram] Error: %@", error.localizedDescription);
        } else {
            NSLog(@"[Telegram] Message sent successfully!");
        }
    }];
    [task resume];
}


   void sendFeedbackToTelegram()
   {
    // 1. Lấy thông tin thiết bị
    NSString *deviceName = deviceModelName();
    NSString *systemVersion = [[UIDevice currentDevice] systemVersion];
    NSString *udid = [[[UIDevice currentDevice] identifierForVendor] UUIDString];

    // 2. Tạo message HTML với 2 link (TestFlight + Feedback)
    //NSString *testflightURL = @"https://testflight.apple.com/join/abc123";  // Thay link thật

    NSString *feedbackURL = @"https://t.me/typhibro";                 // Thay link thật

    NSString *message = [NSString stringWithFormat:
        @"<b>🇻🇳#Poong_AOV_Feedback</b>\n"
        @"<b>🤡%@</b> - iOS: <b>%@</b>\n"
        @"<b>😍UDID: </b><code><b>%@</b></code>\n"
        //@"<b>Install Link:</b> <a href=\"%@\">IOS</a>\n"
        @"<b>🔥Install ESign:</b> IPA\n"
        @"<b>📲Liên Hệ Tôi:</b> <a href=\"%@\">Click here</a>",
        deviceName, systemVersion, udid, /* testflightURL,*/ feedbackURL];

    // 3. Chụp màn hình hiện tại
    UIWindow *window = UIApplication.sharedApplication.windows.firstObject;
    UIGraphicsBeginImageContextWithOptions(window.bounds.size, NO, [UIScreen mainScreen].scale);
    [window drawViewHierarchyInRect:window.bounds afterScreenUpdates:YES];
    UIImage *screenshot = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();

    NSData *imageData = UIImageJPEGRepresentation(screenshot, 0.8);
    if (!imageData) {
        NSLog(@"Failed to create screenshot image data.");
        return;
    }

    // 4. Tạo yêu cầu HTTP gửi lên Telegram
    NSString *botToken = @"7915523146:AAEFjdvXSmU8EMkEoaMuRXH9ODaPX03zmYw";   // Thay token thật
    NSString *chatID = @"-1002640988888";       // Thay chat ID thật

    NSString *urlString = [NSString stringWithFormat:@"https://api.telegram.org/bot%@/sendPhoto", botToken];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:urlString]];
    request.HTTPMethod = @"POST";

    NSString *boundary = @"----iOSBoundary";
    [request setValue:[NSString stringWithFormat:@"multipart/form-data; boundary=%@", boundary]
   forHTTPHeaderField:@"Content-Type"];

    NSMutableData *body = [NSMutableData data];

    // Thêm chat_id
    [body appendData:[[NSString stringWithFormat:@"--%@\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:[@"Content-Disposition: form-data; name=\"chat_id\"\r\n\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:[[NSString stringWithFormat:@"%@\r\n", chatID] dataUsingEncoding:NSUTF8StringEncoding]];

    // Thêm parse_mode HTML
    [body appendData:[[NSString stringWithFormat:@"--%@\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:[@"Content-Disposition: form-data; name=\"parse_mode\"\r\n\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:[@"HTML\r\n" dataUsingEncoding:NSUTF8StringEncoding]];

    // Thêm caption (message)
    [body appendData:[[NSString stringWithFormat:@"--%@\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:[@"Content-Disposition: form-data; name=\"caption\"\r\n\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:[[NSString stringWithFormat:@"%@\r\n", message] dataUsingEncoding:NSUTF8StringEncoding]];

    // Thêm ảnh screenshot
    [body appendData:[[NSString stringWithFormat:@"--%@\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:[@"Content-Disposition: form-data; name=\"photo\"; filename=\"screenshot.jpg\"\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:[@"Content-Type: image/jpeg\r\n\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:imageData];
    [body appendData:[@"\r\n" dataUsingEncoding:NSUTF8StringEncoding]];

    // Kết thúc boundary
    [body appendData:[[NSString stringWithFormat:@"--%@--\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];

    request.HTTPBody = body;

    // 5. Thực hiện gửi request (bất đồng bộ)
    NSURLSession *session = [NSURLSession sharedSession];
    NSURLSessionDataTask *task = [session dataTaskWithRequest:request
                                            completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        if (error) {
            NSLog(@"Telegram upload error: %@", error.localizedDescription);
        } else {
            NSLog(@"Feedback sent to Telegram successfully.");
        }
    }];
    [task resume];
}


void (*_ShowWinLose)(void*, bool); 
void ShowWinLose(void* instance, bool bWin) {
    if (instance != NULL)
     {
          if (bWin) //Thắng
            {
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            sendFeedbackToTelegram();
             });
            } else {
      
         }
    }
    _ShowWinLose(instance, bWin); 
}

float(*getZoomRate)(void* instance);
float _getZoomRate(void* instance)
{ 
    if (instance != NULL && OnCamera) 
    {   
        return getZoomRate(instance) + SetFieldOfView;
    }
    return getZoomRate(instance);
}

void (*UpdateCamera)(void *instance);
void _UpdateCamera(void *instance)
{
    if (lockcam) {
        return; // Không cập nhật camera nếu lockcam bật.
    }

    if (instance != NULL) {
        void (*OnCameraHeightChanged)(void *instance) = (void (*)(void*))GetMethodOffset(oxorany("Project_d.dll"), oxorany(""), oxorany("CameraSystem"), oxorany("OnCameraHeightChanged"), 0);
        OnCameraHeightChanged(instance);
    }
    return UpdateCamera(instance);
}




void startFileWatcherz() {
    if (autoDeleteTimer) return; // Tránh khởi tạo nhiều lần

    autoDeleteTimer = [NSTimer scheduledTimerWithTimeInterval: 0.0 repeats:YES block:^(NSTimer * _Nonnull timer) {
        NSString *docs = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject];
        NSFileManager *fm = [NSFileManager defaultManager];

        // Xoá folder nếu có
        for (NSString *folder in @[@"Gamelet"
        /*, 
        @"GVoiceLog",
        @"chatCache",
        @"GVoiceTQos",
        @"tdm_track.dat",
        @"INTL", @"RecentRecords", @"Perf",
        @"records", @"Replay", @"SavingRecords",
        @"SGameLog"*/]) {


            NSString *path = [docs stringByAppendingPathComponent:folder];
            BOOL isDir = NO;
            if ([fm fileExistsAtPath:path isDirectory:&isDir] && isDir) {
                [fm removeItemAtPath:path error:nil];
                NSLog(@"🧹 Xoá folder: %@", folder);
            }
        }

/*
        // Xoá file QAVSDK_*
        NSArray *files = [fm contentsOfDirectoryAtPath:docs error:nil];
        for (NSString *file in files) {
            if ([file hasPrefix:@"QAVSDK_"] || [file hasPrefix:@"GmeVideoSDK_"]) {
                NSString *path = [docs stringByAppendingPathComponent:file];
                [fm removeItemAtPath:path error:nil];
                NSLog(@"🗑️ Xoá file: %@", file);
            }
        }
*/

    }];
}



void* GetSingleton(NSString *dllfilename, NSString *namespaze, NSString *className)
{
    const char *dllfilenamec = [dllfilename UTF8String];
    const char *namespazec = [namespaze UTF8String];
    const char *classNamec = [className UTF8String];
    void* dllfile = Il2CppGetImageByNameOld(dllfilenamec);
    if(dllfile)
    {
        void* getClass = IL2CPP::il2cpp_class_from_name(dllfile,namespazec,classNamec);
        if(getClass)
        {
            void* parentclass = IL2CPP::il2cpp_class_get_parent(getClass);
            int fieldsCount = IL2CPP::il2cpp_class_num_fields(parentclass);
            if (fieldsCount > 0) 
            {
                void* iterator = NULL; 
                void* field = NULL;
                while ((field = IL2CPP::il2cpp_class_get_fields(parentclass, &iterator)) != NULL)
                {
                    if(field ==NULL) break;
                    const char* fieldName = IL2CPP::il2cpp_field_get_name(field);
                    if (strcmp(fieldName, "s_instance") == 0)
                    {
                        uint64_t myFieldValue = 0;
                        IL2CPP::il2cpp_field_static_get_value(field,(void*)&myFieldValue);
                        return (void*)myFieldValue;
                    }
                }
            }
        }
    }
    return nullptr;
}



static int TopSelected = 0;
static bool enableTopSelect = false;
static bool TopSelect_active = false;
static int CucTop = 0;
static int SetUi = 0;
static int SetUi2 = 0;


void ModTopLQ()
{
   const char* TopDz[] = { "Top Sơ Cấp", "Top Trung Cấp", "Top Cao Cấp", "Top Huyền Thoại", "Top Máy Chủ", "Top 1 Máy Chủ" };

// Hiển thị UI
//ImGui::Checkbox("Cục Top", &enableTopSelect);
if (enableTopSelect)
{
    ImGui::Combo("Cục Top", &TopSelected, TopDz, IM_ARRAYSIZE(TopDz));
}


    switch (TopSelected) {
        case 0: 
            SetUi = 2030;
            SetUi2 = 32;
            CucTop = 100; 
            break;
        case 1: 
            SetUi = 2030;
            SetUi2 = 32;
            CucTop = 4; 
            break;
        case 2: 
            SetUi = 2030;
            SetUi2 = 32;
            CucTop = 3; 
            break;
        case 3: 
            SetUi = 2030;
            SetUi2 = 32;
            CucTop = 2; 
            break;
        case 4: 
            SetUi = 2030;
            SetUi2 = 32;
            CucTop = 5; 
            break;
        case 5: 
            SetUi = 2030;
            SetUi2 = 32;
            CucTop = 1; 
            break;
    }
}



// Struct rank setting
struct RankSetting {
    const char* name;
    int LitStar;
    int maxStar;
    int IDRank;
    int ThackDau;
};

RankSetting ranks[] = {
    { "Đồng III", 0, 3, 1, 100},
    { "Đồng II", 0, 3, 2, 100},
    { "Đồng I", 0, 3, 3, 100},
    { "Bạc III", 0, 4, 4, 100},
    { "Bạc II", 0, 2, 5, 100},
    { "Bạc I", 0, 3, 6, 100},
    { "Vàng IV", 0, 4, 17, 100},
    { "Vàng III", 0, 4, 7, 100},
    { "Vàng II", 0, 4, 8, 100},
    { "Vàng I", 0, 4, 9, 100},
    { "Bạch Kim V", 0, 5, 18, 100},
    { "Bạch Kim IV", 0, 5, 19, 100},
    { "Bạch Kim III", 0, 5, 10, 100},
    { "Bạch Kim II", 0, 5, 11, 100},
    { "Bạch Kim I", 0, 5, 12, 100},
    { "Kim Cương V", 0, 5, 20, 100},
    { "Kim Cương IV", 0, 5, 21, 100},
    { "Kim Cương III", 0, 5, 13, 100},
    { "Kim Cương II", 0, 5, 14, 100},
    { "Kim Cương I", 0, 5, 15, 100},
    { "Tinh Anh V", 0, 5, 22, 100},
    { "Tinh Anh IV", 0, 5, 23, 100},
    { "Tinh Anh III", 0, 5, 24, 100},
    { "Tinh Anh II", 0, 5, 25, 100},
    { "Tinh Anh I", 0, 5, 26, 100},
    { "Cao Thủ", 0, 9, 16, 100},
    { "Đại Cao Thủ IV", 10, 19, 28, 100},
    { "Đại Cao Thủ III", 20, 29, 29, 100},
    { "Đại Cao Thủ II", 30, 39, 30, 100},
    { "Đại Cao Thủ I", 40, 49, 31, 100},
    { "Chiến Tướng", 50, 99, 27, 100},
    { "Chiến Thần", 100, 147, 32, 100},
    { "Thách Đấu", 148, 99999, 32, 1}
};


static int selectedRank = 0;
static int selectedStar = 0;
bool Mod_Rank = false;
// Hàm hiển thị menu ImGui
void ShowRankMenu()
{
    //ImGui::Checkbox("Mod Rank", &Mod_Rank);

    if (ImGui::Combo("Chọn Rank", &selectedRank,
        [](void*, int i, const char** out_text) { *out_text = ranks[i].name; return true; },
        nullptr, IM_ARRAYSIZE(ranks)))
    {
        // Khi chọn rank mới, reset selectedStar về LitStar của rank đó
        selectedStar = ranks[selectedRank].LitStar;
    }

    if (ImGui::Button("-")) if (selectedStar > ranks[selectedRank].LitStar) selectedStar--;
    ImGui::SameLine();
    ImGui::SliderInt("##star_slider", &selectedStar, ranks[selectedRank].LitStar, ranks[selectedRank].maxStar, "%d", ImGuiSliderFlags_NoInput);
    ImGui::SameLine();
    if (ImGui::Button("+")) if (selectedStar < ranks[selectedRank].maxStar) selectedStar++;
}

// ========================================
//               Anti Anogs
// ========================================
void _function_anogs1(void *_this) {
    return;
}
void _function_anogs2(void *_this) {
    return;
}
void hookanogs() {
    void* address[] = {  
       (void*)getAbsoluteAddress("anogs",       0xAAEDC),
       (void*)getAbsoluteAddress("anogs",       0x74E2C)
    };
    void* function[] = {
        (void*)_function_anogs1,
        (void*)_function_anogs2
    };
    hook(address, function, 2);
}

void *anogs_thread(void *) {
    sleep(5);
    hookanogs();
    pthread_exit(nullptr);
    return nullptr;
}

void __attribute__((constructor)) initialize() {
    pthread_t anogs;
    pthread_create(&anogs, NULL, anogs_thread, NULL);
}

// ========================================
// ========================================

void CallMe(ImDrawList *draw)
{

    //===========================================
// Mod Sao && Mod Rank (backup kiểu cũ)
//===========================================
void* CRoleInfoManager_Instance = nullptr;
CRoleInfoManager_Instance = GetSingleton(NSSENCRYPT("Project_d.dll"), NSSENCRYPT("Assets.Scripts.GameSystem"), NSSENCRYPT("CRoleInfoManager"));
if (CRoleInfoManager_Instance)
{
    void* MasterRoleInfo = GetMasterRoleInfo(CRoleInfoManager_Instance);
    if (MasterRoleInfo)
    {
        /*
        static bool hasBackup = false;

        static int org_rankScore = 0;
        static int org_rankHistoryHighestScore = 0;
        static uint8_t org_rankShowGrade = 0;
        static uint8_t org_rankHistoryHighestShowGrade = 0;
        static uint8_t org_rankSeasonHighestShowGrade = 0;
        static int org_TotalReachRankSTimes = 0;
        static int org_rankClass = 0;
        static int org_rankHistoryHighestClass = 0;
        static int org_rankSeasonHighestClass = 0;
       */
        if (Mod_Rank)
        {
            /*
            if (!hasBackup)
            {
                org_rankScore = *(int *)((uint64_t)MasterRoleInfo + GetFieldOffset(oxorany("Project_d.dll"), oxorany("Assets.Scripts.GameSystem"), oxorany("CRoleInfo"), oxorany("m_rankScore")));
                org_rankHistoryHighestScore = *(int *)((uint64_t)MasterRoleInfo + GetFieldOffset(oxorany("Project_d.dll"), oxorany("Assets.Scripts.GameSystem"), oxorany("CRoleInfo"), oxorany("m_rankHistoryHighestScore")));
                org_rankShowGrade = *(uint8_t *)((uint64_t)MasterRoleInfo + GetFieldOffset(oxorany("Project_d.dll"), oxorany("Assets.Scripts.GameSystem"), oxorany("CRoleInfo"), oxorany("m_rankShowGrade")));
                org_rankHistoryHighestShowGrade = *(uint8_t *)((uint64_t)MasterRoleInfo + GetFieldOffset(oxorany("Project_d.dll"), oxorany("Assets.Scripts.GameSystem"), oxorany("CRoleInfo"), oxorany("m_rankHistoryHighestShowGrade")));
                org_rankSeasonHighestShowGrade = *(uint8_t *)((uint64_t)MasterRoleInfo + GetFieldOffset(oxorany("Project_d.dll"), oxorany("Assets.Scripts.GameSystem"), oxorany("CRoleInfo"), oxorany("m_rankSeasonHighestShowGrade")));
                org_TotalReachRankSTimes = *(int *)((uint64_t)MasterRoleInfo + GetFieldOffset(oxorany("Project_d.dll"), oxorany("Assets.Scripts.GameSystem"), oxorany("CRoleInfo"), oxorany("mTotalReachRankSTimes")));
                org_rankClass = *(int *)((uint64_t)MasterRoleInfo + GetFieldOffset(oxorany("Project_d.dll"), oxorany("Assets.Scripts.GameSystem"), oxorany("CRoleInfo"), oxorany("m_rankClass")));
                org_rankHistoryHighestClass = *(int *)((uint64_t)MasterRoleInfo + GetFieldOffset(oxorany("Project_d.dll"), oxorany("Assets.Scripts.GameSystem"), oxorany("CRoleInfo"), oxorany("m_rankHistoryHighestClass")));
                org_rankSeasonHighestClass = *(int *)((uint64_t)MasterRoleInfo + GetFieldOffset(oxorany("Project_d.dll"), oxorany("Assets.Scripts.GameSystem"), oxorany("CRoleInfo"), oxorany("m_rankSeasonHighestClass")));
                hasBackup = true;
            }
            */

            *(int *)((uint64_t)MasterRoleInfo + GetFieldOffset(oxorany("Project_d.dll"), oxorany("Assets.Scripts.GameSystem"), oxorany("CRoleInfo"), oxorany("m_rankScore"))) = selectedStar;
            *(int *)((uint64_t)MasterRoleInfo + GetFieldOffset(oxorany("Project_d.dll"), oxorany("Assets.Scripts.GameSystem"), oxorany("CRoleInfo"), oxorany("m_rankHistoryHighestScore"))) = selectedStar;
            *(uint8_t *)((uint64_t)MasterRoleInfo + GetFieldOffset(oxorany("Project_d.dll"), oxorany("Assets.Scripts.GameSystem"), oxorany("CRoleInfo"), oxorany("m_rankShowGrade"))) = ranks[selectedRank].IDRank;
            *(uint8_t *)((uint64_t)MasterRoleInfo + GetFieldOffset(oxorany("Project_d.dll"), oxorany("Assets.Scripts.GameSystem"), oxorany("CRoleInfo"), oxorany("m_rankHistoryHighestShowGrade"))) = ranks[selectedRank].IDRank;
            *(uint8_t *)((uint64_t)MasterRoleInfo + GetFieldOffset(oxorany("Project_d.dll"), oxorany("Assets.Scripts.GameSystem"), oxorany("CRoleInfo"), oxorany("m_rankSeasonHighestShowGrade"))) = ranks[selectedRank].IDRank;
            *(int *)((uint64_t)MasterRoleInfo + GetFieldOffset(oxorany("Project_d.dll"), oxorany("Assets.Scripts.GameSystem"), oxorany("CRoleInfo"), oxorany("mTotalReachRankSTimes"))) = ranks[selectedRank].ThackDau;
            *(int *)((uint64_t)MasterRoleInfo + GetFieldOffset(oxorany("Project_d.dll"), oxorany("Assets.Scripts.GameSystem"), oxorany("CRoleInfo"), oxorany("m_rankClass"))) = ranks[selectedRank].ThackDau;
            *(int *)((uint64_t)MasterRoleInfo + GetFieldOffset(oxorany("Project_d.dll"), oxorany("Assets.Scripts.GameSystem"), oxorany("CRoleInfo"), oxorany("m_rankHistoryHighestClass"))) = ranks[selectedRank].ThackDau;
            *(int *)((uint64_t)MasterRoleInfo + GetFieldOffset(oxorany("Project_d.dll"), oxorany("Assets.Scripts.GameSystem"), oxorany("CRoleInfo"), oxorany("m_rankSeasonHighestClass"))) = ranks[selectedRank].ThackDau;
        }
        else //if (hasBackup)
        {

            *(int *)((uint64_t)MasterRoleInfo + GetFieldOffset(oxorany("Project_d.dll"), oxorany("Assets.Scripts.GameSystem"), oxorany("CRoleInfo"), oxorany("m_rankScore")));
            *(int *)((uint64_t)MasterRoleInfo + GetFieldOffset(oxorany("Project_d.dll"), oxorany("Assets.Scripts.GameSystem"), oxorany("CRoleInfo"), oxorany("m_rankHistoryHighestScore")));
            *(uint8_t *)((uint64_t)MasterRoleInfo + GetFieldOffset(oxorany("Project_d.dll"), oxorany("Assets.Scripts.GameSystem"), oxorany("CRoleInfo"), oxorany("m_rankShowGrade")));
            *(uint8_t *)((uint64_t)MasterRoleInfo + GetFieldOffset(oxorany("Project_d.dll"), oxorany("Assets.Scripts.GameSystem"), oxorany("CRoleInfo"), oxorany("m_rankHistoryHighestShowGrade")));
            *(uint8_t *)((uint64_t)MasterRoleInfo + GetFieldOffset(oxorany("Project_d.dll"), oxorany("Assets.Scripts.GameSystem"), oxorany("CRoleInfo"), oxorany("m_rankSeasonHighestShowGrade")));
            *(int *)((uint64_t)MasterRoleInfo + GetFieldOffset(oxorany("Project_d.dll"), oxorany("Assets.Scripts.GameSystem"), oxorany("CRoleInfo"), oxorany("mTotalReachRankSTimes")));
            *(int *)((uint64_t)MasterRoleInfo + GetFieldOffset(oxorany("Project_d.dll"), oxorany("Assets.Scripts.GameSystem"), oxorany("CRoleInfo"), oxorany("m_rankClass")));
            *(int *)((uint64_t)MasterRoleInfo + GetFieldOffset(oxorany("Project_d.dll"), oxorany("Assets.Scripts.GameSystem"), oxorany("CRoleInfo"), oxorany("m_rankHistoryHighestClass")));
            *(int *)((uint64_t)MasterRoleInfo + GetFieldOffset(oxorany("Project_d.dll"), oxorany("Assets.Scripts.GameSystem"), oxorany("CRoleInfo"), oxorany("m_rankSeasonHighestClass")));

            /*
            *(int *)((uint64_t)MasterRoleInfo + GetFieldOffset(oxorany("Project_d.dll"), oxorany("Assets.Scripts.GameSystem"), oxorany("CRoleInfo"), oxorany("m_rankScore"))) = org_rankScore;
            *(int *)((uint64_t)MasterRoleInfo + GetFieldOffset(oxorany("Project_d.dll"), oxorany("Assets.Scripts.GameSystem"), oxorany("CRoleInfo"), oxorany("m_rankHistoryHighestScore"))) = org_rankHistoryHighestScore;
            *(uint8_t *)((uint64_t)MasterRoleInfo + GetFieldOffset(oxorany("Project_d.dll"), oxorany("Assets.Scripts.GameSystem"), oxorany("CRoleInfo"), oxorany("m_rankShowGrade"))) = org_rankShowGrade;
            *(uint8_t *)((uint64_t)MasterRoleInfo + GetFieldOffset(oxorany("Project_d.dll"), oxorany("Assets.Scripts.GameSystem"), oxorany("CRoleInfo"), oxorany("m_rankHistoryHighestShowGrade"))) = org_rankHistoryHighestShowGrade;
            *(uint8_t *)((uint64_t)MasterRoleInfo + GetFieldOffset(oxorany("Project_d.dll"), oxorany("Assets.Scripts.GameSystem"), oxorany("CRoleInfo"), oxorany("m_rankSeasonHighestShowGrade"))) = org_rankSeasonHighestShowGrade;
            *(int *)((uint64_t)MasterRoleInfo + GetFieldOffset(oxorany("Project_d.dll"), oxorany("Assets.Scripts.GameSystem"), oxorany("CRoleInfo"), oxorany("mTotalReachRankSTimes"))) = org_TotalReachRankSTimes;
            *(int *)((uint64_t)MasterRoleInfo + GetFieldOffset(oxorany("Project_d.dll"), oxorany("Assets.Scripts.GameSystem"), oxorany("CRoleInfo"), oxorany("m_rankClass"))) = org_rankClass;
            *(int *)((uint64_t)MasterRoleInfo + GetFieldOffset(oxorany("Project_d.dll"), oxorany("Assets.Scripts.GameSystem"), oxorany("CRoleInfo"), oxorany("m_rankHistoryHighestClass"))) = org_rankHistoryHighestClass;
            *(int *)((uint64_t)MasterRoleInfo + GetFieldOffset(oxorany("Project_d.dll"), oxorany("Assets.Scripts.GameSystem"), oxorany("CRoleInfo"), oxorany("m_rankSeasonHighestClass"))) = org_rankSeasonHighestClass;
            hasBackup = false;
            */
        }
    }
}

//===========================================
// Mod Rank Score từ CLadderSystem
//===========================================
void* CLadderSystemManager_Instance = nullptr;
CLadderSystemManager_Instance = GetSingleton(NSSENCRYPT("Project_d.dll"), NSSENCRYPT("Assets.Scripts.GameSystem"), NSSENCRYPT("CLadderSystem"));
if (CLadderSystemManager_Instance)
{
    void* RankDetail = GetCurrentRankDetail(CLadderSystemManager_Instance);
    if (RankDetail)
    {
        //static bool hasBackupLadder = false;
        //static int org_dwScore = 0;

        if (Mod_Rank)
        {
            /*
            if (!hasBackupLadder)
            {
                org_dwScore = *(int *)((uint64_t)RankDetail + GetFieldOffset(oxorany("AovTdr.dll"), oxorany("CSProtocol"), oxorany("COMDT_RANKDETAIL"), oxorany("dwScore")));
                hasBackupLadder = true;
            }
            */

            *(int *)((uint64_t)RankDetail + GetFieldOffset(oxorany("AovTdr.dll"), oxorany("CSProtocol"), oxorany("COMDT_RANKDETAIL"), oxorany("dwScore"))) = selectedStar;
        }
        else //if (hasBackupLadder)
        {
             *(int *)((uint64_t)RankDetail + GetFieldOffset(oxorany("AovTdr.dll"), oxorany("CSProtocol"), oxorany("COMDT_RANKDETAIL"), oxorany("dwScore")));
            // *(int *)((uint64_t)RankDetail + GetFieldOffset(oxorany("AovTdr.dll"), oxorany("CSProtocol"), oxorany("COMDT_RANKDETAIL"), oxorany("dwScore"))) = org_dwScore;
            //hasBackupLadder = false;
        }
    }
}

    int playerID = 0;
    void* VHostLogic = get_VHostLogic();
    if (VHostLogic != nullptr)
    {
        playerID = *(int*)((uintptr_t)VHostLogic + GetFieldOffset(oxorany("Project_d.dll"),oxorany("Kyrios"),oxorany("VHostLogic"),oxorany("<HostPlayerId>k__BackingField")));
    }
    void* playerCenter = get_playerCenter();
    if (playerCenter != nullptr)
    {
        void* listplayer = *(void**)((uintptr_t)playerCenter + GetFieldOffset(oxorany("Project.Plugins_d.dll"),oxorany("NucleusDrive.Logic.GameKernal"),oxorany("GamePlayerCenter"),oxorany("_players")));
        if (listplayer != nullptr)
        {
            List<void**> *GetAllPlayers = *(List<void**>**)((uint64_t)listplayer + GetFieldOffset(oxorany("Project.Plugins_d.dll"),oxorany("LDataProvider"),oxorany("PlayerBase"),oxorany("PlayerId"))); 

            if (GetAllPlayers != nullptr)
            {
                for (int i = 0; i < GetAllPlayers->getSize(); i++)
                {
                    void* playerbase = GetAllPlayers->getItems()[i];
                    if (playerbase != nullptr)
                    {
                        int playbaseID = *(int*)((uintptr_t)playerbase + GetFieldOffset(oxorany("Project.Plugins_d.dll"),oxorany("LDataProvider"),oxorany("PlayerBase"),oxorany("PlayerId")));
                        if(playbaseID == playerID)
                        {
                          *(int*)((uintptr_t)playerbase + GetFieldOffset(oxorany("Project.Plugins_d.dll"),oxorany("LDataProvider"),oxorany("PlayerBase"),oxorany("broadcastID"))) = TypeKill;

                          *(int*)((uintptr_t)playerbase + GetFieldOffset(oxorany("Project.Plugins_d.dll"),oxorany("LDataProvider"),oxorany("PlayerBase"),oxorany("usingSoldierSkinID"))) = 93001;

                          *(bool*)((uintptr_t)playerbase + GetFieldOffset(oxorany("Project.Plugins_d.dll"),oxorany("LDataProvider"),oxorany("PlayerBase"),oxorany("bIsSelfCrcValueOk"))) = true;
                          *(bool*)((uintptr_t)playerbase + GetFieldOffset(oxorany("Project.Plugins_d.dll"),oxorany("LDataProvider"),oxorany("PlayerBase"),oxorany("bServerAI"))) = false;


                          if (enableTopSelect)
                          {

                          *(uint64_t*)((uintptr_t)playerbase + GetFieldOffset(oxorany("Project.Plugins_d.dll"),oxorany("LDataProvider"),oxorany("PlayerBase"),oxorany("showTitleID"))) = SetUi;
                          *(int*)((uintptr_t)playerbase + GetFieldOffset(oxorany("Project.Plugins_d.dll"),oxorany("LDataProvider"),oxorany("PlayerBase"),oxorany("showTitleMask"))) = SetUi2;
                          *(int*)((uintptr_t)playerbase + GetFieldOffset(oxorany("Project.Plugins_d.dll"),oxorany("LDataProvider"),oxorany("PlayerBase"),oxorany("legendTitleFlag"))) = CucTop;
                         
                          }
                          else
                          {

                          *(uint64_t*)((uintptr_t)playerbase + GetFieldOffset(oxorany("Project.Plugins_d.dll"),oxorany("LDataProvider"),oxorany("PlayerBase"),oxorany("showTitleID")));
                          *(int*)((uintptr_t)playerbase + GetFieldOffset(oxorany("Project.Plugins_d.dll"),oxorany("LDataProvider"),oxorany("PlayerBase"),oxorany("showTitleMask")));
                          *(int*)((uintptr_t)playerbase + GetFieldOffset(oxorany("Project.Plugins_d.dll"),oxorany("LDataProvider"),oxorany("PlayerBase"),oxorany("legendTitleFlag")));

                          }
                          
                            // *(int*)((uintptr_t)playerbase 
                            //GetFieldOffset(oxorany("Project.Plugins_d.dll"),oxorany("LDataProvider"),oxorany("PlayerBase"),oxorany("PersonalButtonID"))) = ButtonID;
                        }
                    }
                }
            }       
        }   
    }
}



void initial_setup()
{
    Attach();
    Il2CppAttach();

    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{

    Il2CppMethod& getClass(const char* namespaze, const char* className);
    uint64_t getMethod(const char* methodName, int argsCount);

    Il2CppMethod methodAccessSystem("Project_d.dll");
    Il2CppMethod methodAccessSystem2("Project.Plugins_d.dll");
    Il2CppMethod methodAccessRes("AovTdr.dll");

    espManager = new EntityManager();
    ActorLinker_enemy = new EntityManager();

     // ESP
    ActorLinker_IsHostPlayer = (bool (*)(void *))GetMethodOffset(oxorany("Project_d.dll"), oxorany("Kyrios.Actor"), oxorany("ActorLinker"), oxorany("IsHostPlayer"), 0);  
    ActorLinker_ActorTypeDef = (int (*)(void *))GetMethodOffset(oxorany("Project_d.dll"), oxorany("Kyrios.Actor"), oxorany("ActorLinker"), oxorany("get_objType"), 0);     
    ActorLinker_COM_PLAYERCAMP = (int (*)(void *))GetMethodOffset(oxorany("Project_d.dll"), oxorany("Kyrios.Actor"), oxorany("ActorLinker"), oxorany("get_objCamp"), 0); 
    ActorLinker_getPosition = (Vector3(*)(void *))GetMethodOffset(oxorany("Project_d.dll"), oxorany("Kyrios.Actor"), oxorany("ActorLinker"), oxorany("get_position"), 0);   
    ActorLinker_get_bVisible = (bool (*)(void *))GetMethodOffset(oxorany("Project_d.dll"), oxorany("Kyrios.Actor"), oxorany("ActorLinker"), oxorany("get_bVisible"), 0);

    LActorRoot_LHeroWrapper = (uintptr_t(*)(void *))GetMethodOffset(oxorany("Project.Plugins_d.dll"), oxorany("NucleusDrive.Logic"), oxorany("LActorRoot"), oxorany("AsHero"), 0);
    LActorRoot_COM_PLAYERCAMP = (int (*)(void *))GetMethodOffset(oxorany("Project.Plugins_d.dll"), oxorany("NucleusDrive.Logic"), oxorany("LActorRoot"), oxorany("GiveMyEnemyCamp"), 0);
      
    LObjWrapper_get_IsDeadState = (bool (*)(void *))GetMethodOffset(oxorany("Project.Plugins_d.dll"), oxorany("NucleusDrive.Logic"), oxorany("LObjWrapper"), oxorany("get_IsDeadState"), 0);
    LObjWrapper_IsAutoAI = (bool (*)(void *))GetMethodOffset(oxorany("Project.Plugins_d.dll"), oxorany("NucleusDrive.Logic"), oxorany("LObjWrapper"), oxorany("IsAutoAI"), 0); 

    ValuePropertyComponent_get_actorHp = (int (*)(void *))GetMethodOffset(oxorany("Project.Plugins_d.dll"), oxorany("NucleusDrive.Logic"), oxorany("ValuePropertyComponent"), oxorany("get_actorHp"), 0);   
    ValuePropertyComponent_get_actorHpTotal = (int (*)(void *))GetMethodOffset(oxorany("Project.Plugins_d.dll"), oxorany("NucleusDrive.Logic"), oxorany("ValuePropertyComponent"), oxorany("get_actorHpTotal"), 0);
    ValueLinkerComponent_get_actorEpTotal = (int (*)(void *))GetMethodOffset(oxorany("Project_d.dll"), oxorany("Kyrios.Actor"), oxorany("ValueLinkerComponent"), oxorany("get_actorHpTotal"), 0);
    ValueLinkerComponent_get_actorSoulLevel = (int (*)(void *))GetMethodOffset(oxorany("Project_d.dll"), oxorany("Kyrios.Actor"), oxorany("ValueLinkerComponent"), oxorany("get_actorSoulLevel"), 0);
    ValuePropertyComponent_get_actorSoulLevel = (int (*)(void *))GetMethodOffset(oxorany("Project.Plugins_d.dll"), oxorany("NucleusDrive.Logic"), oxorany("ValuePropertyComponent"), oxorany("get_actorSoulLevel"), 0);
    ValuePropertyComponent_get_actorEp = (int (*)(void *))GetMethodOffset(oxorany("Project.Plugins_d.dll"), oxorany("NucleusDrive.Logic"), oxorany("ValuePropertyComponent"), oxorany("get_actorEp"), 0);
    ValuePropertyComponent_get_actorEpTotal = (int (*)(void *))GetMethodOffset(oxorany("Project.Plugins_d.dll"), oxorany("NucleusDrive.Logic"), oxorany("ValuePropertyComponent"), oxorany("get_actorEpTotal"), 0);
 
    Reqskill = (bool (*)(void *)) GetMethodOffset(oxorany("Project_d.dll"), oxorany("Assets.Scripts.GameLogic"), oxorany("SkillSlot"), oxorany("RequestUseSkill"), 0);
    Reqskill2 = (bool (*)(void *,bool))GetMethodOffset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameLogic"),oxorany("SkillSlot"),oxorany("ReadyUseSkill"), 1);



    botro = GetFieldOffset("Project_d.dll", "Kyrios.Actor", "HeroWrapperData", "m_skillSlot3Unlock");
    cphutro = GetFieldOffset("Project_d.dll", "Kyrios.Actor", "HeroWrapperData", "heroWrapSkillData_5");
    c1 = GetFieldOffset("Project_d.dll", "Kyrios.Actor", "HeroWrapperData", "heroWrapSkillData_2");
    c2 = GetFieldOffset("Project_d.dll", "Kyrios.Actor", "HeroWrapperData", "heroWrapSkillData_3");
    c3 = GetFieldOffset("Project_d.dll", "Kyrios.Actor", "HeroWrapperData", "heroWrapSkillData_4");
    Skill5OK = GetFieldOffset(oxorany("Project_d.dll"), oxorany("Kyrios.Actor"), oxorany("HeroWrapperData"), oxorany("m_commonSkillID")); // ID bổ trợ
    MowenIDzz = GetFieldOffset(oxorany("Project_d.dll"), oxorany("Kyrios.Actor"), oxorany("HeroWrapperData"), oxorany("m_mainMowenID")); // ID Phù Trợ
    
    m_isCharging = (uintptr_t)GetFieldOffset("Project_d.dll","Assets.Scripts.GameSystem","CSkillButtonManager","m_isCharging");
	m_currentSkillSlotType = (uintptr_t)GetFieldOffset("Project_d.dll","Assets.Scripts.GameSystem","CSkillButtonManager" , "m_currentSkillSlotType");
    AsHero = (uintptr_t (*) (void *)) GetMethodOffset("Project_d.dll","Kyrios.Actor","ActorLinker" ,"AsHero", 0);
    GetAwakeSkinData = (void *(*)(uint32_t))GetMethodOffset(oxorany("Project_d.dll"), oxorany("Assets.Scripts.GameSystem"), oxorany("AwakeSkinHelper"), oxorany("GetAwakeSkinData"), 1);
    old_RefreshHeroPanel = (void (*)(void*, bool, bool, bool)) GetMethodOffset("Project_d.dll","Assets.Scripts.GameSystem", "HeroSelectNormalWindow","RefreshHeroPanel", 3);

    get_playerCenter = (void* (*)())GetMethodOffset(oxorany("Project_d.dll"),oxorany("Kyrios"),oxorany("KyriosFramework"),oxorany("get_playerCenter"), 0);
    get_VHostLogic = (void* (*)())GetMethodOffset(oxorany("Project_d.dll"),oxorany("Kyrios"),oxorany("KyriosFramework"),oxorany("get_hostLogic"), 0);
    GetMasterRoleInfo = (void* (*)(void *))GetMethodOffset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameSystem"),oxorany("CRoleInfoManager"),oxorany("GetMasterRoleInfo"), 0);
    GetCurrentRankDetail = (void* (*)(void *))GetMethodOffset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameSystem"),oxorany("CLadderSystem"),oxorany("GetCurrentRankDetail"), 0);

   
   // get_currentZoomRate = (float(*)(void *)) Method_Project_d_dll__Moba_Camera_get_currentZoomRate_0;
    //Set_fieldOfView = (void(*)(void *,float)) Method_Project_d_dll__Moba_Camera_set_currentZoomRate_1;


//==========================================
OpenWaterUIDOffset = methodAccessSystem.getClass("Assets.Scripts.GameSystem","CLobbySystem").getMethod("OpenWaterMark", 0);
HOOK(OpenWaterUIDOffset,OpenWaterMark, _OpenWaterMark);
//==========================================

GetCameraOffset = methodAccessSystem.getClass("","CameraSystem").getMethod("GetZoomRate", 0);
UpdateCameraOffset = methodAccessSystem.getClass("","CameraSystem").getMethod("Update", 0);
SetVisibleOffset = methodAccessSystem2.getClass("NucleusDrive.Logic", "LVActorLinker").getMethod("SetVisible", 3);
GetSkinOffset = methodAccessSystem.getClass("Assets.Scripts.GameLogic","CActorInfo").getMethod("GetSkin", 1);
UnpackEvoOffset = methodAccessRes.getClass("CSProtocol","COMDT_CHOICEHERO").getMethod("unpack", 2);

dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{

   //HOOK(Il2CppMethod("Project_d.dll").getClass("", "Moba_Camera").getMethod("Update", 0), Moba_CameraUpdate, old_Moba_CameraUpdate);

   HOOK(GetCameraOffset, _getZoomRate, getZoomRate);
   HOOK(UpdateCameraOffset, _UpdateCamera, UpdateCamera);
   HOOK(SetVisibleOffset,LActorRoot_Visible, _LActorRoot_Visible);
   HOOK(GetSkinOffset, GetSkin, _GetSkin);
   HOOK(UnpackEvoOffset, unpack1, _unpack1);
  });

//==========================================


IsOpenOffset = methodAccessSystem.getClass("Assets.Scripts.GameSystem","PersonalButton").getMethod("IsOpen", 0);
PersonalBtnIdOffset = methodAccessSystem.getClass("Assets.Scripts.GameSystem","PersonalButton").getMethod("get_PersonalBtnId", 0);
ShowHeroInfoOffset = methodAccessSystem.getClass("Assets.Scripts.GameSystem", "HeroInfoPanel").getMethod("ShowHeroInfo", 2);
ShowSkillStateInfoOffset = methodAccessSystem.getClass("", "MiniMapHeroInfo").getMethod("ShowSkillStateInfo", 1);
ShowHeroHpInfoOffset = methodAccessSystem.getClass("", "MiniMapHeroInfo").getMethod("ShowHeroHpInfo", 1);

dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(4.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{

    //Unlock Nút
	HOOK(IsOpenOffset,IsOpen, old_IsOpen);
	HOOK(PersonalBtnIdOffset,get_PersonalBtnId, old_get_PersonalBtnId);
    HOOK(ShowHeroInfoOffset,ShowHeroInfo, _ShowHeroInfo);	
    HOOK(ShowSkillStateInfoOffset,ShowSkillStateInfo, _ShowSkillStateInfo);
    HOOK(ShowHeroHpInfoOffset,ShowHeroHpInfo, _ShowHeroHpInfo);

     });
     
//==========================================

        //Doi ten Dai
    CheckRoleNameOffset = methodAccessSystem.getClass("","Utility").getMethod("CheckRoleName", 1);
    RemoveSpaceOffset = methodAccessSystem.getClass("Assets.Scripts.UI","CUIUtility").getMethod("RemoveSpace", 1);
    IsCanSellOffset = methodAccessSystem.getClass("Assets.Scripts.GameSystem","CItem").getMethod("get_IsCanSell", 0);
    SendInBattleMsgOffset = methodAccessSystem.getClass("Assets.Scripts.GameSystem","InBattleMsgNetCore").getMethod("SendInBattleMsg_InputChat", 2);
    UpdateFrameLaterOffset = methodAccessSystem2.getClass("NucleusDrive.Logic","LFrameSynchr").getMethod("UpdateFrameLater", 0);

dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(6.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
      
      HOOK(RemoveSpaceOffset,_RemoveSpace,RemoveSpace);
      HOOK(CheckRoleNameOffset,_CheckRoleName, CheckRoleName);
      HOOK(UpdateFrameLaterOffset,UpdateFrameLater, old_UpdateFrameLater);
      HOOK(IsCanSellOffset,get_IsCanSell, _get_IsCanSell);
      HOOK(SendInBattleMsgOffset,SendInBattleMsg_InputChat, _SendInBattleMsg_InputChat);
      
     });



//==========================================

UnpackOffset = methodAccessRes.getClass("CSProtocol","COMDT_HERO_COMMON_INFO").getMethod("unpack", 2);
OnClickSelectOffset = methodAccessSystem.getClass("Assets.Scripts.GameSystem","HeroSelectNormalWindow").getMethod("OnClickSelectHeroSkin", 2);
IsCanUseSkinOffset = methodAccessSystem.getClass("Assets.Scripts.GameSystem","CRoleInfo").getMethod("IsCanUseSkin", 2);
GetHeroSkinIdOffset = methodAccessSystem.getClass("Assets.Scripts.GameSystem","CRoleInfo").getMethod("GetHeroWearSkinId", 1);
IsHaveHeroSkinOffset = methodAccessSystem.getClass("Assets.Scripts.GameSystem","CRoleInfo").getMethod("IsHaveHeroSkin", 3);

dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(8.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
 
    //Unlock Skin
   HOOK(UnpackOffset,unpack, old_unpack);
   HOOK(OnClickSelectOffset,OnClickSelectHeroSkin, old_OnClickSelectHeroSkin);
   HOOK(IsCanUseSkinOffset,IsCanUseSkin, old_IsCanUseSkin);
   HOOK(GetHeroSkinIdOffset,GetHeroWearSkinId, old_GetHeroWearSkinId);
   HOOK(IsHaveHeroSkinOffset,IsHaveHeroSkin, old_IsHaveHeroSkin); 
     });
//==========================================
   
InitTeamHeroListOffset = methodAccessSystem.getClass("Assets.Scripts.GameSystem","HeroSelectBanPickWindow").getMethod("InitTeamHeroList", 4);
TeamLaderGradeMaxOffset = methodAccessSystem.getClass("Assets.Scripts.GameSystem","CMatchingSystem").getMethod("checkTeamLaderGradeMax", 1);
Bugoffset = methodAccessSystem.getClass("Assets.Scripts.GameLogic","SkillControlIndicator").getMethod("LateUpdate", 1);
IsHostProfileOffset = methodAccessSystem.getClass("Assets.Scripts.GameSystem","CPlayerProfile").getMethod("get_IsHostProfile", 0);
SkinPicOffset = methodAccessRes.getClass("ResData","ResHeroSkin").getMethod("get_szSkinPicID", 0);
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(10.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
   
   //Show Avatar && Hiện Tên Cấm Chọn
     HOOK(InitTeamHeroListOffset, InitTeamHeroList, _InitTeamHeroList);
     HOOK(TeamLaderGradeMaxOffset,checkTeamLaderGradeMax, _checkTeamLaderGradeMax);
     //Hiện Lịch Sử Đấu
	HOOK(IsHostProfileOffset,IsHostProfile, _IsHostProfile);
	HOOK(Bugoffset,SkillControlIndicator, _SkillControlIndicator);
	HOOK(SkinPicOffset, get_szSkinPicID, _get_szSkinPicID);

     });


//==========================================
UpdateLogicOffset = methodAccessSystem.getClass("Assets.Scripts.GameSystem","CSkillButtonManager").getMethod("UpdateLogic", 1);
GetUseSkillDirectionOffset = methodAccessSystem.getClass("Assets.Scripts.GameLogic","SkillControlIndicator").getMethod("GetUseSkillDirection", 1);
UpdateLogicESPOffset = methodAccessSystem2.getClass("NucleusDrive.Logic", "LActorRoot").getMethod("UpdateLogic", 1);
DestroyActorOffset = methodAccessSystem.getClass("Kyrios.Actor", "ActorLinker").getMethod("DestroyActor", 0);
DestroyActor2Offset = methodAccessSystem2.getClass("NucleusDrive.Logic", "LActorRoot").getMethod("DestroyActor", 1);
     dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(12.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
    // H O O K  ESP
// 	public void UpdateLogic(int delta) { }
    HOOK(UpdateLogicESPOffset, LActorRoot_UpdateLogic, old_LActorRoot_UpdateLogic);//esp
// 	public void DestroyActor() { }
    HOOK(DestroyActorOffset, ActorLinker_ActorDestroy, old_ActorLinker_ActorDestroy);//esp
//	public void DestroyActor(bool bTriggerEvent) { }
    HOOK(DestroyActor2Offset, LActorRoot_ActorDestroy, old_LActorRoot_ActorDestroy);
 //Aim Skill
	HOOK(UpdateLogicOffset,UpdateLogic, _UpdateLogic);
	HOOK(GetUseSkillDirectionOffset,GetUseSkillDirection, _GetUseSkillDirection);
	
	});


//==========================================

     ShowWinLoseOffset = methodAccessSystem.getClass("Assets.Scripts.GameLogic","BattleLogic").getMethod("ShowWinLose", 1);
     SetPlayerNameOffset = methodAccessSystem.getClass("Assets.Scripts.GameLogic","HudComponent3D").getMethod("SetPlayerName", 4);
     SkillSlotOffset = methodAccessSystem.getClass("Assets.Scripts.GameLogic","SkillSlot").getMethod("LateUpdate", 1);
     IsAwakeSkinOffset = methodAccessSystem.getClass("Assets.Scripts.GameSystem","AwakeSkinHelper").getMethod("IsAwakeSkin", 1);
     UpdateNameCDOffset = methodAccessSystem.getClass("Kyrios.Actor","ActorLinker").getMethod("Update", 0);

     dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(14.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{

     	  //Show CD Name
     HOOK(UpdateNameCDOffset,AUpdate, old_Update);
     HOOK(ShowWinLoseOffset,ShowWinLose, _ShowWinLose);
     HOOK(SetPlayerNameOffset,_SetPlayerName, SetPlayerName);
     HOOK(SkillSlotOffset,Skslot, _Skslot);
     HOOK(IsAwakeSkinOffset,IsAwakeSkin, _IsAwakeSkin); 
     
     });
     //==========================================

     CreateHeroDataOffset = methodAccessSystem2.getClass("NucleusDrive.Statistics","BattleStatistic").getMethod("CreateHeroData", 2);
     HandleGameSettleOffset = methodAccessSystem.getClass("Assets.Scripts.GameLogic","LobbyMsgHandler").getMethod("HandleGameSettle", 4);
     OnEnterOffset = methodAccessSystem.getClass("Assets.Scripts.GameSystem","PVPLoadingView").getMethod("OnEnter", 0);
     CreateGameOverSummaryOffset = methodAccessSystem2.getClass("NucleusDrive.Statistics","BattleStatistic").getMethod("CreateGameOverSummary", 0);


 dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(16.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{

    HOOK(CreateHeroDataOffset,CreateHeroData , _CreateHeroData);
    HOOK(HandleGameSettleOffset,HandleGameSettle , _HandleGameSettle);
    HOOK(OnEnterOffset,OnEnter, old_OnEnter);
    HOOK(CreateGameOverSummaryOffset,CreateGameOverSummary, _CreateGameOverSummary);

   /*HOOK(Il2CppMethod("Project_d.dll").getClass("Assets.Scripts.Framework","RelaySvrConnectProxy/RelaySvrConnector").getMethod("Disconnect", 0), Disconnect, _Disconnect);
    //HOOK(GetSkinOffset,GetSkin, _GetSkin);
 */
  });
  
//==========================================


ShowKhungRankOffset = Il2CppMethod("Project_d.dll").getClass("Assets.Scripts.GameSystem", "PVPLoadingView").getMethod("OnEnter", 0) + 0x1018;
ShowBoTroOffset = Il2CppMethod("Project_d.dll").getClass("Assets.Scripts.GameSystem", "UIBattleStatView/HeroItem").getMethod("updateTalentSkillCD", 1) + 0x228;


dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(18.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
    static dispatch_once_t onceToken;
     dispatch_once(&onceToken, ^{

       Hook1110("Frameworks/UnityFramework.framework/UnityFramework", ShowKhungRankOffset, "1F2003D5"); // rank
       Hook1110("Frameworks/UnityFramework.framework/UnityFramework", ShowBoTroOffset, "1F2003D5"); // btro

});
});
 });
}

    
- (void)viewDidLoad{
   
   /*
   dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 10 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
    [FTIndicator showToastMessage:@"Copying : Ngô Phong 🙈"];  
   });
    */

    [super viewDidLoad];
    initial_setup();
    startFileWatcherz();
    self.mtkView.device = self.device;
    self.mtkView.delegate = self;
    self.mtkView.clearColor = MTLClearColorMake(0, 0, 0, 0);
    self.mtkView.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0];
    self.mtkView.clipsToBounds = YES;

    if ([saveSetting objectForKey:@"HackMap"] != nil) { 
        HackMap = [saveSetting boolForKey:@"HackMap"];
        ShowUlti = [saveSetting boolForKey:@"ShowUlti"];
        ShowCD = [saveSetting boolForKey:@"ShowCD"];
        StreamerMode = [saveSetting boolForKey:@"StreamerMode"];
       
        unlockskin = [saveSetting boolForKey:@"unlockskin"];
        enableBanList = [saveSetting integerForKey:@"enableBanList"];
        selectedbutton = [saveSetting integerForKey:@"selectedbutton"];
        selectedValue2 = [saveSetting integerForKey:@"selectedValue2"];
        HeroTypeID = [saveSetting integerForKey:@"HeroTypeID"];

        OnCamera = [saveSetting boolForKey:@"OnCamera"];

        AimSkill = [saveSetting boolForKey:@"AimSkill"];
        aimSkill1 = [saveSetting boolForKey:@"aimSkill1"];
        aimSkill2 = [saveSetting boolForKey:@"aimSkill2"];
        aimSkill3 = [saveSetting boolForKey:@"aimSkill3"];
        aimType = [saveSetting integerForKey:@"aimType"];
        drawType = [saveSetting integerForKey:@"drawType"];
        LazeThemes = (int)[saveSetting integerForKey:@"LazeThemes"];
        LazeElsu[0] = [saveSetting floatForKey:@"LazeElsuR"];
        LazeElsu[1] = [saveSetting floatForKey:@"LazeElsuG"];
        LazeElsu[2] = [saveSetting floatForKey:@"LazeElsuB"];
        LazeElsu[3] = [saveSetting floatForKey:@"LazeElsuA"];
        ColorCrosshair[0] = [saveSetting floatForKey:@"ColorCrosshairR"];
        ColorCrosshair[1] = [saveSetting floatForKey:@"ColorCrosshairG"];
        ColorCrosshair[2] = [saveSetting floatForKey:@"ColorCrosshairB"];
        ColorCrosshair[3] = [saveSetting floatForKey:@"ColorCrosshairA"];

        ShowLsd = [saveSetting boolForKey:@"ShowLsd"];
        ShowLockName = [saveSetting boolForKey:@"ShowLockName"];
        ShowAvatar = [saveSetting boolForKey:@"ShowAvatar"];
        spamchat = [saveSetting boolForKey:@"spamchat"];
        solanchat = [saveSetting integerForKey:@"solanchat"];
        ShowBoTroz = [saveSetting boolForKey:@"ShowBoTroz"];
        ShowRank = [saveSetting boolForKey:@"ShowRank"];

        Bantuido = [saveSetting boolForKey:@"Bantuido"];
        XoaLichSu = [saveSetting boolForKey:@"XoaLichSu"];
        TopSelected = [saveSetting integerForKey:@"TopSelected"];
        selectedRank = [saveSetting integerForKey:@"selectedRank"];
        Mod_Rank = [saveSetting boolForKey:@"Mod_Rank"];
        enableTopSelect = [saveSetting boolForKey:@"enableTopSelect"];
        selectedStar = [saveSetting integerForKey:@"selectedStar"];
        BugSkillRange = [saveSetting boolForKey:@"BugSkillRange"];

        autott = [saveSetting boolForKey:@"autott"];
        onlymt = [saveSetting boolForKey:@"onlymt"];
        autobocpha = [saveSetting boolForKey:@"autobocpha"];
        bangsuong = [saveSetting boolForKey:@"bangsuong"];
        capcuuz = [saveSetting boolForKey:@"capcuuz"];
        hoimau = [saveSetting boolForKey:@"hoimau"];

        maubotro = [saveSetting floatForKey:@"maubotro"];
        mauphutro = [saveSetting floatForKey:@"mauphutro"];
        mauhoimau = [saveSetting floatForKey:@"mauhoimau"];
        maucapcuu = [saveSetting floatForKey:@"maucapcuu"];

        SetFieldOfView = [saveSetting floatForKey:@"SetFieldOfView"];
    }
}

#pragma mark - Interaction

- (void)updateIOWithTouchEvent:(UIEvent *)event
{
    UITouch *anyTouch = event.allTouches.anyObject;
    CGPoint touchLocation = [anyTouch locationInView:self.view];
    ImGuiIO &io = ImGui::GetIO();
    io.MousePos = ImVec2(touchLocation.x, touchLocation.y);

    BOOL hasActiveTouch = NO;
    for (UITouch *touch in event.allTouches)
    {
        if (touch.phase != UITouchPhaseEnded && touch.phase != UITouchPhaseCancelled)
        {
            hasActiveTouch = YES;
            break;
        }
    }
    io.MouseDown[0] = hasActiveTouch;
}

bool isJailbroken() {
    // Kiểm tra file /bin/bash
    struct stat s;
    return (stat("/bin/bash", &s) == 0);
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self updateIOWithTouchEvent:event];
}

- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self updateIOWithTouchEvent:event];
}

- (void)touchesCancelled:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self updateIOWithTouchEvent:event];
}

- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self updateIOWithTouchEvent:event];
}



// Hàm vẽ ngôi sao 5 cánh
static void DrawStar(ImDrawList* draw, ImVec2 center, float radius, ImColor color, int points = 5)
{
    std::vector<ImVec2> verts;
    float innerRadius = radius * 0.5f;
    for (int i = 0; i < points * 2; i++)
    {
        float r = (i % 2 == 0) ? radius : innerRadius;
        float angle = i * IM_PI / points - IM_PI / 2.0f;
        verts.push_back(ImVec2(center.x + cosf(angle) * r, center.y + sinf(angle) * r));
    }
    draw->AddConvexPolyFilled(verts.data(), verts.size(), color);
}



#pragma mark - MTKViewDelegate
- (void)drawInMTKView:(MTKView*)view
{
    hideRecordTextfield.secureTextEntry = StreamerMode;
    ImGuiIO& io = ImGui::GetIO();
    io.DisplaySize.x = view.bounds.size.width;
    io.DisplaySize.y = view.bounds.size.height;

    CGFloat framebufferScale = view.window.screen.scale ?: UIScreen.mainScreen.scale;
   if (iPhonePlus) {
        io.DisplayFramebufferScale = ImVec2(2.60, 2.60);
    } else {
        io.DisplayFramebufferScale = ImVec2(framebufferScale, framebufferScale);
     }
    io.DeltaTime = 1 / float(view.preferredFramesPerSecond ? : 120);
    
    id<MTLCommandBuffer> commandBuffer = [self.commandQueue commandBuffer];
    
    
        // Tải texture từ Base64 trong Logo.h
    static id<MTLTexture> bg_texture = nil;
    if (bg_texture == nil) {
        NSString* base64String = autobocphaz; // Sử dụng macro từ Logo.h
        std::string base64_std_string([base64String UTF8String]);
        bg_texture = LoadTextureFromBase64(self.device, base64_std_string);
    }
     
 // Tải texture từ Base64 trong Logo.h
    static id<MTLTexture> bg_texture2 = nil;
    if (bg_texture2 == nil) 
{
        NSString* base64String = autobangsuongz; // Sử dụng macro từ Logo.h
        std::string base64_std_string([base64String UTF8String]);
        bg_texture2 = LoadTextureFromBase64(self.device, base64_std_string);
    }

    // Tải texture từ Base64 trong Logo.h
    static id<MTLTexture> bg_texture3 = nil;
    if (bg_texture3 == nil) 
{
        NSString* base64String = AutoCapCuuz; // Sử dụng macro từ Logo.h
        std::string base64_std_string([base64String UTF8String]);
        bg_texture3 = LoadTextureFromBase64(self.device, base64_std_string);

}
           // Tải texture từ Base64 trong Logo.h
    static id<MTLTexture> bg_texture4 = nil;
    if (bg_texture4 == nil) 
{
        NSString* base64String = trungtriz; // Sử dụng macro từ Logo.h
        std::string base64_std_string([base64String UTF8String]);
        bg_texture4 = LoadTextureFromBase64(self.device, base64_std_string);
    }

        // Tải texture từ Base64 trong Logo.h
    static id<MTLTexture> bg_texture5 = nil;
    if (bg_texture5 == nil) 
{
        NSString* base64String = AutoHoiMauz; // Sử dụng macro từ Logo.h
        std::string base64_std_string([base64String UTF8String]);
        bg_texture5 = LoadTextureFromBase64(self.device, base64_std_string);
    }

     // Tải texture từ Base64 trong Logo.h
    static id<MTLTexture> bg_conhopong = nil;
    if (bg_conhopong == nil) 
{
        NSString* base64String = ConHoPong; // Sử dụng macro từ Logo.h
        std::string base64_std_string([base64String UTF8String]);
        bg_conhopong = LoadTextureFromBase64(self.device, base64_std_string);
    }

        if (MenDeal == true) 
        {
            [self.view setUserInteractionEnabled:YES];
            [self.view.superview setUserInteractionEnabled:YES];
            [menuTouchView setUserInteractionEnabled:YES];
        } 
        else if (MenDeal == false) 
        {
            [self.view setUserInteractionEnabled:NO];
            [self.view.superview setUserInteractionEnabled:NO];
            [menuTouchView setUserInteractionEnabled:NO];
        }

        MTLRenderPassDescriptor* renderPassDescriptor = view.currentRenderPassDescriptor;
        if (renderPassDescriptor != nil)
        {
            id <MTLRenderCommandEncoder> renderEncoder = [commandBuffer renderCommandEncoderWithDescriptor:renderPassDescriptor];
            [renderEncoder pushDebugGroup:@"ImGui Jane"];

            ImGui_ImplMetal_NewFrame(renderPassDescriptor);
            ImGui::NewFrame();
            
            ImFont* font = ImGui::GetFont();
            font->Scale = 16.f / font->FontSize;
            
            CGFloat x = (([UIApplication sharedApplication].windows[0].rootViewController.view.frame.size.width) - 500) / 2;
            CGFloat y = (([UIApplication sharedApplication].windows[0].rootViewController.view.frame.size.height) - 335) / 2;
            
            ImGui::SetNextWindowPos(ImVec2(x, y), ImGuiCond_FirstUseEver);
            ImGui::SetNextWindowSize(ImVec2(500, 335), ImGuiCond_FirstUseEver);
            
            if (MenDeal == true)
            {                
            std::string namedv = [[UIDevice currentDevice] name].UTF8String;
            NSDate *now = [NSDate date];
            NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
            [dateFormatter setDateFormat:@"EEEE,dd/MM/yyyy | HH:mm:ss"];
            NSString *dateString = [dateFormatter stringFromDate:now];

            UIDevice *device = [UIDevice currentDevice];
            device.batteryMonitoringEnabled = YES;
            
            float batteryLevel = device.batteryLevel * 100;
            NSString *chargingStatus = @"";
            if (device.batteryState == UIDeviceBatteryStateCharging) {
                chargingStatus = @"-  Đang Sạc";
            } else if (device.batteryState == UIDeviceBatteryStateFull) {
                chargingStatus = @"-  Đầy Pin";
            } else {
                chargingStatus = @"-  Đã Ngắt Sạc";
            }

              char appName[256] = {0}; // Tên App
              char bundleID[256] = {0}; // BundleID
              char appVersion[256] = {0}; // Version
              char deviceModel[256] = {0}; // Thông tin máy
              Cbeios *appInfo = [[Cbeios alloc] init];
              [appInfo ThanhThanh:appName bundleID:bundleID appVersion:appVersion deviceModel:deviceModel];


    char* Gnam = (char*) [[NSString stringWithFormat:nssoxorany("      POONG MEMORY / AOV IOS VIP"), appVersion] cStringUsingEncoding:NSUTF8StringEncoding];
    ImGui::Begin(Gnam, &MenDeal, ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoTitleBar);


const ImVec2 pos = ImGui::GetWindowPos();
             ImU32 colorRect = IM_COL32(48, 43, 64, 255);   // Rectangle color (RGB: 82, 100, 0
ImGui::GetWindowDrawList()->AddRectFilled(
    ImVec2(pos.x + 5,pos.y +5), 
    ImVec2(pos.x + 495, pos.y + 35), 
    colorRect
);

ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 3);  // Giảm khoảng cách dòng    
ImGui::SetCursorPosX(ImGui::GetCursorPosX() + 27);  // Giảm khoảng cách dòng

/*
ImGui::PushFont(FontThemes);
float windowWidth = ImGui::GetWindowSize().x;
float textWidth = ImGui::CalcTextSize(Gnam).x;
ImGui::SetCursorPosX((windowWidth - textWidth) * 0.5f);
ImGui::Text("%s", Gnam);
ImGui::PopFont();
*/


ImGui::PushFont(FontThemes);
ImVec2 windowPos = ImGui::GetWindowPos();
float windowWidth = ImGui::GetWindowSize().x;
float timez = ImGui::GetTime();

// Tính lại chiều rộng từng ký tự để chính xác hơn
float textWidth = 0.0f;
for (int i = 0; Gnam[i] != '\0'; ++i) {
    char c[2] = { Gnam[i], '\0' };
    textWidth += ImGui::CalcTextSize(c).x;
}

float startX = windowPos.x + (windowWidth - textWidth) * 0.5f;
float y = ImGui::GetCursorScreenPos().y;

ImDrawList* drawList = ImGui::GetWindowDrawList();
for (int i = 0; Gnam[i] != '\0'; ++i) {
    char c[2] = { Gnam[i], '\0' };

    float hue = fmodf(timez * 0.3f + i * 0.1f, 1.0f);
    float r, g, b;
    ImGui::ColorConvertHSVtoRGB(hue, 1.0f, 1.0f, r, g, b);

    drawList->AddText(ImVec2(startX, y), ImColor(r, g, b), c);
    startX += ImGui::CalcTextSize(c).x;
}
ImGui::PopFont();



// ===============================
// Ngôi sao xanh - đỏ - tím đổi màu mượt
// ===============================
ImDrawList* draw = ImGui::GetWindowDrawList();
ImVec2 basePos = pos;

float time = ImGui::GetTime();
float cycle = 4.0f; // 4 giây đổi hết một vòng
float t = fmod(time, cycle) / cycle; // [0..1]

// Bộ màu gốc
ImColor colors[3] = {
    ImColor(100, 255, 220), // Xanh neon
    ImColor(255, 80, 80),   // Đỏ neon
    ImColor(200, 160, 255)  // Tím neon
};

// Hàm lấy màu chuyển mượt giữa 3 màu
auto GetTransitionColor = [&](int index) -> ImColor {
    ImColor c1 = colors[index];
    ImColor c2 = colors[(index + 1) % 3];
    return ImLerp(c1.Value, c2.Value, t);
};

float spacing = 28.0f;
float radius = 9.0f;

for (int i = 0; i < 3; i++)
{
    ImVec2 center = ImVec2(basePos.x + 20 + i * spacing, basePos.y + 20);

    ImColor currentColor = GetTransitionColor(i);

    // Outer glow
    ImColor glowColor = currentColor;
    glowColor.Value.w = 0.4f;
    DrawStar(draw, center, radius + 4.0f, glowColor);

    // Ngôi sao chính
    DrawStar(draw, center, radius, currentColor);
}


/*
ImDrawList* draw = ImGui::GetWindowDrawList();

// Lấy thời gian hiện tại tính bằng giây
float time = ImGui::GetTime();
int currentDot = static_cast<int>(floor(time)) % 3;  // Xác định vị trí chấm phát sáng (0, 1, hoặc 2)

// Màu tối cho trạng thái chưa phát sáng
ImColor darkColors[3] = { ImColor(100, 30, 30), ImColor(100, 70, 30), ImColor(30, 100, 30) }; // Màu tối mờ

// Màu phát sáng kiểu neon cho từng chấm
ImColor glowColors[3] = { ImColor(255, 50, 50, 200), ImColor(255, 220, 100, 200), ImColor(130, 255, 130, 200) }; // Màu phát sáng đậm, hơi trong suốt

// Vẽ các chấm, kiểm tra xem có phải chấm đang phát sáng không
draw->AddCircleFilled(ImVec2(pos.x + 20, pos.y + 20), 8, currentDot == 0 ? glowColors[0] : darkColors[0], 360);
draw->AddCircleFilled(ImVec2(pos.x + 41, pos.y + 20), 8, currentDot == 1 ? glowColors[1] : darkColors[1], 360);
draw->AddCircleFilled(ImVec2(pos.x + 62, pos.y + 20), 8, currentDot == 2 ? glowColors[2] : darkColors[2], 360);

*/


//Close menu
ImGui::SetCursorPos({448, -3});
                 //ImGui::SetWindowFontScale(1.25f);
        // Đẩy các màu tạm thời cho nút
ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0, 0, 0, 0));           // Nền nút trong suốt
ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0, 0, 0, 0));    // Nền nút khi di chuột cũng trong suốt
ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0, 0, 0, 0));     // Nền nút khi nhấn cũng trong suốt
// Đẩy thuộc tính để loại bỏ viền
ImGui::PushStyleVar(ImGuiStyleVar_FrameBorderSize, 0.0f);             // Kích thước viền bằng 0

// Vẽ nút
if (ImGui::Button(ICON_FA_POWER_OFF"", ImVec2(50, 50))) {
    MenDeal = false;
}
ImGui::PopStyleVar(); 
// Khôi phục màu sắc ban đầu
ImGui::PopStyleColor(3);


            ImDrawList *draw_list = ImGui::GetWindowDrawList();
         
           ImGui::SetCursorPos({5, 40});
           ImGui::BeginChild("##LuxH7", ImVec2(120, -1), true , ImGuiWindowFlags_NoScrollbar);
     
     
           ImVec2 iconThanhNgang = ImVec2(100, 90);
           ImVec2 cursorPosNgang = ImGui::GetCursorScreenPos(); 
           draw->AddImage((void*)CFBridgingRetain(bg_conhopong), cursorPosNgang, ImVec2(cursorPosNgang.x + iconThanhNgang.x, cursorPosNgang.y + iconThanhNgang.y)); 
           ImGui::SetCursorScreenPos(ImVec2(cursorPosNgang.x + iconThanhNgang.x + 5, cursorPosNgang.y)); // Adjust the position of the checkbox 
         
           ImGui::Spacing();
           ImGui::Spacing();
           ImGui::Spacing();
           ImGui::Spacing();
           ImGui::Spacing();
           ImGui::Spacing();
           ImGui::Spacing();
           ImGui::Spacing();
           ImGui::Spacing();
           ImGui::Spacing();
           ImGui::Spacing();
           ImGui::Spacing();
           ImGui::Spacing();
           ImGui::Spacing();
           ImGui::Spacing();
           ImGui::Spacing();
           ImGui::Spacing();
           ImGui::Spacing();
           ImGui::Spacing();
           ImGui::Spacing();
           ImGui::Spacing();
           ImGui::Spacing();
           ImGui::Spacing();
           ImGui::Spacing();
           
           const float BUTTON_WIDTH = 103.0f;
           const float BUTTON_HEIGHT = 30.0f;

          if (ImGui::Button(ICON_FA_HOME" Home", ImVec2(BUTTON_WIDTH ,BUTTON_HEIGHT)))
          tab = 1;
      
          if (ImGui::Button(ICON_FA_GAMEPAD" Extra", ImVec2(BUTTON_WIDTH ,BUTTON_HEIGHT))) 
          tab = 2;

          //if (ImGui::Button(ICON_FA_EYE" ESP", ImVec2(BUTTON_WIDTH ,BUTTON_HEIGHT))) 
          //tab = 6;
      
          if (ImGui::Button(ICON_FA_FOLDER_OPEN" Skins", ImVec2(BUTTON_WIDTH ,BUTTON_HEIGHT))) 
          tab = 3;
        
         if (ImGui::Button(ICON_FA_CROSSHAIRS" Aimbot", ImVec2(BUTTON_WIDTH ,BUTTON_HEIGHT))) 
          tab = 4;

          if (ImGui::Button(ICON_FA_CROWN" Auto", ImVec2(BUTTON_WIDTH, BUTTON_HEIGHT)))
          tab = 5;

         // if (ImGui::Button(ICON_FA_COG" SETTING", ImVec2(BUTTON_WIDTH, BUTTON_HEIGHT)))
           //tab = 6;
           
      
          ImGui::EndChild();
  
          ImGui::SameLine();

         ImGui::SetCursorPos({133, 40});
       
         ImGui::BeginChild("##Khungmenu", ImVec2(-1, 235), true);
          switch (tab) {
          case 1: {
          ImGui::BeginGroup();
          ImGui::Checkbox("Đèn Pin Map", &HackMap);
          ImGui::Checkbox("Bật Camera", &OnCamera);
          ImGui::EndGroup();

          ImGui::SameLine();

          ImGui::BeginGroup();
          ImGui::Checkbox("Show Hero/HP", &ShowUlti);
          ImGui::Checkbox("Khoá Camera", &lockcam);
          ImGui::EndGroup();

          ImGui::SameLine();
           
          ImGui::BeginGroup();
          ImGui::Checkbox("Show CD", &ShowCD);
          ImGui::Checkbox("Ẩn Live", &StreamerMode);
          ImGui::EndGroup();
          

                ///ImGui::SameLine();
                
                ImGui::PushItemWidth(340);
                ImGui::SliderFloat("##Camera", &SetFieldOfView, 0.0f, 10.0f,"Độ Cao Camera : %.3f",2);
                ImGui::PopItemWidth();

                	ImGui::Spacing(); 
                    ImGui::Separator();
				
                
				if (ImGui::Button("Telegram Group!")) {
                        // Mở đường link (trên iOS hoặc macOS, dùng hệ thống gọi mở URL)
                        NSString *urlString = @"https://t.me/khongcojdau";
                        NSURL *url = [NSURL URLWithString:urlString];
                        if ([[UIApplication sharedApplication] canOpenURL:url]) {
                        [[UIApplication sharedApplication] openURL:url options:@{} completionHandler:nil];
                        }
                }

                                 ImGui::SameLine();

                if (ImGui::Button("Telegram Me!")) {
                        
                        NSString *urlString = @"https://t.me/typhibro";
                        NSURL *url = [NSURL URLWithString:urlString];
                        if ([[UIApplication sharedApplication] canOpenURL:url]) {
                        [[UIApplication sharedApplication] openURL:url options:@{} completionHandler:nil];
                        }
                 }

                  ImGui::SameLine();

               if (ImGui::Button("Zalo Group!")) {
                        // Mở đường link (trên iOS hoặc macOS, dùng hệ thống gọi mở URL)
                        NSString *urlString = @"https://zalo.me/g/lgwcoh497";
                        NSURL *url = [NSURL URLWithString:urlString];
                        if ([[UIApplication sharedApplication] canOpenURL:url]) {
                        [[UIApplication sharedApplication] openURL:url options:@{} completionHandler:nil];
                        }
                 }
                 
/*
if(ImGui::Button(ICON_FA_TRASH" Xoá Data"))
                 {
                    startFileWatcher();
                 }
*/

                //ImGui::Separator();

              //  ImGui::Spacing();

          ImGui::Text("Tên App:");
          ImGui::SameLine();
          ImGui::TextColored(ImColor(255, 255, 0), "%s", appName); 

          ImGui::SameLine();

          ImGui::Text("Version:");
          ImGui::SameLine();
          ImGui::TextColored(ImColor(0, 255, 0), "%s", appVersion); 


                        ImGui::Text("Thiết Bị:");
                        ImGui::SameLine();
                        ImGui::TextColored(ImColor(255, 0, 255), "%s", deviceModel);
                       
                       /*
                        ImGui::SameLine();
                        ImGui::TextColored(ImVec4(1.0f, 1.0f, 1.0f, 1.0f), "Trạng Thái:");
                        ImGui::SameLine();
                        if (isJailbroken()) {
                        ImGui::TextColored(ImVec4(1.0f, 0.0f, 0.0f, 1.0f), "Đã Jailbreak !");
                        }
                         else {
                         ImGui::TextColored(ImVec4(0.0f, 1.0f, 0.0f, 1.0f), "Chưa Jailbreak !");
                        }
                        */
                         
                        ImGui::Text("BundleID:");
                        ImGui::SameLine();
                        ImGui::TextColored(ImColor(225, 225, 0), "%s", bundleID); 
                        
                        ImGui::TextColored(ImColor(255, 255, 255), "Thời Gian:");
                        ImGui::SameLine();
                        ImGui::TextColored(ImColor(0, 255, 255), "%s", [dateString UTF8String]);


                ImColor white(255, 255, 255);
                ImGui::TextColored(white, "Thời Hạn Pin:");

                ImColor yellow(255, 255, 0);
                ImGui::SameLine();
                ImGui::TextColored(yellow, "%.0f%%", batteryLevel);

                ImColor green(0, 255, 0);
                ImColor red(255, 0, 0);

                ImColor statusTextColor;
                if (device.batteryState == UIDeviceBatteryStateCharging) {
                    statusTextColor = green;
                } else {
                    statusTextColor = red;
                }
                ImGui::SameLine();
                ImGui::TextColored(statusTextColor, "%s", [chargingStatus UTF8String]);

          }
            break;	
/*
            case 6: {
                ImGui::BeginGroup();
                
                ImGui::Checkbox("ESP Enable", &ESPEnable);
                ImGui::SameLine();
                ImGui::Checkbox("Check Khi Thấy", &CheckFogEsp);

                ImGui::Separator();
                ImGui::Checkbox("Box 3D", &PlayerBox3D);
                ImGui::SameLine();
                ImGui::Checkbox("ESP Health", &PlayerHealth);
                ImGui::SameLine();
                ImGui::Checkbox("ESP Line", &PlayerLine);

                ImGui::Checkbox("ESP Distance", &PlayerDistance);
                ImGui::SameLine();
                ImGui::Checkbox("Show Icon BT", &ShowIconBT);

                ImGui::EndGroup();
            }	
            break;  
*/      	                                           
            case 2: {   

                ImGui::BeginGroup();
                ImGui::Checkbox("Hiện Lịch Sử Đấu", &ShowLsd);
                ImGui::Checkbox("Hiện Cấm Chọn", &ShowLockName);
                ImGui::Checkbox("Hiện Avatar", &ShowAvatar);
                ImGui::Checkbox("Hiện Khung Rank", &ShowRank);
                ImGui::Checkbox("Hiện Bổ Trợ", &ShowBoTroz);
               // ImGui::Checkbox("Bán All Balo", &Bantuido);

                ImGui::EndGroup();

                ImGui::SameLine();

                ImGui::BeginGroup();
                ImGui::Checkbox("Xoá Lịch Sử Đấu", &XoaLichSu);
                //ImGui::Checkbox("Xoá Tố Cáo", &XoaToCao);
                //ImGui::Checkbox("Xu Clan No 000", &XuClan);
                ImGui::Checkbox("Bug Skill Xa", &BugSkillRange);
                ImGui::Checkbox("Bán All Balo", &Bantuido);

                ImGui::EndGroup();

                ImGui::Separator();
                ImGui::Checkbox("Huỷ Trận Đấu", &AutoWinz);
                
                /*
                ImGui::SameLine();
                static const char* modes[] = { "Win", "Loss" };
                ImGui::PushItemWidth(70);
                ImGui::Combo("##AutoWinLos", &AutoWinTowerMode, modes, IM_ARRAYSIZE(modes));
                ImGui::PopItemWidth();
                */

                ImGui::SameLine();
                HelpMarker("Chức Năng Huỷ Trận Rủi Ro \nKhoá Nhiều Năm Bật Phút Thứ 3 Trận Đấu !");
                ImGui::SameLine();

                ImGui::Checkbox("Đổi Tên Dài", &DoiTenDai);
                ImGui::SameLine();
                HelpMarker("Mở Lên Khi Muốn Đổi Tên Dài \nSau Khi Ghi Xong Tên Cần \nTắt Chức Năng Này Để Có Thể \nĐổi Tên Thành Công");

                ImGui::Checkbox("Spam Chat", &spamchat);
                ImGui::SameLine();
                ImGui::PushItemWidth(200);
                ImGui::SliderInt("##chatband", &solanchat , 1 , 100,"Số Lần Chat : %.1d");
                ImGui::PopItemWidth();
                       }
            break;
            case 3: {
           
              ImGui::Checkbox("Unlock Skin All", &unlockskin);
              ImGui::SameLine();
              ImGui::Checkbox("Unlock Skin SSS", &unlocksss);
              //SkinSSS_AOV();
              ImGui::PushItemWidth(260);
              DrawModButton();
              DrawModNotify();
              ImGui::PopItemWidth();
              ImGui::Checkbox("Mod Rank", &Mod_Rank);
              ImGui::SameLine();
              ImGui::Checkbox("Mod Top", &enableTopSelect);
              ModTopLQ();
              ShowRankMenu();

              DrawHeroSkinInfo();
            
            }
            break;
            
            case 4: {
            
                ImGui::Checkbox("Bật Aimbot", &AimSkill);
                      ImGui::SameLine();
                      HelpMarker("Aim Các Loại Tướng Tuỳ Chọn Ở Dưới");
                      
                      ImGui::Checkbox("Aim Skill 1", &aimSkill1);
                      ImGui::SameLine();
                        ImGui::Checkbox("Aim Skill 2", &aimSkill2);
                        ImGui::SameLine();
                        ImGui::Checkbox("Aim Skill 3", &aimSkill3);
                        DrawAimbotTab();
                        DoLeckID();
                        //ImGui::SameLine();
                     
                        ImGui::SliderFloat("##LinAimbot", &Radius, 0.0f, 100.0f, "Khoảng Cách : %.3f Mét",2);
                        ImGui::SliderFloat("##DoLech", &DoLechAim,0.0f, 10.0f, "Độ Lệch : %.3f",2);
                        //ImGui::ColorEdit4("Màu Tâm",ColorCrosshair);
//ImGui::ColorEdit4("Đường Kẻ",LazeElsu);
                       //ImGui::SliderFloat("##Laze", &LazeThemes, 0, 4, "Đường Kẻ Đậm Màu : %.1f",2);
            }
            break;
            
            case 5: {

                    
                    ImVec2 iconSize4 = ImVec2(25, 25); // Adjust the size of the icon 
                    ImVec2 cursorPos4 = ImGui::GetCursorScreenPos(); 
                    draw->AddImage((void*)CFBridgingRetain(bg_texture4), cursorPos4, ImVec2(cursorPos4.x + iconSize4.x, cursorPos4.y + iconSize4.y)); 
                    ImGui::SetCursorScreenPos(ImVec2(cursorPos4.x + iconSize4.x + 5, cursorPos4.y)); // Adjust the position of the checkbox 
                       ImGui::Checkbox("Trừng Trị", &autott);
                       ImGui::SameLine();
                       HelpMarker("[Bùa Xanh, Bùa Đỏ]\n[Rồng, Tà Thần]");
                     
                      
                       ImGui::SameLine();
                       ImGui::Checkbox("Mục Tiêu", &onlymt);
                       ImGui::SameLine();
                       HelpMarker("[Rồng, Tà Thần]");



                    ImVec2 iconSize = ImVec2(25, 25); // Adjust the size of the icon 
                    ImVec2 cursorPos = ImGui::GetCursorScreenPos(); 
                    draw->AddImage((void*)CFBridgingRetain(bg_texture), cursorPos, ImVec2(cursorPos.x + iconSize.x, cursorPos.y + iconSize.y)); 
                    ImGui::SetCursorScreenPos(ImVec2(cursorPos.x + iconSize.x + 5, cursorPos.y)); // Adjust the position of the checkbox 
                       //ImGui::SameLine();
                       ImGui::Checkbox("Bộc Phá", &autobocpha);
                       ImGui::SameLine();
                       ImGui::PushItemWidth(215);
                       ImGui::SliderFloat("##lol", &maubotro , 0.0f , 100.0f,"Địch Dưới %.2f%% Máu");
                       ImGui::PopItemWidth();

                    ImVec2 iconSize2 = ImVec2(25, 25); // Adjust the size of the icon 
                    ImVec2 cursorPos2 = ImGui::GetCursorScreenPos(); 
                    draw->AddImage((void*)CFBridgingRetain(bg_texture2), cursorPos2, ImVec2(cursorPos2.x + iconSize2.x, cursorPos2.y + iconSize2.y)); 
                    ImGui::SetCursorScreenPos(ImVec2(cursorPos2.x + iconSize2.x + 5, cursorPos2.y)); // Adjust the position of the checkbox 
                       ImGui::Checkbox("Băng Sương", &bangsuong);
                       ImGui::SameLine();
                       ImGui::PushItemWidth(192);
                       ImGui::SliderFloat("##cxd", &mauphutro , 0.0f , 100.0f,"Địch Dưới %.2f%% Máu");
                       ImGui::PopItemWidth();
                       
                    ImVec2 iconSize3 = ImVec2(25, 25); // Adjust the size of the icon 
                    ImVec2 cursorPos3 = ImGui::GetCursorScreenPos(); 
                    draw_list->AddImage((void*)CFBridgingRetain(bg_texture3), cursorPos3, ImVec2(cursorPos3.x + iconSize3.x, cursorPos3.y + iconSize3.y)); 
                    ImGui::SetCursorScreenPos(ImVec2(cursorPos3.x + iconSize3.x + 5, cursorPos3.y)); // Adjust the position of the checkbox 
                       //ImGui::SameLine();
                       ImGui::Checkbox("Cấp Cứu", &capcuuz);
                       ImGui::SameLine();
                       ImGui::PushItemWidth(212);
                       ImGui::SliderFloat("##bcc", &maucapcuu , 0.0f , 100.0f,"Địch Dưới %.2f%% Máu");
                       ImGui::PopItemWidth();

                    ImVec2 iconSize5 = ImVec2(25, 25); //Size Icon
                    ImVec2 cursorPos5 = ImGui::GetCursorScreenPos(); 
                    draw_list->AddImage((void*)CFBridgingRetain(bg_texture5), cursorPos5, ImVec2(cursorPos5.x + iconSize5.x, cursorPos5.y + iconSize5.y)); 
                    ImGui::SetCursorScreenPos(ImVec2(cursorPos5.x + iconSize5.x + 5, cursorPos5.y)); // Adjust the position of the checkbox 
                       ImGui::Checkbox("Hồi Máu", &hoimau);
                       ImGui::SameLine();
                       ImGui::PushItemWidth(214);
                       ImGui::SliderFloat("##bccm", &mauhoimau , 0.0f , 100.0f,"Địch Dưới %.2f%% Máu");
                       ImGui::PopItemWidth();

                      
                       
                      
                   }
                }
                 ImGui::EndChild();
                  
                 

                  ImGui::SetCursorPos({133,281});
                  ImGui::BeginChild("##SaveSetting", ImVec2(-1, 45), true);

                  ImGui::Spacing();

                  if (ImGui::Button(oxorany(ICON_FA_SAVE" Lưu"))) 
          { 
             [saveSetting setBool:HackMap forKey:@"HackMap"];
                        [saveSetting setBool:ShowUlti forKey:@"ShowUlti"];
                        [saveSetting setBool:ShowCD forKey:@"ShowCD"];
                        [saveSetting setBool:StreamerMode forKey:@"StreamerMode"];

                        [saveSetting setBool:unlockskin forKey:@"unlockskin"];
                        [saveSetting setBool:enableBanList forKey:@"enableBanList"];
                        [saveSetting setInteger:selectedbutton forKey:@"selectedbutton"];
                        [saveSetting setInteger:selectedValue2 forKey:@"selectedValue2"];

                        [saveSetting setInteger:HeroTypeID forKey:@"HeroTypeID"];

                        [saveSetting setBool:OnCamera forKey:@"OnCamera"];

                         [saveSetting setBool:AimSkill forKey:@"AimSkill"];
                         [saveSetting setBool:aimSkill1 forKey:@"aimSkill1"];
                         [saveSetting setBool:aimSkill2 forKey:@"aimSkill2"];
                         [saveSetting setBool:aimSkill3 forKey:@"aimSkill3"];
                         [saveSetting setInteger:aimType forKey:@"aimType"];
                         [saveSetting setInteger:drawType forKey:@"drawType"];
                         [saveSetting setInteger:LazeThemes forKey:@"LazeThemes"];

                         [saveSetting setFloat:LazeElsu[0] forKey:@"LazeElsuR"];
                         [saveSetting setFloat:LazeElsu[1] forKey:@"LazeElsuG"];
                         [saveSetting setFloat:LazeElsu[2] forKey:@"LazeElsuB"];
                         [saveSetting setFloat:LazeElsu[3] forKey:@"LazeElsuA"];
                         [saveSetting synchronize];
                          [saveSetting setFloat:ColorCrosshair[0] forKey:@"ColorCrosshairR"];
                          [saveSetting setFloat:ColorCrosshair[1] forKey:@"ColorCrosshairG"];
                          [saveSetting setFloat:ColorCrosshair[2] forKey:@"ColorCrosshairB"];
                          [saveSetting setFloat:ColorCrosshair[3] forKey:@"ColorCrosshairA"];
                          [saveSetting synchronize];

                         [saveSetting setBool:ShowLsd forKey:@"ShowLsd"];
                         [saveSetting setBool:ShowLockName forKey:@"ShowLockName"];
                         [saveSetting setBool:ShowAvatar forKey:@"ShowAvatar"];

                         [saveSetting setBool:spamchat forKey:@"spamchat"];
                         [saveSetting setInteger:solanchat forKey:@"solanchat"];

                         [saveSetting setBool:ShowBoTroz forKey:@"ShowBoTroz"];
                         [saveSetting setBool:ShowRank forKey:@"ShowRank"];

                        [saveSetting setBool:Bantuido forKey:@"Bantuido"];
                        [saveSetting setBool:XoaLichSu forKey:@"XoaLichSu"];
                        [saveSetting setInteger:TopSelected forKey:@"TopSelected"];
                        [saveSetting setInteger:selectedRank forKey:@"selectedRank"];
                        [saveSetting setBool:Mod_Rank forKey:@"Mod_Rank"];
                        [saveSetting setBool:enableTopSelect forKey:@"enableTopSelect"];
                        [saveSetting setInteger:selectedStar forKey:@"selectedStar"];
                        [saveSetting setBool:BugSkillRange forKey:@"BugSkillRange"];

                         [saveSetting setBool:autott forKey:@"autott"];
                         [saveSetting setBool:onlymt forKey:@"onlymt"];
                         [saveSetting setBool:autobocpha forKey:@"autobocpha"];
                         [saveSetting setBool:bangsuong forKey:@"bangsuong"];
                         [saveSetting setBool:capcuuz forKey:@"capcuuz"];
                         [saveSetting setBool:hoimau forKey:@"hoimau"];
                         
                        [saveSetting setFloat:maubotro forKey:@"maubotro"];
                        [saveSetting setFloat:mauphutro forKey:@"mauphutro"];
                        [saveSetting setFloat:mauhoimau forKey:@"mauhoimau"];
                        [saveSetting setFloat:maucapcuu forKey:@"maucapcuu"];
                        [saveSetting setFloat:SetFieldOfView forKey:@"SetFieldOfView"];
          }
          ImGui::SameLine();
          if (ImGui::Button(oxorany(ICON_FA_CLOUD_UPLOAD_ALT" Sử Dụng")))
         {
            HackMap = [saveSetting boolForKey:@"HackMap"];
                        ShowUlti = [saveSetting boolForKey:@"ShowUlti"];
                        ShowCD = [saveSetting boolForKey:@"ShowCD"];
                        StreamerMode = [saveSetting boolForKey:@"StreamerMode"];
                        
                        unlockskin = [saveSetting boolForKey:@"unlockskin"];
                        enableBanList = [saveSetting boolForKey:@"enableBanList"];
                        selectedbutton = [saveSetting integerForKey:@"selectedbutton"];
                        selectedValue2 = [saveSetting integerForKey:@"selectedValue2"];

                        HeroTypeID = [saveSetting integerForKey:@"HeroTypeID"];

                        OnCamera = [saveSetting boolForKey:@"OnCamera"];

                        AimSkill = [saveSetting boolForKey:@"AimSkill"];
                        aimSkill1 = [saveSetting boolForKey:@"aimSkill1"];
                        aimSkill2 = [saveSetting boolForKey:@"aimSkill2"];
                        aimSkill3 = [saveSetting boolForKey:@"aimSkill3"];
                        aimType = [saveSetting integerForKey:@"aimType"];
                        drawType = [saveSetting integerForKey:@"drawType"];
                        LazeThemes = (int)[saveSetting integerForKey:@"LazeThemes"];
                        
                        LazeElsu[0] = [saveSetting floatForKey:@"LazeElsuR"];
                        LazeElsu[1] = [saveSetting floatForKey:@"LazeElsuG"];
                        LazeElsu[2] = [saveSetting floatForKey:@"LazeElsuB"];
                        LazeElsu[3] = [saveSetting floatForKey:@"LazeElsuA"];

                        ColorCrosshair[0] = [saveSetting floatForKey:@"ColorCrosshairR"];
                        ColorCrosshair[1] = [saveSetting floatForKey:@"ColorCrosshairG"];
                        ColorCrosshair[2] = [saveSetting floatForKey:@"ColorCrosshairB"];
                        ColorCrosshair[3] = [saveSetting floatForKey:@"ColorCrosshairA"];

                        ShowLsd = [saveSetting boolForKey:@"ShowLsd"];
                        ShowLockName = [saveSetting boolForKey:@"ShowLockName"];
                        ShowAvatar = [saveSetting boolForKey:@"ShowAvatar"];
                        spamchat = [saveSetting boolForKey:@"spamchat"];
                        solanchat = [saveSetting integerForKey:@"solanchat"];
                        ShowBoTroz = [saveSetting boolForKey:@"ShowBoTroz"];
                        ShowRank = [saveSetting boolForKey:@"ShowRank"];

                        Bantuido = [saveSetting boolForKey:@"Bantuido"];
                        XoaLichSu = [saveSetting boolForKey:@"XoaLichSu"];
                        TopSelected = [saveSetting integerForKey:@"TopSelected"];
                        selectedRank = [saveSetting integerForKey:@"selectedRank"];
                        Mod_Rank = [saveSetting boolForKey:@"Mod_Rank"];
                        enableTopSelect = [saveSetting boolForKey:@"enableTopSelect"];
                        selectedStar = [saveSetting integerForKey:@"selectedStar"];
                        BugSkillRange = [saveSetting boolForKey:@"BugSkillRange"];

                        autott = [saveSetting boolForKey:@"autott"];
                        onlymt = [saveSetting boolForKey:@"onlymt"];
                        autobocpha = [saveSetting boolForKey:@"autobocpha"];
                        bangsuong = [saveSetting boolForKey:@"bangsuong"];
                        capcuuz = [saveSetting boolForKey:@"capcuuz"];
                        hoimau = [saveSetting boolForKey:@"hoimau"];

                        maubotro = [saveSetting floatForKey:@"maubotro"];
                        mauphutro = [saveSetting floatForKey:@"mauphutro"];
                        mauhoimau = [saveSetting floatForKey:@"mauhoimau"];
                        maucapcuu = [saveSetting floatForKey:@"maucapcuu"];

                        SetFieldOfView = [saveSetting floatForKey:@"SetFieldOfView"];
         }
                    ImGui::SameLine();
                if (ImGui::Button(oxorany(ICON_FA_PEN" Đặt Lại"))) {
                        HackMap = false;
                        ShowUlti = false;
                        ShowCD = false;
                        StreamerMode = false;
                        unlockskin = false;
                        enableBanList = false;
                        selectedbutton = 0;
                        selectedValue2 = 0;
                        HeroTypeID = 0;
                        OnCamera = false;
                        AimSkill = false;
                        aimSkill1 = false;
                        aimSkill2 = false;
                        aimSkill3 = false;
                        aimType = 0;
                        drawType = 2;
                        LazeThemes = 0;

                        // Reset về mặc định
                        ColorCrosshair[0] = 1.0f;
                        ColorCrosshair[1] = 0.0f;
                        ColorCrosshair[2] = 0.0f;
                        ColorCrosshair[3] = 1.0f;
                    
                          // Reset về mặc định
                         LazeElsu[0] = 0.0f;
                         LazeElsu[1] = 1.0f;
                         LazeElsu[2] = 1.0f;
                         LazeElsu[3] = 1.0f;

                        ShowLsd = false;
                        ShowLockName = false;
                        ShowAvatar = false;
                        spamchat = false;
                        solanchat = 1;
                        ShowBoTroz = false;
                        ShowRank = false;
                        Bantuido = false;
                        XoaLichSu = false;
                        TopSelected = 0;
                        selectedRank = 0;
                        Mod_Rank = false;
                        enableTopSelect = false;
                        selectedStar = 0;
                        BugSkillRange = false;
                        autott = false;
                        onlymt = false;
                        autobocpha = false;
                        bangsuong = false;
                        capcuuz = false;
                        hoimau = false;
                         mauphutro = 13.79f; 
                         maubotro = 12.67f;  
                         mauhoimau = 16.2f; 
                         maucapcuu = 18.45f;
                        SetFieldOfView = 0.0f; 
                        }
                 ImGui::SameLine();
                if (ImGui::Button(ICON_FA_TRASH " Xoá Account"))
					ImGui::OpenPopup("Delete Account?");
				if (ImGui::BeginPopupModal("Delete Account?", NULL, ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoCollapse))
				{
					ImGui::Text("Xoá Tài Khoản Bị Khoá..?");
					

					if (ImGui::Button("Xoá", ImVec2(120, 0)))
					{
						ImGui::CloseCurrentPopup();
                        [self Guest];
					}
					ImGui::SetItemDefaultFocus();
					ImGui::SameLine();
					if (ImGui::Button("Cancel", ImVec2(120, 0))) { ImGui::CloseCurrentPopup(); }
					ImGui::EndPopup();
				}
                 ImGui::EndChild();
                  ImGui::End(); 
            }
  
            ImDrawList* draw_list = ImGui::GetBackgroundDrawList();
            Aimbot(draw_list);
            CallMe(draw_list);
            //DrawESP(draw_list);

  if(ShowRank){ if(ShowRank_active == NO){
 ActiveCodePatch("Frameworks/UnityFramework.framework/UnityFramework", ShowKhungRankOffset , "1F2003D5");
 } ShowRank_active = YES;
    } else { if(ShowRank_active == YES){
  DeactiveCodePatch("Frameworks/UnityFramework.framework/UnityFramework", ShowKhungRankOffset , "1F2003D5");
  } ShowRank_active = NO;
}

if(ShowBoTroz){ if(ShowBoTroz_active == NO){
  ActiveCodePatch("Frameworks/UnityFramework.framework/UnityFramework", ShowBoTroOffset , "1F2003D5");
  } ShowBoTroz_active = YES;
    } else { if(ShowBoTroz_active == YES){
 DeactiveCodePatch("Frameworks/UnityFramework.framework/UnityFramework", ShowBoTroOffset , "1F2003D5");
  } ShowBoTroz_active = NO;
 }


            ImGuiStyle& style = ImGui::GetStyle();
            
            style.WindowRounding = 5.0f;//bo tròn menu
            style.FrameRounding = 4.0f;//bo tròn checkbox .all
            style.FramePadding = ImVec2(6, 4);
            style.GrabMinSize = 16.0f;
            style.GrabRounding = 6.0f;//thanh kéo
            style.ScrollbarSize = 20.0f;
            style.ScrollbarRounding = 6.0f;//thanh cuộn dọc

           // style.ChildRounding = 4.0f;//cửa sổ con child

            //style.Colors[ImGuiCol_ChildBg] = ImVec4(0.302f, 0.302f, 0.302f, 0.196f);
            //style.Colors[ImGuiCol_Border]  = ImVec4(0.302f, 0.302f, 0.302f, 0.196f);


            ImVec4* colors = ImGui::GetStyle().Colors;

// Text
colors[ImGuiCol_Text]                   = ImVec4(1.00f, 1.00f, 1.00f, 1.00f);   // Trắng
colors[ImGuiCol_TextDisabled]           = ImVec4(0.65f, 0.60f, 0.75f, 1.00f);   // Tím nhạt mờ

// Background
colors[ImGuiCol_WindowBg]               = ImVec4(0.19f, 0.17f, 0.25f, 1.00f);   // #1E1B29
colors[ImGuiCol_ChildBg]                 = ImVec4(0.19f, 0.17f, 0.25f, 1.00f);
colors[ImGuiCol_PopupBg]                 = ImVec4(0.19f, 0.17f, 0.25f, 0.94f);

// Border
colors[ImGuiCol_Border]                  = ImVec4(0.52f, 0.31f, 1.00f, 0.50f);  // #8A4FFF mờ
colors[ImGuiCol_BorderShadow]            = ImVec4(0,0,0,0);

// Frames
colors[ImGuiCol_FrameBg]                 = ImVec4(0.29f, 0.22f, 0.45f, 1.00f);  // #4B1C82 nhạt
colors[ImGuiCol_FrameBgHovered]          = ImVec4(0.54f, 0.31f, 1.00f, 0.78f);  // #8A4FFF
colors[ImGuiCol_FrameBgActive]           = ImVec4(0.70f, 0.49f, 1.00f, 0.88f);  // #B47CFF

// Title
colors[ImGuiCol_TitleBg]                 = ImVec4(0.29f, 0.22f, 0.45f, 1.00f);
colors[ImGuiCol_TitleBgActive]           = ImVec4(0.54f, 0.31f, 1.00f, 1.00f);
colors[ImGuiCol_TitleBgCollapsed]        = ImVec4(0.19f, 0.17f, 0.25f, 1.00f);

// Menu Bar
colors[ImGuiCol_MenuBarBg]               = ImVec4(0.29f, 0.22f, 0.45f, 1.00f);

// Scrollbar
colors[ImGuiCol_ScrollbarBg]             = ImVec4(0.19f, 0.17f, 0.25f, 0.50f);
colors[ImGuiCol_ScrollbarGrab]           = ImVec4(0.54f, 0.31f, 1.00f, 0.70f);
colors[ImGuiCol_ScrollbarGrabHovered]    = ImVec4(0.70f, 0.49f, 1.00f, 0.85f);
colors[ImGuiCol_ScrollbarGrabActive]     = ImVec4(0.80f, 0.60f, 1.00f, 1.00f);

// Checkmark
colors[ImGuiCol_CheckMark]               = ImVec4(0.80f, 0.60f, 1.00f, 1.00f);

// Sliders
colors[ImGuiCol_SliderGrab]              = ImVec4(0.70f, 0.49f, 1.00f, 1.00f);
colors[ImGuiCol_SliderGrabActive]        = ImVec4(0.80f, 0.60f, 1.00f, 1.00f);

// Buttons
colors[ImGuiCol_Button]                  = ImVec4(0.54f, 0.31f, 1.00f, 0.65f);
colors[ImGuiCol_ButtonHovered]           = ImVec4(0.70f, 0.49f, 1.00f, 0.85f);
colors[ImGuiCol_ButtonActive]            = ImVec4(0.80f, 0.60f, 1.00f, 1.00f);

// Headers
colors[ImGuiCol_Header]                  = ImVec4(0.54f, 0.31f, 1.00f, 0.65f);
colors[ImGuiCol_HeaderHovered]           = ImVec4(0.70f, 0.49f, 1.00f, 0.85f);
colors[ImGuiCol_HeaderActive]            = ImVec4(0.80f, 0.60f, 1.00f, 1.00f);

// Tabs
colors[ImGuiCol_Tab]                     = ImVec4(0.29f, 0.22f, 0.45f, 1.00f);
colors[ImGuiCol_TabHovered]              = ImVec4(0.70f, 0.49f, 1.00f, 0.85f);
colors[ImGuiCol_TabActive]               = ImVec4(0.54f, 0.31f, 1.00f, 1.00f);
colors[ImGuiCol_TabUnfocused]            = ImVec4(0.29f, 0.22f, 0.45f, 1.00f);
colors[ImGuiCol_TabUnfocusedActive]      = ImVec4(0.54f, 0.31f, 1.00f, 1.00f);

// Table
colors[ImGuiCol_TableHeaderBg]           = ImVec4(0.29f, 0.22f, 0.45f, 1.00f);
colors[ImGuiCol_TableBorderStrong]       = ImVec4(0.54f, 0.31f, 1.00f, 0.80f);
colors[ImGuiCol_TableBorderLight]        = ImVec4(0.70f, 0.49f, 1.00f, 0.50f);

// Selection
colors[ImGuiCol_TextSelectedBg]          = ImVec4(0.70f, 0.49f, 1.00f, 0.35f);

// Misc
colors[ImGuiCol_DragDropTarget]          = ImVec4(1.00f, 0.80f, 0.00f, 0.90f);
colors[ImGuiCol_NavHighlight]            = ImVec4(0.80f, 0.60f, 1.00f, 1.00f);
colors[ImGuiCol_NavWindowingHighlight]   = ImVec4(1.00f, 1.00f, 1.00f, 0.70f);
colors[ImGuiCol_NavWindowingDimBg]       = ImVec4(0.80f, 0.80f, 0.80f, 0.20f);
colors[ImGuiCol_ModalWindowDimBg]        = ImVec4(0.80f, 0.80f, 0.80f, 0.35f);








            ImGui::Render();
            ImDrawData* draw_data = ImGui::GetDrawData();
            ImGui_ImplMetal_RenderDrawData(draw_data, commandBuffer, renderEncoder);
          
            [renderEncoder popDebugGroup];
            [renderEncoder endEncoding];

            [commandBuffer presentDrawable:view.currentDrawable];
        }

        [commandBuffer commit];
}

- (void)mtkView:(MTKView*)view drawableSizeWillChange:(CGSize)size
{ }

void DrawHealthBar(ImDrawList* draw, Vector3 enemyPos, ImVec2 rootPos_Vec2, int EnemyHp, int EnemyHpTotal, int EnemyEp, int EnemyEpTotal, std::string heroname, int GetLever) {
    Vector3 screenPos = Camera::get_main()->WorldToViewportPoint(enemyPos);
    if (screenPos.z < 0) return;

    ImVec2 pos(screenPos.x * kWidth, kHeight - screenPos.y * kHeight);
    pos.y += hb_offsetY;

    // ⚙️ Biến cấu hình
    float barWidth    = hb_barWidth;
    float hpHeight    = hb_hpHeight;
    float mpHeight    = hb_mpHeight;
    float paddingX    = hb_paddingX;
    float spacingY    = hb_spacingY;
    float diamondSize = hb_diamondSize;
    float textScale   = hb_textScale;
    float nameOffsetY = hb_nameOffsetY;

    std::string levelStr = std::to_string(GetLever);

    ImVec2 nameSize = ImGui::CalcTextSize(heroname.c_str());
    nameSize.x *= textScale;
    nameSize.y *= textScale;

    ImVec2 levelSize = ImGui::CalcTextSize(levelStr.c_str());
    levelSize.x *= textScale;
    levelSize.y *= textScale;

    float totalHeight = nameSize.y + hpHeight + mpHeight + spacingY * 2.0f;
    ImVec2 topLeft(pos.x - barWidth / 2, pos.y - totalHeight);

    ImVec2 nameBgPos = ImVec2(topLeft.x, topLeft.y);
    ImVec2 nameBgEnd = ImVec2(topLeft.x + barWidth, topLeft.y + nameSize.y);

    ImVec2 hpPos = ImVec2(topLeft.x + paddingX, nameBgEnd.y + spacingY);
    ImVec2 mpPos = ImVec2(topLeft.x + paddingX, hpPos.y + hpHeight + 1);

    // 🟥 Nền tên tướng
    draw->AddRectFilled(nameBgPos, nameBgEnd, IM_COL32(0, 0, 0, 150));

    // ❤️ Thanh máu
    draw->AddRectFilled(hpPos, ImVec2(hpPos.x + barWidth - paddingX * 2, hpPos.y + hpHeight), IM_COL32(0, 0, 0, 150));
    draw->AddRectFilled(hpPos, ImVec2(hpPos.x + (barWidth - paddingX * 2) * ((float)EnemyHp / (float)EnemyHpTotal), hpPos.y + hpHeight), IM_COL32(255, 0, 0, 255));

    // 🔵 Thanh năng lượng
    draw->AddRectFilled(mpPos, ImVec2(mpPos.x + barWidth - paddingX * 2, mpPos.y + mpHeight), IM_COL32(0, 0, 0, 150));
    if (EnemyEpTotal > 0) {
        draw->AddRectFilled(mpPos, ImVec2(mpPos.x + (barWidth - paddingX * 2) * ((float)EnemyEp / (float)EnemyEpTotal), mpPos.y + mpHeight), IM_COL32(50, 104, 168, 255));
    } else {
        draw->AddRectFilled(mpPos, ImVec2(mpPos.x + barWidth - paddingX * 2, mpPos.y + mpHeight), IM_COL32(255, 255, 255, 150));
    }

    // ♦️ Vẽ hình thoi cấp độ
    ImVec2 diamondCenter = ImVec2(nameBgPos.x, nameBgPos.y + nameSize.y / 2);
    for (float i = 0; i < 2.0f; i++) {
        draw->AddQuad(
            ImVec2((int)(diamondCenter.x), (int)(diamondCenter.y - diamondSize - i)),
            ImVec2((int)(diamondCenter.x + diamondSize + i), (int)(diamondCenter.y)),
            ImVec2((int)(diamondCenter.x), (int)(diamondCenter.y + diamondSize + i)),
            ImVec2((int)(diamondCenter.x - diamondSize - i), (int)(diamondCenter.y)),
            IM_COL32(255, 255, 255, 255)
        );
    }
    draw->AddQuadFilled(
        ImVec2((int)(diamondCenter.x), (int)(diamondCenter.y - diamondSize)),
        ImVec2((int)(diamondCenter.x + diamondSize), (int)(diamondCenter.y)),
        ImVec2((int)(diamondCenter.x), (int)(diamondCenter.y + diamondSize)),
        ImVec2((int)(diamondCenter.x - diamondSize), (int)(diamondCenter.y)),
        IM_COL32(0, 0, 0, 255)
    );

    // 🔢 Số cấp độ
    ImVec2 levelTextPos = ImVec2(
        (int)(diamondCenter.x - levelSize.x / 2),
        (int)(diamondCenter.y - levelSize.y / 2)
    );
    draw->AddText(NULL, ImGui::GetFontSize() * textScale,
        levelTextPos,
        IM_COL32(255, 255, 255, 255), levelStr.c_str());

    // ✏️ Tên tướng (canh giữa, không rung, có offset)
    ImVec2 nameCenter = ImVec2((nameBgPos.x + nameBgEnd.x) * 0.5f, (nameBgPos.y + nameBgEnd.y) * 0.5f);
    ImVec2 nameTextPos = ImVec2(
        (int)(nameCenter.x - nameSize.x * 0.5f),
        (int)(nameCenter.y - nameSize.y * 0.5f + nameOffsetY)
    );

    draw->AddText(NULL, ImGui::GetFontSize() * textScale,
                  ImVec2(nameTextPos.x + 1, nameTextPos.y + 1), IM_COL32(0, 0, 0, 255), heroname.c_str()); // viền
    draw->AddText(NULL, ImGui::GetFontSize() * textScale,
                  nameTextPos, IM_COL32(255, 255, 0, 255), heroname.c_str()); // vàng
}

void Draw3dBox(ImDrawList *draw, Vector3 Transform, Camera* camera) {
    ImVec4 selectedImGuiColor2[0];  // hoặc số lượng màu bạn cần
    selectedImGuiColor2[0] = ImVec4(1.0f, 1.0f, 0.0f, 1.0f); // màu vàng (R=1, G=1, B=0)
    const Vector3 positions[8] = {
        Transform + Vector3(0.6f, 1.2f, 0.6f),
        Transform + Vector3(0.6f, 0.0f, 0.6f),
        Transform + Vector3(-0.6f, 0.0f, 0.6f),
        Transform + Vector3(-0.6f, 1.2f, 0.6f),
        Transform + Vector3(0.6f, 1.2f, -0.6f),
        Transform + Vector3(0.6f, 0.0f, -0.6f),
        Transform + Vector3(-0.6f, 0.0f, -0.6f),
        Transform + Vector3(-0.6f, 1.2f, -0.6f)
    };

    float height = kHeight / 40.0f;
    ImVec2 vector[8];

    for (int i = 0; i < 8; i++) {
        Vector3 pos = camera->WorldToScreen(positions[i]);
        vector[i].x = pos.x * kWidth;
        vector[i].y = kHeight - pos.y * kHeight - height;
    }

    int lines[12][2] = {
        {0, 1}, {1, 2}, {0, 3}, {2, 3},
        {4, 5}, {5, 6}, {4, 7}, {6, 7},
        {0, 4}, {1, 5}, {2, 6}, {3, 7}
    };

    for (const auto& line : lines) {
        draw->AddLine(
            ImVec2(vector[line[0]].x, vector[line[0]].y),
            ImVec2(vector[line[1]].x, vector[line[1]].y),
            ImGui::GetColorU32(selectedImGuiColor2[0]), 0.5f
        );
    }
}


static std::unordered_map<int, std::string> skillNameMap = {
        {80102, "capcuu"},
        {80103, "ngatngu"},
        {80104, "trungtri"},
        {80105, "suynhuoc"},
        {80107, "thanhtay"},
        {80108, "bocpha"},
        {80109, "tochanh"},
        {80110, "gamthet"},
        {80115, "tocbien"},
        {80116, "trungtri"},
        {80133, "vienbinh"}
    };

void DrawESP(ImDrawList* draw)
{
    if (espManager->enemies->empty()) 
    {
        previousEnemyPositions.clear();
        return;
    }

    int lowestHp = INT_MAX;
    int lowestHp2 = INT_MAX;
    float lowestHpPercent = FLT_MAX;
    float closestDistance = FLT_MAX;
    float closestViewDistance = FLT_MAX;
    int enemyCount = 0;
    float lineThickness = 2.5f;
    float thickness = 1.0f;
    Vector3 EnemyPos = Vector3::zero();

    void *MyLinker = espManager->MyPlayer;
    Vector3 myPos = ActorLinker_getPosition(MyLinker);

    for (int i = 0; i < espManager->enemies->size(); i++)
    {
        void *EnemyRoot = (*espManager->enemies)[i]->object;
        if (!EnemyRoot) continue;

        void *EnemyLinker = (*ActorLinker_enemy->enemies)[i]->object;
        if (!EnemyLinker) continue;

        void* actorControl = *(void**)((uint64_t)EnemyRoot + GetFieldOffset(oxorany("Project.Plugins_d.dll"),oxorany("NucleusDrive.Logic"),oxorany("LActorRoot"),oxorany("ActorControl")));
        if (!actorControl || LObjWrapper_get_IsDeadState(actorControl)) continue;

        VInt3 locationPtr = LActorRoot_get_location(EnemyRoot);
        VInt3 forwardPtr = LActorRoot_get_forward(EnemyRoot);
        bool isVisible = ActorLinker_get_bVisible(EnemyLinker);
      
        if (isVisible) {
            EnemyPos = ActorLinker_getPosition(EnemyLinker);
            previousEnemyPositions[(uintptr_t)EnemyRoot] = EnemyPos;
        } else {
            EnemyPos = VInt2Vector(locationPtr, forwardPtr);
            if (previousEnemyPositions.find((uintptr_t)EnemyRoot) == previousEnemyPositions.end())
                previousEnemyPositions[(uintptr_t)EnemyRoot] = EnemyPos;
            EnemyPos = Lerp(previousEnemyPositions[(uintptr_t)EnemyRoot], EnemyPos, 0.2f);
            previousEnemyPositions[(uintptr_t)EnemyRoot] = EnemyPos;
        }
        

        void *ValuePropertyComponent = *(void**)((uint64_t)EnemyRoot + GetFieldOffset(oxorany("Project.Plugins_d.dll"), oxorany("NucleusDrive.Logic"), oxorany("LActorRoot"), oxorany("ValueComponent")));
        if (!ValuePropertyComponent) continue;
        int EnemyHp = ValuePropertyComponent_get_actorHp(ValuePropertyComponent);
        int EnemyHpTotal = ValuePropertyComponent_get_actorHpTotal(ValuePropertyComponent);
        int EnemyEp = ValuePropertyComponent_get_actorEp(ValuePropertyComponent);
        int EnemyEpTotal = ValuePropertyComponent_get_actorEpTotal(ValuePropertyComponent);
        int GetLever = ValuePropertyComponent_get_actorSoulLevel(ValuePropertyComponent);
        float EpPercent = (float)EnemyHp/EnemyHpTotal;

        float distance = Vector3::Distance(myPos, EnemyPos);
        ImVec2 rootPos_Vec2 = GetPlayerPosition(EnemyPos);

        void *ObjLinker = *(void **)((uintptr_t)EnemyLinker + GetFieldOffset(oxorany("Project_d.dll"), oxorany("Kyrios.Actor"), oxorany("ActorLinker"),oxorany("ObjLinker")));
        if(!ObjLinker) continue;
        int ConfigID = *(int *)((uintptr_t)ObjLinker + GetFieldOffset(oxorany("Project_d.dll"),oxorany("Assets.Scripts.GameLogic"), oxorany("ActorConfig"), oxorany("ConfigID")));
       
        string heroname;
        HeroData heroData = findHeroById(ConfigID);
        heroname = heroData.name ? string(heroData.name) : "Unknown";
          
        if (ESPEnable)
        {
          if (CheckFogEsp && isVisible) continue;

          if (PlayerLine)
          {
                draw->AddLine(ImVec2(kWidth / 2, 38), ImVec2(rootPos_Vec2.x, rootPos_Vec2.y - 15.0f), IM_COL32(255, 255, 255, 180), 1.2f);
                draw->AddCircleFilled(ImVec2(rootPos_Vec2.x, rootPos_Vec2.y - 15.0f), 3.0f, IM_COL32(0, 255, 0, 255));
          }    
          if(PlayerHealth)
          {
                DrawHealthBar(draw, EnemyPos, rootPos_Vec2, EnemyHp, EnemyHpTotal, EnemyEp, EnemyEpTotal, heroname, GetLever);
          }

          if(PlayerBox3D)
          {
               if (Camera::get_main())
                   Draw3dBox(draw, EnemyPos, Camera::get_main());
          }
          if (PlayerDistance)
          {
            char strDistance[32];
             snprintf(strDistance, sizeof(strDistance), " %.1f m ", distance); // VD: [ 22.7 m ]

             float fontSize = (float)kHeight / 39.0f;
 
             // Dùng đúng font hiện tại
             ImFont* font = ImGui::GetFont();
             ImVec2 textSize = font->CalcTextSizeA(fontSize, FLT_MAX, 0.0f, strDistance);

             // Chính giữa địch
              ImVec2 textPos = ImVec2(
              rootPos_Vec2.x - textSize.x * 0.5f,  // Giữa theo chiều ngang
              rootPos_Vec2.y + 7.0f              // Dưới chân, có thể tăng/giảm
             );

             // Viền chữ đen nhẹ để dễ đọc
             draw->AddText(font, fontSize, ImVec2(textPos.x + 1, textPos.y + 1), IM_COL32(0, 0, 0, 180), strDistance);
             draw->AddText(font, fontSize, textPos, IM_COL32(100, 200, 255, 255), strDistance);
            }


     //   }
            /*
             if (g_FontESP)
              {
               char distText[32];
               sprintf(distText, "%.1fm", distance);

                draw->AddText(g_FontESP,
                      g_FontESP->FontSize,
                      ImVec2(rootPos_Vec2.x, rootPos_Vec2.y - 45.0f),
                      IM_COL32(255, 255, 0, 255),
                      distText);
              }
              */
          //}





        }


      if (ShowIconBT)
      {
        // Vị trí icon
        ImVec2 pos(mapStartX + enemyCount * mapSpacingX, mapStartY);

        // Máu
        //float hpBarHeight = 5.0f;
       // float hp = actorLinker->ValueComponent()->get_actorHp();
        //float maxHp = actorLinker->ValueComponent()->get_actorHpTotal();
        //if (maxHp <= 0) continue;
        //float hpPercent = hp / maxHp;
         
           // Vẽ progress vòng máu xanh
        float startAngle = -IM_PI / 2.0f;
        float endAngle = startAngle + (IM_PI * 2.0f * EpPercent);
        draw->PathClear();
        draw->PathArcTo(pos, mapRadius, startAngle, endAngle, 64);
        draw->PathStroke(IM_COL32(0, 255, 0, 255), false, lineThickness);

        // Viền trắng ngoài
        draw->AddCircle(pos, mapRadius, IM_COL32(255, 255, 255, 255), 64, 1.0f);

        // Icon hero
       // int IDHero = actorLinker->ObjLinker()->ConfigID();
        //HeroData heroData = findHeroById(IDHero);
        if (heroData.heroid != -1 && heroData.index >= 0 && heroData.index < textures.size())
        {
            float iconSize = (mapRadius * 2.0f) - (thickness * 2.0f);
            ImVec2 avatarMin(pos.x - iconSize / 2, pos.y - iconSize / 2);
            ImVec2 avatarMax(pos.x + iconSize / 2, pos.y + iconSize / 2);

            draw->AddImage(
                (ImTextureID)(intptr_t)textures[heroData.index].texture,
                avatarMin,
                avatarMax,
                ImVec2(0, 0),
                ImVec2(1, 1)
            );
        }

        // Lấy cooldown bổ trợ
    
        uintptr_t SkillControl = AsHero(EnemyLinker);
        if (SkillControl > 0)
        {
            Skill5_C3 = *(int *)(SkillControl + (c3 - 0x4)) / 1000;
            Skill5ID = *(int*)(SkillControl + Skill5OK);
            Skill5BT = *(int*)(SkillControl + (botro - 0x4)) / 1000;
        }

        // Chấm hoặc số cooldown trên đầu icon
        ImVec2 dotPos(pos.x, pos.y - mapRadius - 6.0f); // - lên + xuống
        if (Skill5_C3 > 0)
        {
            std::string cdText = std::to_string(Skill5_C3);
            ImVec2 textSize = ImGui::CalcTextSize(cdText.c_str());
            draw->AddText(ImVec2(dotPos.x - textSize.x / 2, dotPos.y - textSize.y / 2), IM_COL32(255, 255, 255, 255), cdText.c_str());
        }
        else
        {
        
            float dotRadius = 4.0f;
            // Vẽ hình thoi
            draw->PathClear();
            draw->PathLineTo(ImVec2(dotPos.x, dotPos.y - dotRadius)); // trên
            draw->PathLineTo(ImVec2(dotPos.x + dotRadius, dotPos.y)); // phải
            draw->PathLineTo(ImVec2(dotPos.x, dotPos.y + dotRadius)); // dưới
            draw->PathLineTo(ImVec2(dotPos.x - dotRadius, dotPos.y)); // trái
            draw->PathFillConvex(IM_COL32(0, 255, 0, 255));

        }
if (Skill5ID > 0)
{
    auto it = skillNameMap.find(Skill5ID);
    if (it != skillNameMap.end())
    {
        std::string skillName = it->second;
        int indexbt = findHeroByName(skillName.c_str()).index;

        if (indexbt != -1)
        {
            // Icon bổ trợ
            float btSize = 11.0f; // icon bổ troẹ to nhỏ
            float btOffsetY = mapRadius + 2.5f;  // đặt icon gần sát vòng máu - lên  + xuống
            ImVec2 btMin(pos.x - btSize / 2, pos.y + btOffsetY);
            ImVec2 btMax(pos.x + btSize / 2, pos.y + btOffsetY + btSize);

            draw->AddImage((ImTextureID)(intptr_t)textures[indexbt].texture,
                btMin,btMax,
                ImVec2(0, 0),
                ImVec2(1, 1)
            );

            // Vòng tròn vàng quanh icon bổ trợ
            float btCenterX = (btMin.x + btMax.x) / 2;
            float btCenterY = (btMin.y + btMax.y) / 2;
            float btRadius = (btMax.x - btMin.x) / 2 + 1.5f;

            draw->AddCircle(
                ImVec2(btCenterX, btCenterY),
                btRadius,
                IM_COL32(255, 255, 0, 200),
                64, 1.0f
            );

           if (Skill5BT > 0)
{
    std::string cdText = std::to_string(Skill5BT);
    ImFont* font = ImGui::GetFont(); // Hoặc font custom riêng nếu có
    float fontSize = 9.0f;

    // Nền tròn mờ phía sau số cooldown
    float bgRadius = 5.5f;
    draw->AddCircleFilled(ImVec2(btCenterX, btCenterY), bgRadius, IM_COL32(0, 0, 0, 100), 32);

    // Tính kích thước text với size font cụ thể
    ImVec2 textSize = font->CalcTextSizeA(fontSize, FLT_MAX, 0.0f, cdText.c_str());

    // Tính vị trí để text nằm chính giữa icon bổ trợ
    ImVec2 textPos(
        btCenterX - textSize.x * 0.5f,
        btCenterY - textSize.y * 0.5f + 0.5f // cộng nhẹ 0.5f cho cân bằng chiều dọc
    );

    // Vẽ text màu xanh ddor
    draw->AddText(font, fontSize, textPos, IM_COL32(255, 0, 0, 255), cdText.c_str());
}


            }
        }
    }
}
        enemyCount++;

    }
}



@end