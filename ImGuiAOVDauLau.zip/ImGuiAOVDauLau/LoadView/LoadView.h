#import <Foundation/Foundation.h>
// #import "../Utils/MethodObfuscation.h"

NS_ASSUME_NONNULL_BEGIN

@interface MenuLoad : NSObject
@end

@interface MenuInteraction : UIView
@end

NS_ASSUME_NONNULL_END
