

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface NemSelf : UIView


extern BOOL AntiHooK;

+ (instancetype)Timer;

- (void)start;

@end

NS_ASSUME_NONNULL_END
